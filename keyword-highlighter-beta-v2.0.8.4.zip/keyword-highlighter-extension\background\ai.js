/**
 * background/ai.js · 重要笔记面板「AI 助手」的**唯一请求出口**（2.0.8.4 需求④）
 * ----------------------------------------------------------------------------
 * 为什么必须放在后台：
 *   内容脚本里的 `fetch` 走**页面来源**的 CORS 口径，`api.deepseek.com` 不会给任意网站放行；
 *   service worker 是扩展自己的来源，又有 `host_permissions: <all_urls>`，才发得出去。
 *   设置页的「测试连接」也复用 `KhAi.chat`（只有一份实现，测的就是真发请求的那条路）。
 *
 * 协议：OpenAI 兼容的 `POST {baseUrl}/chat/completions`
 *   { model, messages:[{role,content}], max_tokens, stream:false, temperature? }
 *   headers: Authorization: Bearer <apiKey>（没填 key 就不带，本地/中转服务可能不需要）
 * 回执：{ ok:true, text } | { ok:false, error }（错误原文照抄，不做"友好化"改写 ——
 *   用户要能拿它去搜/去问服务商；面板负责把原文显示出来）。
 *
 * 口径（用户 2026-11-03 拍板）：
 *   · 支持各类 API —— 只要求 OpenAI 兼容；默认值来自 `Config.defaults.ai`（DeepSeek 官方）。
 *   · **纯自由对话**：不带页面标题 / URL / 笔记内容，发出去的只有用户自己打的那几句。
 *   · key 只存在本机 storage，不写日志、不回显、不进导出。
 * ========================================================================= */

(function () {
  'use strict';

  const AI = {};

  /** 请求超时（ms）：流式没开、模型慢时给足一分钟；到点如实报"超时"而不是永远转圈。 */
  const TIMEOUT_MS = 60000;
  /** 错误体最多回传多少字符（整页 HTML 错误页只截开头，面板里放得下也看得清）。 */
  const ERR_TEXT_MAX = 400;

  /** 当前配置（读 storage → 走 Config.merge/normalize 这条**唯一**归一，不在这里抄默认值） */
  function readConfig() {
    return Promise.resolve()
      .then(() => chrome.storage.local.get(null))
      .then((all) => {
        const C = self.KH && self.KH.Config;
        if (!C || typeof C.merge !== 'function') return {};
        const merged = C.merge(all || {});
        const normalized = (typeof C.normalize === 'function') ? C.normalize(merged).config : merged;
        return (normalized && normalized.ai) || {};
      })
      .catch(() => ({}));
  }

  /** `{baseUrl}` → 完整的 chat/completions 地址（用户已经填到端点就不重复拼）。 */
  function endpointOf(baseUrl) {
    const base = String(baseUrl || '').trim().replace(/\/+$/, '');
    if (!base) return '';
    if (/\/chat\/completions$/i.test(base)) return base;
    return base + '/chat/completions';
  }

  /** 把消息数组洗成协议要求的形状（只留 role/content；空内容丢弃） */
  function cleanMessages(list) {
    const out = [];
    if (!Array.isArray(list)) return out;
    for (let i = 0; i < list.length; i++) {
      const m = list[i] || {};
      const role = (m.role === 'assistant') ? 'assistant' : 'user';
      const content = String(m.content == null ? '' : m.content);
      if (!content.trim()) continue;
      out.push({ role: role, content: content.slice(0, 8000) });
    }
    return out;
  }

  /**
   * 发一次对话请求。
   * @param {{messages?: Array, override?: Object}} msg  `override` 只给设置页「测试连接」用：
   *        用页面上**还没保存**的那几项去试，避免"先存再测"把坏配置存进去。
   * @returns {Promise<{ok:boolean, text?:string, error?:string}>}
   */
  AI.chat = async function (msg) {
    const payload = msg || {};
    const stored = await readConfig();
    const override = (payload.override && typeof payload.override === 'object') ? payload.override : null;
    const C = (self.KH && self.KH.Config) || {};
    /* 变量名刻意不叫 `cfg`：单测的「配置键守卫」会把 `cfg.<键>` 当成顶层配置读点，
     * 这里的 enabled/baseUrl/model… 都是 `ai` 下面的子键（不是 Config.defaults 的顶层键）。 */
    const ai = (typeof C.normalizeAi === 'function')
      ? C.normalizeAi(Object.assign({}, stored, override || {}))
      : Object.assign({}, stored, override || {});

    if (ai.enabled === false) return { ok: false, error: 'AI 助手已在设置里关闭' };
    const url = endpointOf(ai.baseUrl);
    if (!url) return { ok: false, error: '还没填接口地址（设置 → AI 助手）' };
    if (!/^https?:\/\//i.test(url)) return { ok: false, error: '接口地址必须以 http:// 或 https:// 开头' };

    const messages = cleanMessages(payload.messages);
    if (!messages.length) return { ok: false, error: '没有要发送的内容' };
    const sys = String(ai.system || '').trim();
    if (sys) messages.unshift({ role: 'system', content: sys.slice(0, 4000) });

    const body = {
      model: ai.model || '',
      messages: messages,
      max_tokens: ai.maxTokens || 800,
      stream: false
    };

    const headers = { 'Content-Type': 'application/json' };
    if (ai.apiKey) headers.Authorization = 'Bearer ' + ai.apiKey;

    const ctrl = (typeof AbortController === 'function') ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch (e) { /* ignore */ } }, TIMEOUT_MS) : 0;
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(body),
        signal: ctrl ? ctrl.signal : undefined,
        credentials: 'omit',
        cache: 'no-store'
      });
    } catch (err) {
      if (timer) clearTimeout(timer);
      const aborted = err && (err.name === 'AbortError' || /aborted/i.test(String(err.message || '')));
      return { ok: false, error: aborted ? ('请求超时（' + Math.round(TIMEOUT_MS / 1000) + ' 秒）') : ('请求没发出去：' + String((err && err.message) || err)) };
    }
    if (timer) clearTimeout(timer);

    let text = '';
    try { text = await res.text(); } catch (e) { text = ''; }

    if (!res.ok) {
      /* 错误原文优先取 JSON 里的 error.message（各家都在这），没有就截原文。
       * ⚠️ 绝不把请求头/Key 打进错误里 —— 这里只碰响应体。 */
      let detail = text;
      try {
        const j = JSON.parse(text);
        detail = (j && j.error && (j.error.message || j.error.code)) || (j && j.message) || text;
      } catch (e) { /* 不是 JSON：原样截断 */ }
      detail = String(detail || '').slice(0, ERR_TEXT_MAX);
      return { ok: false, error: 'HTTP ' + res.status + (detail ? '：' + detail : ''), status: res.status };
    }

    let data = null;
    try { data = JSON.parse(text); } catch (e) { data = null; }
    const choice = data && data.choices && data.choices[0];
    const content = choice && ((choice.message && choice.message.content) || choice.text);
    if (!content) {
      /* 200 但没有内容：把原文截一段回去（多半是协议不兼容 / 中转返回了别的东西） */
      const raw = String(text || '').slice(0, ERR_TEXT_MAX);
      return { ok: false, error: '接口没有返回内容' + (raw ? '：' + raw : '') };
    }
    return { ok: true, text: String(content) };
  };

  /** 设置页「测试连接」：发一句最短的话，只要通就够（消耗的 token 可以忽略）。 */
  AI.test = function (override) {
    return AI.chat({ messages: [{ role: 'user', content: '你好' }], override: override || null });
  };

  self.KhAi = AI;
})();
