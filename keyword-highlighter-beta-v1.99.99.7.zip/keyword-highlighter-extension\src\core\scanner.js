/* ============================================================================
 * src/core/scanner.js · ③Scan + 扩展点② ScannerProbe + 跨节点边界
 * ----------------------------------------------------------------------------
 * 职责：在给定的 root 里遍历文本节点，产出**原始候选命中**（RawHit）。
 *   · 不判断重叠、不渲染、不写注册表 —— 那是 arbiter / renderer / registry 的事。
 *   · 遍历顺序固定：TreeWalker + SHOW_TEXT + 跳过插件自身 UI 子树（`data-kh-ext-ui`）。
 *   · `options.shadow === true`（对应配置 `shadowDOMEnabled`，旧版默认 true）时，
 *     额外逐层进入 Shadow Root —— TreeWalker 按规范不跨 Shadow 边界，必须显式取 root
 *     （`collectShadowRoots`，与 Scheduler 共用同一份遍历）。
 *
 * 扩展点②使用方式（新增一种"定位方式"，例如"命中图片"、canvas 旁文本）：
 *   KH.Scanner.probes.register('image-alt', {
 *     applies(rule) { return rule.kind === 'normal'; },
 *     scan(root, rule, ctx) { return [ {node, start, end, text} ]; }
 *   });
 *   —— 内核文件 diff = 0（UN-06 验收）。
 *   注意：Probe 返回的坐标若能落成 Range 则后续走统一渲染；不能落 Range 的（如图片）
 *   由 Renderer 插件负责视觉，`Range` 为 null 时 Registry 仍登记（供聚合/统计）。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** RawHit 契约：{ rule, node: Text|null, start, end, text, rangeHint } */

  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'TEMPLATE']);
  /** 插件自身 UI 宿主标记（唯一允许出现在 DOM 上的插件属性之一，铁律 §2 第 2 条） */
  const UI_ATTR = 'data-kh-ext-ui';

  /**
   * 该节点是否属于插件自身 UI（含 Shadow 宿主的宿主节点）。
   *
   * 【必须跨 Shadow 边界上溯】DOM 里 `parentElement` 链**在 Shadow 边界处截断**
   * （ShadowRoot 的直接子元素的 `parentElement` 是 null）。
   * 我们自己的面板/卡片内容全在各自的 ShadowRoot 里 —— 一旦开启 Shadow 内扫描
   * （`options.shadow`），若不做跨边界上溯，就会把自己 UI 里的文字当成页面文字去匹配
   * （旧版 v1.13.x 踩过的"备注卡片里的关键词被自己高亮"）。用 `getRootNode()` 出边界，
   * 检查该 root 的 host，再继续向上，直到 document。
   */
  function isOwnUI(node) {
    let el = node && (node.nodeType === 1 ? node : node.parentElement);
    while (el && el.nodeType === 1) {
      if (el.hasAttribute && el.hasAttribute(UI_ATTR)) return true;
      el = el.parentElement;
    }
    // 已到本 root 顶部（或压根没有 parentElement）→ 看看是不是某个 ShadowRoot 内部
    const root = node && node.getRootNode ? node.getRootNode() : null;
    if (root && root.host && root !== document) return isOwnUI(root.host);
    return false;
  }

  /** 该元素的 ShadowRoot（closed 模式取不到 → null；某些沙箱元素会抛，一并吞掉） */
  function shadowRootOf(el) {
    try { return (el && el.shadowRoot) || null; } catch (err) { return null; }
  }

  /**
   * 收集 root 子树内**全部（含嵌套）**的 ShadowRoot。
   * 唯一实现：Scanner（决定扫哪些文本）与 Scheduler（决定观察哪些子树）共用同一份遍历，
   * 避免两处各自写一套"找 shadow root"逻辑而漂移。
   * 用 TreeWalker(SHOW_ELEMENT) 而不是 querySelectorAll('*')：
   * 后者会为整页分配一个巨大的 NodeList，而这里只需要逐个元素看一眼 `shadowRoot`。
   *
   * 注意两个容易写错的点（都实测踩过）：
   *   · `createTreeWalker` 是 **Document 上的方法**，元素/ShadowRoot 上**没有**
   *     （`document.body.createTreeWalker === undefined`）——所以创建一律走 `document`，
   *     判断入参能不能当 root 要看 `nodeType`（元素 1 / 文档 9 / 片段 11），
   *     绝不能拿 `root.createTreeWalker` 当可用性守卫（对元素恒为 undefined → 永远返回空）。
   *   · TreeWalker 不跨 Shadow 边界，所以嵌套 Shadow 必须递归各自处理。
   */
  function collectShadowRoots(root, out) {
    const list = out || [];
    if (!root) return list;
    const t = root.nodeType;
    if (t !== 1 && t !== 9 && t !== 11) return list;   // 只有 元素/文档/DocumentFragment 能当 root
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null);
    let el;
    while ((el = walker.nextNode())) {
      const sr = shadowRootOf(el);
      if (!sr) continue;
      list.push(sr);
      collectShadowRoots(sr, list);       // TreeWalker 不跨边界 → 嵌套 Shadow 递归处理
    }
    return list;
  }

  /** 一个 root（Element / ShadowRoot / Document）内的可扫描文本节点 */
  function walkTextNodes(root, out, opts) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        if (SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
        if (p.isContentEditable && !opts.includeEditable) return NodeFilter.FILTER_REJECT;
        if (p.hasAttribute && p.hasAttribute(UI_ATTR)) return NodeFilter.FILTER_REJECT;
        if (isOwnUI(p)) return NodeFilter.FILTER_REJECT;
        if (!node.nodeValue || !node.nodeValue.length) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let n;
    while ((n = walker.nextNode())) out.push(n);
    return out;
  }

  /**
   * 收集可扫描文本节点（跳过插件 UI / script / 可编辑区）。
   *
   * `options.shadow === true` 时**额外进入 Shadow Root 内部** —— 这是旧版
   * `shadowDOMEnabled`（默认 true，`setupShadowDOMObserver` / `_highlightInRoot(shadowRoot)`）
   * 的等价能力，重构不能丢：TreeWalker 按规范**不会**跨越 Shadow 边界，
   * 所以 Shadow 内的文本必须靠 `collectShadowRoots` 显式取出来单独走一遍。
   */
  function collectTextNodes(root, options) {
    const opts = options || {};
    const out = [];
    if (!root) return out;
    walkTextNodes(root, out, opts);
    if (opts.shadow) {
      for (const sr of collectShadowRoots(root)) walkTextNodes(sr, out, opts);
    }
    return out;
  }

  /* ==================================================================
   * 跨文本节点词边界守卫（cross-node boundary guard）
   * ------------------------------------------------------------------
   * 【语义定稿 —— 很容易理解反，这里写清楚】
   *   它是**负向守卫（作废误判）**，不是"跨节点拼接命中"。
   *   策划案原文（plan.md:292）：
   *     "页面把连续文本拆成相邻节点（如 BUG 被另一词 span 拆成 `B` + `<span>UG</span>`），
   *      命中字符贴节点首/尾时，正则 lookahead/lookbehind 只看当前文本节点内部 → 误判 `B` 为独立全词。
   *      修复：命中贴节点末尾→查右邻兄弟首个可见字符、贴开头→查左邻兄弟末字符，
   *      若延续词字符(/[\p{L}\p{N}_]/u)则作废命中。"
   *   旧版对应实现：keyword-engine.js:183-234 `_crossNodeBoundaryIsWord`（v1.14.1【3】）。
   *
   *   为什么单独需要它：`Compiler.buildPattern` 的全词边界用 `(?<!词字符)…(?!词字符)`，
   *   而**节点边界处没有字符**，两侧断言天然通过 → 拆开的词会被误判成独立全词。
   *
   *   为什么不需要"拼接命中"：旧版 v1.10.x~v1.52.0 的匹配始终在**单个文本节点内**完成，
   *   `<b>关</b>键词` 本就不命中「关键词」。这是既有行为，本次重构**不对齐升级**（避免改动语义）。
   * ================================================================== */

  /** 词字符判定（唯一实现；字符类与 Compiler.buildPattern 的边界类严格一致） */
  const WORD_CHAR_RE = /[\p{L}\p{N}_]/u;
  function isWordChar(ch) { return !!ch && WORD_CHAR_RE.test(ch); }

  /**
   * 可作为"文本延续载体"的行内元素白名单。
   * 采用**白名单**而非块级黑名单：拿不准的元素一律当边界，
   * 因为"少作废一次"只是漏一个误判，"多作废一次"会让用户真词漏高亮（更糟）。
   */
  const INLINE_TAGS = new Set([
    'SPAN', 'B', 'I', 'EM', 'STRONG', 'A', 'U', 'S', 'SMALL', 'SUB', 'SUP', 'MARK',
    'CODE', 'FONT', 'LABEL', 'ABBR', 'CITE', 'Q', 'TIME', 'VAR', 'KBD', 'SAMP',
    'BDI', 'BDO', 'RUBY', 'RT', 'RP', 'DEL', 'INS', 'BIG', 'TT'
  ]);

  /** 该节点能否作为"被拆开的词的延续载体"（文本节点 / 行内元素；块级与 <br> 一律视为边界） */
  function isCarrier(node) {
    if (!node) return false;
    if (node.nodeType === 3) return !!(node.nodeValue || '').trim();
    if (node.nodeType !== 1) return false;
    if (node.tagName === 'BR') return false;                 // 换行 = 天然的词边界
    if (SKIP_TAGS.has(node.tagName)) return false;           // script/style/textarea…
    if (node.hasAttribute && node.hasAttribute(UI_ATTR)) return false;
    if (!INLINE_TAGS.has(node.tagName)) return false;         // 块级容器 → 边界
    return !!(node.textContent || '').trim();
  }

  /** 该元素当前是否**不可见**（display:none / visibility:hidden|collapse）。
   *  只用于"跨节点命中"的透明判定：不占位的元素不该把词切断。
   *  取不到计算样式时一律当"可见"（保守：不改变原有边界语义）。 */
  function isHiddenEl(el) {
    try {
      if (typeof getComputedStyle !== 'function') return false;
      const st = getComputedStyle(el);
      return st.display === 'none' || st.visibility === 'hidden' || st.visibility === 'collapse';
    } catch (e) { return false; }
  }

  /** 本身是行内元素（可被冒泡穿透），且不是插件 UI */
  function isInlineElement(el) {
    return !!(el && el.nodeType === 1 && INLINE_TAGS.has(el.tagName) &&
      !(el.hasAttribute && el.hasAttribute(UI_ATTR)));
  }

  /**
   * 在**同一层**内找该方向最近的可延续载体。
   * @returns {Node|null|undefined} 找到 → 节点；明确撞到块级/BR 边界 → null；
   *                               本层已无兄弟（可继续向上冒泡）→ **undefined**
   */
  function directCarrier(node, dir) {
    let n = dir > 0 ? node.nextSibling : node.previousSibling;
    while (n) {
      if (isCarrier(n)) return n;
      /* 空行内元素（`<span></span>` 这类）视觉上什么都不占 → **透明跳过**，
       * 与上面"全空白文本节点 → 跳过继续找"同一口径。
       * 旧实现把它当边界，于是 `审核<span></span>不通过` 既**不命中**跨节点整词，
       * 又会让全词「审核」被误判成独立词（极端场景体检实测抓到的缺口）。 */
      if (n.nodeType === 1) {
        if (isInlineElement(n) && !String(n.textContent || '').trim()) {
          n = dir > 0 ? n.nextSibling : n.previousSibling;
          continue;
        }
        return null;                       // 块级 / <br> / script → 边界，停止
      }
      n = dir > 0 ? n.nextSibling : n.previousSibling; // 全空白文本节点 → 跳过继续找
    }
    return undefined;
  }

  /**
   * 跨（行内）父级向上冒泡的延续载体查找。
   *
   * 【v2 相对旧版的增强，属"补齐漏判"而非改语义】
   *   旧版 `_nextVisibleNode/_prevVisibleNode`（keyword-engine.js:199-206）**只看同层兄弟**，
   *   因此 `关<b>键</b>词` 这种"命中被包在行内标签里"的拆词方式它判不出来
   *   （`<b>` 内的文本节点没有兄弟 → 直接返回"无延续"）→ 「键」被误判为独立全词。
   *   这属于旧版逐步实现留下的覆盖缺口。v2 沿**行内祖先链**继续向上看一层，
   *   直到撞到非行内祖先（块级容器本身就是天然边界）为止 —— 语义仍严格是
   *   "延续词字符则作废"，只是把判定范围补全。
   */
  function carrier(node, dir) {
    let cur = node;
    for (let depth = 0; cur && depth < 8; depth++) {   // 深度上限兜底，防病态 DOM 造成长链
      const found = directCarrier(cur, dir);
      if (found !== undefined) return found;           // 找到载体 或 明确边界
      const p = cur.parentElement;
      if (!isInlineElement(p)) return null;            // 父级不是行内 → 边界
      cur = p;
    }
    return null;
  }

  /** 取节点文本的首/末**可见**字符（忽略首尾空白）；isLast=true 取末字符 */
  function edgeChar(node, isLast) {
    if (!node) return '';
    const raw = node.nodeType === 3 ? (node.nodeValue || '') : (node.textContent || '');
    const t = isLast ? raw.replace(/\s+$/, '') : raw.replace(/^\s+/, '');
    if (!t) return '';
    return isLast ? t[t.length - 1] : t[0];
  }

  /**
   * 跨文本节点词边界守卫 —— 全工程唯一实现。
   * @returns {boolean} true = 该命中其实处在**被拆开的词**的首/尾，是误判，应作废
   */
  function crossNodeBoundaryIsWord(node, start, end) {
    const text = (node && node.nodeValue) || '';
    // 命中贴节点末尾 → 右邻首个可见字符若延续词字符，说明词还没结束
    if (end === text.length) {
      if (isWordChar(edgeChar(carrier(node, +1), false))) return true;
    }
    // 命中始自节点开头 → 左邻末个可见字符若延续词字符，说明词是从左边开始的
    if (start === 0) {
      if (isWordChar(edgeChar(carrier(node, -1), true))) return true;
    }
    return false;
  }

  /* ---------------- 扩展点②：ScannerProbe ---------------- */

  const probes = KH.createRegistry ? KH.createRegistry('ScannerProbe') : null;

  /* ---- 内置 Probe ①：单节点正则扫描（普通词 / 全词 / 正则的默认定位方式） ---- */
  if (probes) probes.register('node-regex', {
    order: 100,
    /**
     * **只接管"没有指定专用 Probe"的规则**（`rule.probe` 为空）。
     * 这是踩出来的：组合词规则也带 `pattern`（那是它的**核心词**模式），
     * 如果这里同时接管，就会退化成"整页扫核心词"——
     * `KW.comboLR('肝癌','诊断')` 于是把「未配标题的行」里的「肝癌」也标了出来
     * （反例 `肝癌家族史阳性` 被误命中，F04/ST-04 直接变红）。
     * 与 Adapter 的 `order` 派发对称：**规则自己声明由谁扫，内核不猜**。
     */
    applies(rule) { return !!rule.pattern && !rule.probe; },
    scan(root, rule, ctx) {
      const hits = [];
      const nodes = (ctx && ctx.nodes) || collectTextNodes(root, ctx && ctx.options);
      // 守卫通过 ctx 暴露给 Probe —— 任何自定义 Probe 都能复用，无需 import 内核
      const guard = (ctx && ctx.crossNodeBoundaryIsWord) || crossNodeBoundaryIsWord;
      const needGuard = !!(rule.flags && rule.flags.wholeWord);   // 与旧版一致：仅全词命中需守卫
      for (const node of nodes) {
        const text = node.nodeValue;
        /**
         * **必须确保有 `g`**：多命中遍历依赖 `lastIndex` 推进。
         * 缺 `g` 时 `exec` 每次都返回同一个首个匹配 —— 轻则只命中第一个词
         * （全词 + 正则多分支时"首个分支之后的词全漏"，K7 实测），重则 `while` 死循环。
         * 这里对 flags 做兜底而不是只信任上游：这个循环的正确性完全押在 `g` 上。
         */
        const reFlags = rule.pattern.flags.indexOf('g') >= 0 ? rule.pattern.flags : rule.pattern.flags + 'g';
        const re = new RegExp(rule.pattern.source, reFlags);
        let m;
        while ((m = re.exec(text)) !== null) {
          if (m[0].length === 0) { re.lastIndex++; continue; } // 防空匹配死循环
          const start = m.index, end = m.index + m[0].length;
          if (needGuard && guard(node, start, end)) continue;
          hits.push({ rule, node, start, end, text: m[0] });
        }
      }
      return hits;
    }
  });

  /* ---- 内置 Probe ②：跨文本节点（行内 run）扫描 ----
   * 【为什么需要】用户实测场景：页面为了给"不通过"上色，把「审核不通过」拆成了
   *   `审核<span style="color:#e53935">不通过</span>` 两个文本节点。单节点扫描看不到这个词，
   *   但**用户观感上它们是连着的** —— 应该命中，并且两段各自的颜色都保留。
   *
   * 【做法】用现成的 `carrier()` 把"相邻行内"的文本节点串成 run（run 内文本在视觉上连续），
   *   在 run 的拼接文本上匹配，再把 [start,end) 映射回 (node, offset)。
   *
   * 【只产出真正跨节点的命中】单节点能匹配到的一律交给 node-regex ——
   *   否则同位置会双命中（统计与备注重复计数）。这样对既有行为**完全可加**。
   *
   * 【词边界不需要额外守卫】run 是"极大连续文本"，正则的 lookbehind/lookahead 看到的就是
   *   真实相邻字符（run 两端是块级边界，那里本来就没有字符）。于是全词判定在跨节点时也自然正确：
   *   `审核<span>不通过</span>` 下全词「审核」不会命中（后面真的跟着"不"）。
   */
  if (probes) probes.register('inline-run-regex', {
    order: 90,                       // 先于 node-regex（100）
    applies(rule) { return !!rule.pattern && !rule.probe; },
    scan(root, rule, ctx) {
      const hits = [];
      const nodes = (ctx && ctx.nodes) || collectTextNodes(root, ctx && ctx.options);
      const reFlags = rule.pattern.flags.indexOf('g') >= 0 ? rule.pattern.flags : rule.pattern.flags + 'g';

      // ① 聚 run：本节点的左邻载体正好是"当前 run 的最后一个文本节点"→ 续上；否则开新 run
      //    注意 `carrier()` 跨过行内元素时返回的是**元素**（如 审<span>核</span>不通过 里的 <span>），
      //    所以判据要允许"该元素**包含**当前 run 的最后一个节点"；
      //    还要**跳过空行内元素**：`审核<span></span>不通过` 里那个空 span 视觉上什么都不显示，
      //    但它会把 run 断开 → 整词不命中（极端场景体检实测抓到的缺口）。
      const chains = (prev, lastNode, depth) => {
        if (!prev || !lastNode || (depth || 0) > 6) return false;
        if (prev === lastNode) return true;
        if (prev.nodeType === 1) {
          if (prev.contains(lastNode)) return true;               // 行内元素包着它
          /* 空元素 / **隐藏**元素：视觉上都不占位 → 透明跳过，继续往前找。
           *   `审核<span></span>不通过`     —— 空 span（极端体检 C）
           *   `审核<span display:none>XX</span>不通过` —— 隐藏 span（冷门体检 1）
           *   两者在用户眼里都是连着的 "审核不通过"，不该被当成词边界。 */
          if (!String(prev.textContent || '').trim() || isHiddenEl(prev)) {
            return chains(carrier(prev, -1), lastNode, (depth || 0) + 1);
          }
        }
        return false;
      };
      const runs = [];
      let run = null;
      for (const node of nodes) {
        /* 隐藏文本（display:none / visibility:hidden）**不参与聚 run**：
         *   `审核<span style="display:none">XX</span>不通过` 在用户眼里就是连着的"审核不通过"，
         *   隐藏的 "XX" 不该把词切断（冷门体检实测：修前整词不命中）。
         *   注意只影响"跨节点命中"这条路径 —— 普通单节点匹配照旧扫描隐藏内容，
         *   所以其它既有行为（含 el-table 分表、假表格）不受影响。 */
        if (node.parentElement && isHiddenEl(node.parentElement)) continue;
        if (run && chains(carrier(node, -1), run.nodes[run.nodes.length - 1], 0)) {
          run.nodes.push(node);
          run.text += node.nodeValue;
        } else {
          run = { nodes: [node], text: node.nodeValue };
          runs.push(run);
        }
      }

      // ② 只在**跨节点**的 run 上匹配（单节点 run 交给 node-regex）
      for (const r of runs) {
        if (r.nodes.length < 2) continue;
        const re = new RegExp(rule.pattern.source, reFlags);
        let m;
        while ((m = re.exec(r.text)) !== null) {
          if (m[0].length === 0) { re.lastIndex++; continue; }   // 防空匹配死循环
          const start = m.index, end = m.index + m[0].length;
          /* 把 [start,end) 映射成**每一段 (node, 段区间)** —— 段由本探针自己算准，
           * 下游（index/registry/renderer）直接照用，不再靠 carrier 反推节点
           * （carrier 可能返回行内**元素**，反推会踩到 nodeValue 为 null）。 */
          const segs = [];
          let acc = 0;
          for (const n of r.nodes) {
            const len = n.nodeValue.length;
            const s0 = Math.max(start, acc), e0 = Math.min(end, acc + len);
            if (e0 > s0) segs.push({ node: n, start: s0 - acc, end: e0 - acc });
            acc += len;
            if (acc >= end) break;
          }
          if (segs.length < 2) continue;                         // 实际没跨节点 → 交给 node-regex
          const first = segs[0], last = segs[segs.length - 1];
          /* `start/end` 的口径与命中模型一致：**都指起始节点内的偏移**
           * （于是 `end` ＝ 起始节点里从 start 到该段末尾），真正的终点在 endNode/endOffset。 */
          hits.push({
            rule, node: first.node, start: first.start, end: first.end,
            endNode: last.node, endOffset: last.end, segments: segs, crossNode: true, text: m[0]
          });
        }
      }
      return hits;
    }
  });

  const Scanner = {
    probes,
    collectTextNodes,
    collectShadowRoots,
    shadowRootOf,
    isOwnUI,
    UI_ATTR,

    /** 跨节点词边界守卫（内核能力，经 ctx 传给所有 Probe；不是注册点） */
    crossNodeBoundaryIsWord,

    /**
     * 供 Probe 复用的结构/文本原语。
     * 放在这里的原因：像"组合词"这种定位方式需要"按行/列找相邻单元格"这类结构遍历，
     * 但**不允许**它把逻辑写进内核文件；内核只提供原语，策略由 Probe 决定。
     * 这样新增定位方式不必改内核（meta-check #T 也会校验跨节点守卫仍单源）。
     */
    util: {
      isWordChar,
      isCarrier,
      carrier,
      edgeChar,
      crossNodeBoundaryIsWord,
      collectTextNodes,
      /** 子树内文本节点（跳过插件 UI / script / 可编辑区） */
      textNodesIn(root, options) { return collectTextNodes(root, options); }
    },

    /**
     * @param {Node} root 扫描根（整页重建传 document.body；局部增量传变更容器）
     * @param {CompiledRule[]} rules
     * @param {object} [options]
     * @returns {RawHit[]}
     */
    scan(root, rules, options) {
      const nodes = collectTextNodes(root, options);
      const ctx = {
        root,
        nodes,
        nodeSet: new Set(nodes),   // O(1) 判断"这个文本节点属于本次扫描范围"
        options: options || {},
        crossNodeBoundaryIsWord,
        util: Scanner.util
      };
      const raw = [];
      const ordered = (probes ? probes.entries() : []).sort((a, b) => (a[1].order || 999) - (b[1].order || 999));
      for (const rule of rules || []) {
        for (const [name, probe] of ordered) {
          if (probe.applies && !probe.applies(rule, ctx)) continue;
          /**
           * 单个 Probe 出错**不得影响其它 Probe / 整条管线**。
           * 这是踩过的真坑：P2 里 `rare-char` 的 `scan` 抛了一个 ReferenceError
           * （重构时把函数留在了内层作用域），结果**首次重建整条流水线直接中断**，
           * 页面上所有功能一起失效 —— 表现为"四个不相干的功能用例同时变红"，
           * 排查成本极高。注册点意味着"内核必须对注册方保持防御性"。
           */
          let hits = [];
          try {
            hits = probe.scan(root, rule, ctx) || [];
          } catch (err) {
            console.error('[KH] ScannerProbe 执行异常（已隔离，不影响其它 Probe）:', name, err);
            continue;
          }
          for (const h of hits) raw.push(h);
        }
      }
      return raw;
    }
  };

  KH.Scanner = Scanner;
})();
