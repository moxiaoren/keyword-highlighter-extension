/* ============================================================================
 * src/core/config.js · 默认值唯一真源 + 兼容读取 + 校验 + 迁移
 * ----------------------------------------------------------------------------
 * 铁律（方案 §2 第 5 条）：默认值只在本文件出现一次。
 *   · 其它任何文件不得再写第二份 defaults（旧版 lib/storage.js:17-59 即第二份，已废弃）。
 *   · 版本号**不在这里**定义 —— 版本唯一真源是 manifest.json（meta-check #1 校验）。
 *
 * 兼容策略（方案 §7.2「存量数据零改写」）：
 *   · 未知键：宽容保留（不删用户数据）。
 *   · 已废弃键：读取时忽略，写入时不再落盘（delete on write），避免每次 set 写回脏字段。
 *   · 绝不执行「组合词左右翻转」迁移（v1.8.4 已闭环），只做宽容读取。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** 已废弃的存储键（读到即忽略、写回即清除）。来源：方案 §7.1 + R7。 */
  const DEPRECATED_KEYS = [
    'noteFormat',            // 全文无使用场景
    'comboFlipped',          // 翻转迁移已闭环，仅存量兼容读取
    'pageCleanMinGap',       // 由 pageRebuildGapMs 统一取代
    'highlightStyle.defaultBorderColor',  // CSS.highlights 不支持边框
    'highlightStyle.defaultBorderWidth',
    'highlightStyle.defaultBorderRadius'  // 旧默认值含 typo 'iat::3px'
  ];

  /** 合法枚举（校验用）。非法值回退到默认，但不静默丢数据。 */
  const ENUMS = {
    'siteRules[].type': ['blacklist', 'whitelist'],
    'siteRules[].matchType': ['exact', 'subdomain', 'prefix', 'regex'],
    'siteRules[].scope': ['domain', 'url'],
    /* 变更处理方式（K58）：smart = 相关性预筛（省资源，默认）；always = 任何变动都整页重建（旧行为，最保守） */
    'changeHandling': ['smart', 'always']
  };

  const Config = {
    /** 默认值 —— 唯一真源（方案 §7.1 定稿形态） */
    defaults: {
      globalEnabled: true,

      keywords: [],
      groups: [],

      /** { type, pattern, matchType:'exact'|'subdomain'|'prefix'|'regex', scope:'domain'|'url' } */
      siteRules: [],
      /** {'example.com': true} 本地即时状态，默认不随导出分享 */
      siteDisabledMap: {},

      /** 仅背景色/文字色 —— 边框圆角已移除（CSS.highlights 不支持） */
      highlightStyle: {
        defaultBgColor: '#ff9500',
        defaultTextColor: '#000000'
      },

      noteCardStyle: {
        bgColor: '#ffffff',
        textColor: '#333333',
        borderColor: '#cccccc',
        borderWidth: '1px',
        borderRadius: '8px',
        shadow: '0 4px 12px rgba(0,0,0,0.15)',
        maxWidth: '320px',
        opacity: '0.96',
        fontSize: '14px'
      },

      importantNote: {
        imgSize: 70
      },

      /* ---- 图片文字识别（OCR）----
       * `defaultMax`：每个锚点最多识别几张图（关键词上可单独覆盖，留空即用这个默认）
       * `crossOriginSites`：{'example.com': true} 允许扩展代为读取该站点的跨域图片。
       *   默认**不开**：跨域读图等于替页面再发一次请求，必须按站点显式授权（决策留档见 changelog）。 */
      imgOcr: {
        defaultMax: 4,
        crossOriginSites: {}
      },

      matchSettings: {
        defaultCaseSensitive: false,
        defaultWholeWord: false,
        defaultUseRegex: false
      },

      shadowDOMEnabled: true,
      suspendInactiveTab: true,

      /* ---- 翻页清扫（方案 §4.3 / §14 决策留档 D4）---- */
      pageResidualClean: true,
      /** 分页点击捕获：默认关（启发式猜分页误触发率高，病根已由 CSS.highlights 根治） */
      pageCleanClick: false,

      /* ---- 整页重建兜底（方案 §4.2）---- */
      pageRebuildOnChange: true,
      /** 变更处理方式（K58）：
       *  `smart`  —— 先判相关性：与命中/抓取/图片都无关的变动不重建（省资源，默认）；
       *  `always` —— 任何页面变动都整页重建（P1/P2 之前的旧行为，最保守；静默窗口与最小间隔照旧）。
       *  留这个开关的理由：预筛的取舍是"判多只是多算一次、判漏才是事故"，
       *  但用户遇到"页面明明变了却不亮"时，需要一条能**立刻排除预筛嫌疑**的路。 */
      changeHandling: 'smart',
      /** 静默窗口：距最后一次页面变动 ≥ 此值才重建，避开高频动态页竞态 */
      pageRebuildSilentMs: 1000,
      /** 全局重建最小间隔：三条翻页通道（click / URL / 指纹轮询）共用此唯一口径（R14） */
      pageRebuildGapMs: 2000,

      /** 内容指纹采样间隔（R13）—— 仅在无 CSS.highlights 环境或极端翻页兜底时消耗 */
      pageFingerprintIntervalMs: 1000
    },

    /**
     * 深度合并：以 defaults 为骨架，用存储值覆盖。
     * 注意区别于"深拷贝 defaults"——数组/对象型存储值**整体替换**而非合并，
     * 否则用户清空 keywords 后会被默认空数组"看似正常"但 groups 残留等隐性错误掩盖。
     */
    merge(stored) {
      const out = {};
      const src = stored || {};
      for (const k of Object.keys(this.defaults)) {
        const dv = this.defaults[k];
        const sv = src[k];
        if (dv !== null && typeof dv === 'object' && !Array.isArray(dv)) {
          out[k] = Object.assign({}, dv, (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) ? sv : {});
        } else {
          out[k] = (sv === undefined) ? dv : sv;
        }
      }
      // 未知键：宽容保留，不丢用户数据
      for (const k of Object.keys(src)) {
        if (!(k in out)) out[k] = src[k];
      }
      return out;
    },

    /** 一次性清洗：丢弃废弃键、修正非法枚举、补齐关键词字段。返回 {config, changed} */
    normalize(raw) {
      const cfg = this.merge(raw);
      const changed = { deprecated: [], invalid: [] };

      // ① 废弃键
      for (const key of DEPRECATED_KEYS) {
        if (key.indexOf('.') >= 0) {
          const [head, tail] = key.split('.');
          if (cfg[head] && typeof cfg[head] === 'object' && tail in cfg[head]) {
            delete cfg[head][tail];
            changed.deprecated.push(key);
          }
        } else if (key in cfg) {
          delete cfg[key];
          changed.deprecated.push(key);
        }
      }

      // ② 站点规则枚举
      if (Array.isArray(cfg.siteRules)) {
        cfg.siteRules = cfg.siteRules.filter(r => r && typeof r.pattern === 'string' && r.pattern.length > 0);
        for (const r of cfg.siteRules) {
          if (!ENUMS['siteRules[].type'].includes(r.type)) { r.type = 'blacklist'; changed.invalid.push('type'); }
          if (!ENUMS['siteRules[].matchType'].includes(r.matchType)) { r.matchType = 'exact'; changed.invalid.push('matchType'); }
          if (r.scope !== undefined && !ENUMS['siteRules[].scope'].includes(r.scope)) { r.scope = 'domain'; changed.invalid.push('scope'); }
        }
      }

      // ②b 变更处理方式（K58）：非法值回退 smart（绝不因为一个坏值让"省资源"或"保守"两头都失效）
      if (!ENUMS['changeHandling'].includes(cfg.changeHandling)) {
        cfg.changeHandling = this.defaults.changeHandling;
        changed.invalid.push('changeHandling');
      }

      // ③ 关键词字段补齐（不改语义、不翻转）
      if (Array.isArray(cfg.keywords)) {
        cfg.keywords = cfg.keywords.map(k => {
          if (!k || typeof k !== 'object') return null;
          const o = Object.assign({}, k);
          if (o.enabled === undefined) o.enabled = true;
          if (o.caseSensitive === undefined) o.caseSensitive = cfg.matchSettings.defaultCaseSensitive;
          if (o.wholeWord === undefined) o.wholeWord = cfg.matchSettings.defaultWholeWord;
          if (o.useRegex === undefined) o.useRegex = cfg.matchSettings.defaultUseRegex;
          if (o.groupId === undefined) o.groupId = null;
          return o;
        }).filter(Boolean);
      }

      return { config: cfg, changed };
    },

    /** 从 chrome.storage 读取（宽容）。返回 {config, changed} */
    async load(area) {
      const store = (area || (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local));
      if (!store) return this.normalize({});
      const raw = await store.get(null);
      return this.normalize(raw);
    },

    /** 写回时剔除废弃键，避免脏字段循环落盘 */
    stripDeprecated(patch) {
      const out = Object.assign({}, patch);
      for (const key of DEPRECATED_KEYS) {
        if (key.indexOf('.') >= 0) continue; // 嵌套键由 normalize 处理
        if (key in out) delete out[key];
      }
      return out;
    },

    /** 供 meta-check #3「死配置扫描」使用：defaults 的扁平键路径清单 */
    keyPaths() {
      const paths = [];
      const walk = (obj, prefix) => {
        for (const k of Object.keys(obj)) {
          const v = obj[k];
          const p = prefix ? prefix + '.' + k : k;
          if (v !== null && typeof v === 'object' && !Array.isArray(v)) walk(v, p);
          else paths.push(p);
        }
      };
      walk(this.defaults, '');
      return paths;
    },

    DEPRECATED_KEYS,
    ENUMS
  };

  KH.Config = Config;
})();
