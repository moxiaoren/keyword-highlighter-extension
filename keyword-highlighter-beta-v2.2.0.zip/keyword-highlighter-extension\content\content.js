/* ============================================================================
 * content/content.js · 内容脚本入口（唯一启动点）
 * ----------------------------------------------------------------------------
 * 职责只有四件事，**不含任何业务逻辑**（铁律 §2：不许自己实现管线）：
 *   1. 调用 `KH.boot()` 启动
 *   2. 监听 storage 变化 → `KH.applyConfig()`
 *   3. 响 background 的快捷键消息（切换全局 / 切换本站 / 打开设置）
 *   4. 页面卸载时 `KH.destroy()`
 * ========================================================================= */

(function () {
  'use strict';

  if (window.__KH_CONTENT_BOOTED__) return;   // 防重复注入（all_frames + 动态注入可能叠加）
  window.__KH_CONTENT_BOOTED__ = true;

  const KH = window.KH;
  if (!KH) {
    console.warn('[KH] 核心模块未加载，内容脚本退出');
    return;
  }

  /* ---------------- ① 启动 ---------------- */

  /**
   * 就绪标记（`<html data-kh-state="on|off">`）。
   *
   * 为什么需要它：内容脚本运行在**隔离世界**，页面自己的脚本（以及 DevTools 控制台、
   * 自动化测试的主世界求值）**看不到 `window.KH`**。给整机联调 / 真浏览器回归一个
   * 主世界可见、且**不改变任何高亮行为**的观察点（这是页面 DOM 上插件留下的唯一非 UI 标记，
   * 只挂在 `documentElement` 上，不参与匹配也不影响布局）。
   * 取值：`on` = 已进入高亮态；`off` = 全局暂停 / 站点禁用 / 无可用规则。
   */
  function markState(ok) {
    try {
      document.documentElement.setAttribute('data-kh-state', ok ? 'on' : 'off');
    } catch (err) { /* documentElement 不可写时忽略 */ }
  }

  KH.boot().then((ok) => {
    markState(ok);
    console.debug('[KH] boot', ok ? '高亮态' : '未启用',
      'v' + (chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '?'),
      'build ' + (KH.BUILD_TIME || 'dev'));
  }).catch((err) => {
    markState(false);
    console.error('[KH] boot 失败', err);
  });

  /* ---------------- ② 配置热更新 ---------------- */

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      const patch = {};
      for (const k of Object.keys(changes)) patch[k] = changes[k].newValue;
      KH.applyConfig(patch).catch(err => console.error('[KH] 配置热更新失败', err));
    });
  } catch (err) {
    console.warn('[KH] storage.onChanged 不可用（扩展上下文已失效？）', err);
  }

  /* ---------------- ③ 快捷键 / 消息路由（统一协议，禁止硬编码字符串） ---------------- */

  const MSG = KH.MSG;

  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || !msg.type) return false;
      switch (msg.type) {
        case MSG.GLOBAL_CHANGED:
          KH.applyConfig({ globalEnabled: !!msg.value })
            .then(() => { markState(!!msg.value); sendResponse({ ok: true, globalEnabled: !!msg.value }); })
            .catch(e => sendResponse({ ok: false, error: String(e) }));
          return true;

        case MSG.SITE_CHANGED:
          // 「临时禁用本站」已由 background 落盘（siteDisabledMap），这里只需按新状态重评并上线/下线
          KH.boot().then(ok => { markState(ok); sendResponse({ ok: true, siteEnabled: ok }); })
            .catch(e => sendResponse({ ok: false, error: String(e) }));
          return true;

        case MSG.SITE_TOGGLE: {
          // 兜底路径：万一 background 没在跑（例如扩展刚更新过、SW 尚未唤醒），
          // 由内容脚本自己翻转本机禁用状态并落盘 —— storage.onChanged 会把状态同步到其它标签页。
          (async () => {
            try {
              const host = location.hostname;
              const { siteDisabledMap = {} } = await chrome.storage.local.get('siteDisabledMap');
              const next = !siteDisabledMap[host];
              if (next) siteDisabledMap[host] = true; else delete siteDisabledMap[host];
              await chrome.storage.local.set({ siteDisabledMap });
              const ok = await KH.boot();
              markState(ok);
              sendResponse({ ok: true, host, disabled: next, siteEnabled: ok });
            } catch (e) {
              sendResponse({ ok: false, error: String(e) });
            }
          })();
          return true;
        }

        case MSG.REBUILD_REQUEST:
          try {
            const r = KH.rebuild({ source: 'request' });
            sendResponse(Object.assign({ ok: true, type: MSG.REBUILD_DONE }, r));
          } catch (e) {
            sendResponse({ ok: false, error: String(e) });
          }
          return false;

        case MSG.EDITOR_OPEN:
          /* popup 的「＋ 快速添加」→ 在当前网页弹 1:1 编辑器。
           * 只由**顶层 frame** 响应：all_frames=true 时消息会送到每个 iframe，
           * 不守卫的话每个 iframe 都会弹一个编辑器；
           * 非顶层**不回话**（返回 false 且不调 sendResponse），让顶层那次的回执生效。 */
          if (window.top !== window) return false;
          (async () => {
            try {
              const ok = await KH.PageEditor.open(msg.keyword || null);
              sendResponse({ ok: !!ok });
            } catch (e) {
              sendResponse({ ok: false, error: String(e) });
            }
          })();
          return true;

        case MSG.STATE_QUERY:
          sendResponse({
            ok: true,
            siteEnabled: !!KH.state.siteEnabled,
            globalEnabled: !!(KH.config && KH.config.globalEnabled),
            hits: KH.registry.size,
            rules: KH.rules.length,
            version: KH.version,
            // 扩展点登记情况（诊断用；UN-06 据此验证"新功能只注册不改内核"）
            adapters: KH.Compiler ? KH.Compiler.adapters.names() : [],
            probes: KH.Scanner ? KH.Scanner.probes.names() : [],
            features: KH.features ? KH.features.names() : []
          });
          return false;

        /**
         * 命中快照（**只读诊断**，不改任何高亮行为）。
         * 为什么需要：内容脚本在隔离世界，页面主世界（DevTools 控制台 / 真浏览器自动化）
         * 看不到 `window.KH`，而"到底哪些词、在哪个节点、什么区间命中了"只有注册表知道。
         * 没有这个口子，真浏览器回归只能靠"肉眼 + 截图"，无法自动断言
         * （`tests/` 里的 Node 单测覆盖纯逻辑，几何/布局类必须真浏览器验证）。
         * `msg.fetch === true` 时附带抓取结果，便于核对抓取链路口径。
         */
        case MSG.DEBUG_HITS: {
          const fetchOn = !!(msg && msg.fetch);
          const dump = {
            total: KH.registry ? KH.registry.size : -1,
            rules: (KH.rules || []).map(r => ({
              kind: r.kind, probe: r.probe, ruleId: r.ruleId, raw: r.raw,
              label: r.meta && r.meta.label, core: r.meta && r.meta.coreRaw,
              pattern: r.pattern ? r.pattern.source : null,
              labelPattern: r.labelPattern ? r.labelPattern.source : null
            })),
            // 自检：当前页面 DOM 上出现过的全部插件属性（应只有 data-kh-ext-ui / -state / -hl-style）
            attrs: (function () {
              const seen = new Set();
              try {
                for (const el of document.querySelectorAll('*')) {
                  for (const a of Array.from(el.attributes || [])) if (a.name.indexOf('data-kh') === 0) seen.add(a.name);
                }
              } catch (e) { /* ignore */ }
              return Array.from(seen);
            })(),
            hits: (KH.registry && KH.registry.all ? KH.registry.all() : []).map(h => ({
              id: h.id,
              ruleId: h.ruleId,
              kind: h.kind,
              visual: h.visual !== false,
              textNode: h.textNode ? (h.textNode.nodeValue || '').slice(0, 60) : null,
              parentTag: h.textNode && h.textNode.parentElement ? h.textNode.parentElement.tagName : null,
              start: h.start,
              end: h.end,
              hitText: h.textNode ? (h.textNode.nodeValue || '').slice(h.start, h.end) : '',
              meta: h.meta ? {
                display: h.meta.display, label: h.meta.label, fetchLabels: h.meta.fetchLabels,
                fetchOnly: h.meta.fetchOnly, important: h.meta.important,
                importantNote: h.meta.importantNote, note: h.meta.note,
                axis: h.meta.axis, imgSize: h.meta.imgSize, impNoteBg: h.meta.impNoteBg
              } : null,
              fetchHtml: fetchOn && KH.Fetch && h.textNode
                ? (function () { try { return KH.Fetch.blockFor(h.textNode, h.meta && h.meta.fetchLabels) || ''; } catch (e) { return 'ERR:' + e.message; } })()
                : undefined
            }))
          };
          sendResponse({ ok: true, dump });
          return false;
        }

        default:
          return false;
      }
    });
  } catch (err) {
    console.warn('[KH] runtime.onMessage 不可用', err);
  }

  /* ---------------- ④ 卸载 ---------------- */

  window.addEventListener('pagehide', () => {
    try { KH.destroy(); } catch (err) { /* 页面正在销毁，忽略 */ }
  });
})();
