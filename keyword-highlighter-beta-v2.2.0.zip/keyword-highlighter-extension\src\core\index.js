/* ============================================================================
 * src/core/index.js · 门面 KH —— 全工程唯一对外 API
 * ----------------------------------------------------------------------------
 * 铁律（方案 §3.3）：options / popup / content / features **一律不许自己实现管线**，
 *   只能调这里。新增功能 = 注册扩展点，不是改内核。
 *
 * 单一管线（8 阶段，方案 §3.1）：
 *   Load ──▶ Compile ──▶ Scan ──▶ Resolve ──▶ Index ──▶ Render ──▶ Consume ──▶ Clear
 *   读配置    编译规则    扫候选     裁决重叠     建单表     唯一渲染    消费数据    唯一清理
 *
 * 与方案原文的一处顺序修正（评审记录）：
 *   原顺序写作 …Resolve → Render → Index → Consume，实现时调整为 …Resolve → **Index → Render** → Consume。
 *   原因：Range 缓存（`hit._range`）必须挂在**注册表里的同一条记录**上，否则每次重建都要重算 Range，
 *   且 RendererPlugin 无法按 id 关联视觉；把 Index 提到 Render 之前可做到"一个 Hit 对象贯穿全管线"。
 *   该调整不改变任何对外行为与验收项，仅影响阶段编号顺序。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** feature 注册表 —— 第五个注册点（管线外的数据消费方：统计 / 重要笔记 / 备注卡 / 快捷键） */
  const features = (KH.createRegistry ? KH.createRegistry('Feature') : null);
  KH.features = features;

  /**
   * 元素内第一个非空文本节点（纯结构遍历，不做任何 class/属性反查）。
   * 供 pointToRange 在 caret 落在元素上时下钻取文本；找不到（纯装饰元素/纯空白）返回 null，
   * 调用链随后的几何命中回退会接管。
   * 【v2.0.0 实测教训】此函数曾**只被调用、从未被定义** —— 平时 caret 都直接落在文本节点上，
   * 一旦落到元素（命中词边缘 / 命中文字被浮层遮住 / caret 返回宿主元素），交互定位直接抛
   * "firstTextNode is not defined"，悬停与点击在真实页面上**全部静默失效**。
   * 夹具的悬停/点击点都取在文本正中（caret 恒返文本节点），测试全绿也发现不了 ——
   * 直到 F13d 浮层夹具把这条路径踩了出来。
   */
  function firstTextNode(el) {
    try {
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
      let n;
      while ((n = walker.nextNode())) {        if (n.nodeValue && n.nodeValue.trim().length) return n;
      }
    } catch (err) { /* el 可能已脱离文档等，尽力而为 */ }
    return null;
  }

  const state = {
    config: null,
    rules: [],
    siteEnabled: false,
    booted: false
  };

  /* ---------------- 公共 API ---------------- */

  const KH_API = {
    /** 版本**不在代码里定义**，运行时读 manifest（唯一真源，见方案 §2 第 5 条 / meta-check #1） */
    get version() {
      try { return chrome.runtime.getManifest().version; } catch (e) { return '0.0.0'; }
    },

    get state() { return state; },
    get config() { return state.config; },
    get rules() { return state.rules; },

    /**
     * 定点定位 —— 交互定位的唯一入口（铁律 §2 第 3 条）。
     * 回退链（R5）：`caretPositionFromPoint`（标准） → `caretRangeFromPoint`（Chromium/Safari 私有）
     *   → **几何命中**（注册表 Range 矩形测试） → `null`。**绝不**回退到 `closest('.kh-*')` /
     *   `data-kh-*` 之类 DOM 反查。
     *
     * 旧版缺陷（keyword-engine.js:2153-2156）：只用 `caretRangeFromPoint`，无标准 API 回退，
     * 非 Chromium 内核（如 Firefox）点击定位直接失效。
     * 另一处细节：标准 API 存在但**该点返回 null**（点在空白处/元素间隙）时，
     * 旧写法会直接放弃；此处仍继续尝试私有 API，只有两条都拿不到才返回 null。
     *
     * 回退③（v2.0.0 实测补）：caret 两条 API 在真实页面上还有三类拿不到"注册表认识"的
     * 文本节点的场景 —— 命中文字被浮层盖住（element-ui 固定列 / 吸顶工具条 / 弹层，
     * caret 落在浮层上）、open Shadow 内容（caret 被重定向到宿主元素）、`user-select:none`
     * 文本。此时改用注册表里命中的 Range 做矩形命中测试（数据仍只来自注册表，无 DOM 反查）：
     * 点落在任一命中矩形的**精确范围**内 → 立即返回；否则取带 3px 容差的最近命中。
     * 仅在 caret 路径全部落空时才走这里，正常页面零开销。
     */
    pointToRange(x, y) {
      let node = null, offset = 0;

      if (document.caretPositionFromPoint) {
        try {
          const pos = document.caretPositionFromPoint(x, y);
          if (pos && pos.offsetNode) { node = pos.offsetNode; offset = pos.offset || 0; }
        } catch (err) { /* 某些内核签名不同会抛，落到下一条 */ }
      }
      if (!node && document.caretRangeFromPoint) {
        try {
          const r = document.caretRangeFromPoint(x, y);
          if (r) { node = r.startContainer; offset = r.startOffset; }
        } catch (err) { /* 同上 */ }
      }
      if (node) {
        if (node.nodeType !== 3) {
          // 落在元素上：向下取最近文本节点（纯结构遍历，不做任何 class/属性反查）
          const t = firstTextNode(node);
          if (t) { node = t; offset = Math.min(offset, node.nodeValue.length); }
        }
        if (node.nodeType === 3) return { node, offset };
      }

      /* ---- 回退③：几何命中（caret 路径全部落空才到这里） ---- */
      return this._hitByGeometry(x, y);
    },

    /**
     * 原始命中（Scanner 产出）→ 注册表记录。
     *
     * 【跨节点命中】`inline-run-regex` 探针会产出跨文本节点的命中（如 `审核<span red>不通过</span>`）：
     *   · `start/end` 仍是**起始节点内**的偏移（end ＝ 起始节点里剩下的长度）；
     *   · 真正的终点在 `endNode/endOffset`；
     *   · `segments` 是本条命中覆盖的每一段 `{node, start, end}` —— 注册表按它给**每个**节点建索引，
     *     否则鼠标点在第二段上时 `registry.query` 查不到（悬浮备注 / 点击卡片会失效）。
     * 单节点命中不带 endNode，行为与以前完全一致（向后兼容）。
     */
    _hitRecord(r, extra) {
      const rec = Object.assign({
        ruleId: r.rule.ruleId,
        textNode: r.node,
        start: r.start,
        end: r.end
      }, extra || {});
      if (r.endNode && r.endNode !== r.node) {
        rec.endNode = r.endNode;
        rec.endOffset = r.endOffset;
        rec.crossNode = true;
        /* 段由 Scanner 探针直接给出（它才算得准匹配覆盖了哪些节点）。
         * **不要**在这里用 `Scanner.util.carrier()` 反推：carrier 可能返回行内**元素**
         * （其 nodeValue 为 null），反推会抛异常 —— 实测这会让整轮重建中断、高亮全空。 */
        rec.segments = Array.isArray(r.segments) ? r.segments : [{ node: r.node, start: r.start, end: r.end }];
      }
      return rec;
    },

    /**
     * 几何命中回退：遍历注册表，用各命中的 Range 矩形做坐标命中测试。
     * Range 优先复用渲染层缓存的 `hit._range`（同一份对象，不另建第二真源）。
     * @returns {{node: Text, offset: number}|null} 返回命中的文本节点与区间起点，
     *          调用方经 `registry.query(node, offset)` 拿到同一条命中记录。
     */
    _hitByGeometry(x, y) {
      if (!KH.registry || typeof KH.registry.all !== 'function') return null;
      const TOL = 3;
      let best = null, bestDist = Infinity;
      for (const h of KH.registry.all()) {
        const tn = h.textNode;
        if (!tn || !tn.isConnected) continue;
        let range = h._range || null;
        if (!range || range.startContainer !== tn) {
          try {
            range = document.createRange();
            range.setStart(tn, Math.min(h.start, tn.nodeValue.length));
            /* 跨节点命中：终点在 endNode/endOffset，否则几何回退只量得到第一段 */
            if (h.endNode && h.endNode !== tn && h.endNode.isConnected) {
              range.setEnd(h.endNode, Math.min(h.endOffset || 0, h.endNode.nodeValue.length));
            } else {
              range.setEnd(tn, Math.min(h.end, tn.nodeValue.length));
            }
          } catch (err) { continue; }                 // 区间越界等异常：跳过该条
        }
        let rects;
        try { rects = range.getClientRects(); } catch (err) { continue; }
        for (const rc of rects) {
          if (!rc || (rc.width === 0 && rc.height === 0)) continue;
          const dx = x < rc.left - TOL ? rc.left - x : (x > rc.right + TOL ? x - rc.right : 0);
          const dy = y < rc.top - TOL ? rc.top - y : (y > rc.bottom + TOL ? y - rc.bottom : 0);
          if (dx === 0 && dy === 0) return { node: tn, offset: h.start };   // 精确包含：直接命中
          const d = dx * dx + dy * dy;
          if (d < bestDist) { bestDist = d; best = { node: tn, offset: h.start }; }
        }
      }
      return best;
    },

    /** 命中查询（配合 pointToRange 使用） */
    hitAtPoint(x, y) {
      const p = this.pointToRange(x, y);
      if (!p) return null;
      return KH.registry.query(p.node, p.offset);
    },

    /** 全量重建：唯一入口 */
    rebuild(opts) {
      return KH_API.run(opts && opts.root ? opts.root : document.body, (opts && opts.source) || 'manual');
    },

    /** 配置热更新：重新编译规则并按需重建 */
    async applyConfig(patch) {
      const merged = KH.Config.merge(Object.assign({}, state.config || {}, patch || {}));
      const normalized = KH.Config.normalize(merged).config;
      state.config = normalized;
      state.rules = KH.Compiler.compileAll(normalized);
      KH.registry.emit(KH.EVENTS.CONFIG_CHANGED, normalized);
      // 观察器/翻页通道按新配置重挂
      KH.Scheduler.setupObserver(normalized);
      KH.Scheduler.setupFingerprintWatcher(normalized);
      KH.Scheduler.setupPageClickWatcher(normalized);
      KH.Scheduler.setupVisibilityWatcher(normalized);
      return this.rebuild({ source: 'config' });
    },

    /**
     * 跑一次完整管线。
     * 注意：Rebuilder.clear 与 Registry.clear 都在 ⑧Clear 阶段成对调用，别处禁止再清。
     */
    run(root, source) {
      const t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
      const target = root || document.body;

      // ⑧ Clear（先清后建，方案 §4.2）—— 抑制窗口覆盖整个重建过程
      KH.Rebuilder.enterRebuild();
      try {
        KH.Rebuilder.clear(null, { reason: 'rebuild' });

        // ③ Scan
        // `shadow` 来自配置 `shadowDOMEnabled`（旧版默认 true）：开启时扫描器会逐层进入
        // Shadow Root 取文本 —— TreeWalker 不跨 Shadow 边界，不给这个开关就永远扫不到
        // Web Component 页面里的内容（旧版 `setupShadowDOMObserver` 的能力，不能丢）。
        const shadow = !(state.config && state.config.shadowDOMEnabled === false);
        const raw = KH.Scanner.scan(target, state.rules, { shadow });

        // ④ Resolve
        const { resolved, shadowed } = KH.Arbiter.resolve(raw);

        // ⑥ Index（先建单表，让 Range/视觉/统计共用同一条记录）
        const hl = (state.config && state.config.highlightStyle) || {};
        const created = [];
        /* 单条命中登记出错**不得中断整轮重建**（与"单个 Probe 出错不影响管线"同一原则）——
         * 实测踩过：`_hitRecord` 里一个 null.nodeValue 直接把整轮重建打挂，页面高亮全空、
         * 表现为"所有功能一起失效"，排查成本极高。这里逐条隔离。 */
        const addOne = (r, extra) => {
          try {
            const { hit, created: isNew } = KH.registry.add(KH_API._hitRecord(r, extra));
            if (isNew) created.push(hit);
          } catch (err) {
            console.error('[KH] 命中登记失败（已隔离，不影响其它命中）:', err);
          }
        };
        for (const r of resolved) {
          addOne(r, {
            kind: r.rule.kind,
            visual: r.rule.visual !== false,
            // 样式解析只在这里发生一次：规则自带 > 全局默认（唯一默认值源 = Config.defaults.highlightStyle）
            // 走兜底分支说明用的就是**全局默认文字色** → 标 textIsDefault，
            // 渲染层据此保留原网页文字色（除非与原色分不开，见 renderer 的感知判据）
            style: r.rule.style || { bgColor: hl.defaultBgColor, textColor: hl.defaultTextColor, textIsDefault: true },
            meta: Object.assign({ text: r.text }, r.rule.meta || {}),
            contentKey: r.rule.ruleId + '|' + (r.node ? r.node.nodeValue.slice(0, 32) : '') + '|' + r.start + '-' + r.end
          });
        }
        // 被裁决覆盖的命中不渲染，但仍登记（供统计/聚合/仅抓取使用）
        for (const r of shadowed) {
          addOne(r, {
            kind: r.rule.kind,
            visual: false,
            style: null,
            meta: Object.assign({ text: r.text, shadowed: true }, r.rule.meta || {}),
            contentKey: r.rule.ruleId + '|shadowed|' + r.start + '-' + r.end
          });
        }

        // ⑤ Render（唯一渲染实现；仅渲染 visual !== false 的）
        const visual = KH.registry.visualOnly().filter(h => !h.meta.shadowed);
        const rendered = KH.Renderer.render(visual);

        // ⑦ Consume（feature 统一消费，禁止各自监听 DOM）
        if (features) {
          for (const [label, feat] of features.entries()) {
            if (!feat || typeof feat.consume !== 'function') continue;
            try { feat.consume(KH.registry.all(), state.config); }
            catch (err) { console.error('[KH] feature consume 异常:', label, err); }
          }
        }

        KH.registry.emit(KH.EVENTS.HITS_CHANGED, { total: KH.registry.size, rendered: rendered.rendered, source });
        KH.registry.emit(KH.EVENTS.REBUILD_DONE, { source, ms: (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0 });
        return { total: KH.registry.size, rendered: rendered.rendered, skipped: rendered.skipped, source };
      } finally {
        KH.Rebuilder.exitRebuild(60);
      }
    },

    /** 全量下线 */
    destroy() {
      KH.Scheduler.teardownAll();
      KH.Rebuilder.clear(null, { reason: 'destroy' });
      KH.registry.emit(KH.EVENTS.HITS_CHANGED, { total: 0, rendered: 0, source: 'destroy' });
    },

    /**
     * 启动。由 content/content.js 调用，是全页唯一的启动入口。
     *
     * 【站点状态切换必须能"下线"】(旧版 content.js:59-103 `reEvaluateSite` 的语义，不得丢)
     *   同一个入口同时承担三种情形：
     *     · 首次启动
     *     · 配置变更后的重建（globalEnabled / 关键词）
     *     · **URL 变化后的站点规则重评** —— `scope:'url'` 的规则可能让本页由生效转失效（或反之），
     *       所以 URL 监听回调必须走 `boot()` 而不是直接 `rebuild()`
     *       （旧版只 rebuild 不重评 → 网址级规则中途失效时高亮残留）。
     *   因此任何提前 return 的分支都必须先 `destroy()`（上面已在入口清一次），
     *   保证"切到失效态"时页面上的高亮被收干净。
     * @returns {Promise<boolean>} 是否成功进入高亮态
     */
    async boot() {
      if (state.booted) this.destroy();
      const { config } = await KH.Config.load();
      state.config = config;
      state.rules = KH.Compiler.compileAll(config);
      state.booted = true;                 // 即使下面提前返回，也已完成一次"启动"（后续会先 destroy）

      if (config.globalEnabled === false) { state.siteEnabled = false; return false; }

      const host = location.hostname;
      state.siteEnabled = KH.SiteRules ? KH.SiteRules.shouldHighlight(host, location.href, config) : true;
      if (!state.siteEnabled) return false;
      if (!state.rules.length) return false;

      // 先建观察器再首扫：值后到的变化才在观察范围内（旧版 v1.10.11 的教训，ST-05）
      KH.Scheduler.setupObserver(config);
      // URL 变化 → **重新评估站点规则**（不是无条件 rebuild）
      KH.Scheduler.setupUrlWatcher(() => {
        KH_API.boot().catch(err => console.error('[KH] URL 变更后重评站点规则失败', err));
      });
      KH.Scheduler.setupFingerprintWatcher(config);
      KH.Scheduler.setupPageClickWatcher(config);
      KH.Scheduler.setupVisibilityWatcher(config);

      this.rebuild({ source: 'boot' });
      return true;
    }
  };

  /* 注意：必须用 defineProperties 而不是 Object.assign ——
     Object.assign 会把 getter 求值成**当时的静态快照**（读一次就定死），
     导致 `KH.rules` 在编译完成后仍返回空数组（真实踩过的坑）。 */
  Object.defineProperties(KH, Object.getOwnPropertyDescriptors(KH_API));

  /** 供 Node 单测使用（无 window 时导出到 globalThis） */
  if (typeof module !== 'undefined' && module.exports) module.exports = KH;
})();
