/* ============================================================================
 * src/ui/components/keyword-editor.js · 关键词编辑弹窗（唯一实现）
 * ----------------------------------------------------------------------------
 * R8 的核心：**同一份编辑器，options 里弹、popup 里也弹**。
 * 旧版 popup 的「＋ 快速添加」是"另开一个窗口跳设置页"（popup/popup.js:122），
 * 于是同一次操作在两端是两套交互、两套字段、两套校验 —— 这正是"功能这里有一处、
 * 那里没有"的典型来源。v2 收敛成一个 `KH.ui.openEditor()`。
 *
 * 字段不在这里声明（那会变成第二份字段表）：一律遍历 `KH.FieldMap.FORM_SECTIONS`
 * 与 `KEYWORD_FIELDS` 生成控件，因此：
 *   · 新增字段 → 只加 FieldMap 一行 → 弹窗 / popup / 批量栏 / CSV 同时生效；
 *   · 保存路径固定为 `FieldMap.toStore()` → `Store.sanitizeKeyword()` → 落盘。
 *
 * 保存前的三道闸（缺一不可，UN-08）：
 *   ① 必填校验（核心词为空时必须是"仅抓取"：有标题词 + 抓取字段）
 *   ② 判重（text + 标题词 + 组合方向，旧版 `_sameKeyword` 的键）
 *   ③ 往返校验（表单→存储→再读回，逐字段比对；不对称立刻报错而不是静默丢字段）
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));
  const ui = (KH.ui = KH.ui || {});
  const D = () => ui.dom;

  /**
   * 字段控件**已抽到共享工厂** `ui.Fields.create`（src/ui/components/fields.js）。
   *
   * 为什么要抽：分组编辑弹窗原先是手写的另一套控件，于是这边升级成
   * “开关胶囊 / 颜色胶囊 / 行内字段”之后，那边还停在“勾选框 / 旧色块”。
   * 收敛成一个工厂后，改一处 = 所有表单一起变（结构保证，不靠自觉）。
   * 字段声明的语义与 id 契约见该文件头部注释。
   */
  const control = (field, value, ctx) => ui.Fields.create(field, value, ctx);

  /**
   * @param {object} opts
   *   keyword  编辑对象（省略＝新建）
   *   cfg      当前配置
   *   mode     'options' | 'popup'
   *   onSaved  (kw) => void
   */
  function openEditor(opts) {
    const o = opts || {};
    const h = D().h;
    const fm = KH.FieldMap;
    const cfg = o.cfg || {};
    const groups = cfg.groups || [];
    const src = o.keyword || null;
    // 带 id = 编辑既有；不带 id = 新建（「复制」就是"预填但不带 id"，于是自然成为新建）
    const editing = (src && src.id) ? src : null;

    // 初值：编辑/预填＝按字段表回填；纯新建＝按字段表取默认（默认值来自 Config，不在这里写死）
    const form = src ? fm.toForm(src) : fm.defaults(cfg);

    const controls = [];
    /* 分区按 `FORM_SECTIONS[].col` 落到**独立竖列**里（见 fieldmap.js 里 col 的说明）：
     * 每列一个 flex 竖列，卡片在列内首尾相接，不再出现"同一行里矮卡片下面一大块空洞"。 */
    const cols = new Map();
    const colsBox = h('div', { class: 'kh-editor-cols' });
    const colOf = (n) => {
      if (!cols.has(n)) {
        const c = h('div', { class: 'kh-editor-col' });
        cols.set(n, c);
        colsBox.appendChild(c);
      }
      return cols.get(n);
    };

    for (const sec of fm.FORM_SECTIONS) {
      const bodyId = 'kh-sec-body-' + sec.id;
      // 分区标题做成可点击的折叠头（默认全展开）：长表单能按需收起，省得一路滚
      const headBtn = h('button', {
        class: 'kh-editor-sec-head', type: 'button',
        'aria-expanded': 'true', 'aria-controls': bodyId
      }, [
        h('span', { class: 'kh-editor-sec-chevron', text: '▾' }),
        h('span', { class: 'kh-editor-sec-title', text: sec.title }),
        h('span', { class: 'kh-editor-sec-hint', text: sec.hint })
      ]);
      const card = h('div', { class: 'kh-editor-sec', 'data-sec': sec.id }, [headBtn]);
      const bodyEl = h('div', { class: 'kh-editor-sec-body', id: bodyId });
      const headExtra = h('div', { class: 'kh-editor-sec-extra' });   // 标题行右侧插槽
      headBtn.addEventListener('click', () => {
        const closed = card.classList.toggle('is-collapsed');
        headBtn.setAttribute('aria-expanded', closed ? 'false' : 'true');
        headBtn.querySelector('.kh-editor-sec-chevron').textContent = closed ? '▸' : '▾';
      });
      /* `head: true` 的字段渲染到**标题行右侧**（如「启用」）：
       *   · 正文里不用为它单独占一行（用户实测："放右上角避免占空间"）；
       *   · 它不能塞进 `headBtn` 内部 —— 按钮里嵌交互控件既不合法、点一下还会顺带折叠分区，
       *     所以插槽是 headBtn 的**兄弟**，折叠热区只覆盖标题本身。
       * 正文排布（胶囊成行 / 竖线分隔 / 半行整行流式）统一交给 `ui.Fields.layout`，
       * 与分组弹窗共用同一份实现 —— 免得两边各写一套悄悄漂移。 */
      const headFields = [], bodyItems = [];
      for (const f of fm.fieldsOf(sec.id)) {
        const c = control(f, form[f.key], { groups, imgSize: form.imgSize, onChange: () => { /* 联动在下面按需处理 */ } });
        controls.push(c);
        if (f.head) headFields.push({ spec: f, ctrl: c });
        else bodyItems.push({ spec: f, ctrl: c });
      }
      for (const it of headFields) headExtra.appendChild(it.ctrl.el);
      ui.Fields.layout(bodyItems, bodyEl);
      card.appendChild(bodyEl);
      // 标题行 = 折叠按钮 + 右侧插槽（无插槽时不渲染，保持原样）
      if (headExtra.childNodes.length) {
        card.insertBefore(h('div', { class: 'kh-editor-sec-headrow' }, [headBtn, headExtra]), bodyEl);
        headBtn.classList.add('is-in-row');
      }
      colOf(Number(sec.col) || 1).appendChild(card);
    }
    const grid = colsBox;   // 后面的联动/查询都按 `grid.querySelector` 走，语义不变

    const byKey = (k) => controls.find(c => c.key === k) || null;

    // ---- 组合方向联动：只改「显示文案」，字段值一律不动（保存路径完全不受影响）----
    // 文案来自 FieldMap.axisLabels（单一来源），因此这里只是"贴文案"，不是第二张字段表。
    const comboCard = grid.querySelector('.kh-editor-sec[data-sec="combo"]');
    const comboHint = comboCard ? comboCard.querySelector('.kh-editor-sec-hint') : null;
    const axisCtl = byKey('comboAxis');
    let axisNote = null;
    if (comboCard) {
      // 「勾了组合却没填标题词」是最常见的"看起来没生效"来源，用一行提示说清楚（文案随方向变）
      axisNote = h('div', { class: 'kh-editor-axis-note' });
      comboCard.querySelector('.kh-editor-sec-body').appendChild(axisNote);
    }
    function applyAxisLabels() {
      const com = byKey('cellVerify');
      const raw = com && com.el.querySelector('.kh-fld-label');
      if (raw) raw.dataset.baseLabel = raw.dataset.baseLabel || raw.textContent;   // 首次进入时留底，避免二次叠加
      const lb = fm.axisLabels(axisCtl ? axisCtl.read() : 'lr');
      if (raw) raw.textContent = lb.cellVerify + (raw.dataset.baseLabel.indexOf('*') >= 0 ? ' *' : '');
      const mode = byKey('cellVerifyMatchMode');
      if (mode) {
        /**
         * 「全词」这一项的精确含义随方向走：左右格 = 整词精确；上下格 = 整格相等。
         * 它现在渲染成**胶囊**（与表格列同一套说法，标签固定「全词」），
         * 所以这层方向差异落到胶囊的 tooltip 上，而不是可见文案 —— 可见文案必须与表格列一致。
         */
        const exactText = (lb.cellVerifyMatchMode === '列词匹配') ? '整词精确（整格相等）' : '整词精确';
        const chip = mode.el.classList && mode.el.classList.contains('kh-fld-chip') ? mode.el : null;
        if (chip) {
          chip.title = exactText;
        } else {
          const sel = mode.el.querySelector('select');
          const opts = sel ? sel.options : [];
          for (const op of opts) if (op.value === 'exact') op.textContent = exactText;
        }
      }
      if (comboHint) comboHint.textContent = lb.hint;
      if (axisNote) {
        // 只在"填了标题词但没启用组合"时提醒：这正是用户觉得"配了没反应"的场景
        const on = !!(byKey('cellVerifyEnabled') && byKey('cellVerifyEnabled').read());
        const hasTitle = !!(com && String(com.read() || '').trim());
        axisNote.hidden = !(!on && hasTitle);
        axisNote.textContent = axisNote.hidden ? '' : ('这份「' + lb.cellVerify + '」当前不会生效：请勾上本节顶部的「启用组合」。');
      }
    }
    if (axisCtl) {
      const sel = axisCtl.el.querySelector('select');
      if (sel) sel.addEventListener('change', applyAxisLabels);
    }
    applyAxisLabels();

    // 组合词联动：未勾选"启用组合"时，标题词相关字段不可用（避免留下半截状态）
    const enableCtl = byKey('cellVerifyEnabled');
    function syncCombo() {
      const on = enableCtl && enableCtl.read();
      for (const key of ['cellVerify', 'comboAxis', 'cellVerifyMatchMode', 'cellVerifyCaseSensitive', 'cellVerifyUseRegex', 'cellOffset']) {
        const c = byKey(key);
        if (!c) continue;
        c.el.classList.toggle('is-disabled', !on);
        for (const inp of c.el.querySelectorAll('input, select, textarea, button')) inp.disabled = !on;
      }
      applyAxisLabels();
    }
    if (enableCtl) {
      const cb = enableCtl.el.querySelector('input');
      if (cb) cb.addEventListener('change', syncCombo);
      syncCombo();
    }

    /** 汇总当前表单值 */
    function readForm() {
      const out = {};
      for (const c of controls) out[c.key] = c.read();
      return out;
    }

    const errBox = h('div', { class: 'kh-editor-err' });
    errBox.hidden = true;
    const wrap = h('div', { class: 'kh-editor' }, [grid, errBox]);

    function fail(msg) {
      errBox.textContent = msg;
      errBox.hidden = false;
      return false;
    }

    const modal = ui.Modal.open({
      title: editing ? '编辑关键词' : '添加关键词',
      body: wrap,
      /* 尺寸：popup 里（800×600 上限）只能用 sm；**页面模式**（popup 的「快速添加」委托给
       * 当前网页，见 src/features/page-editor.js）与 options 一样用 lg 三列 —— 这才是"1:1"。 */
      size: (o.mode === 'popup') ? 'sm' : 'lg',
      /* 挂载点：页面模式传 ShadowRoot，样式与 DOM 都活在 shadow 里，不污染页面 */
      mount: o.mount || null,
      bare: !!o.bare,          // 独立窗口里只留内容（去掉遮罩与标题行）
      /* 关闭回调：独立编辑窗口（popup/editor.html）靠它在自己关掉后收起窗口 */
      onClose: o.onClose || null,
      saveLabel: editing ? '保存' : '添加',
      onSave: async () => {
        errBox.hidden = true;
        const raw = readForm();

        // ③ 先跑往返校验：字段表若不对称，这里就会炸出来（而不是等用户发现"某个字段没存上"）
        const rt = fm.roundTrip(Object.assign({}, form, raw), cfg);
        if (!rt.ok) return fail('字段映射异常（请把下面这行反馈给开发者）：' + rt.diffs.join('；'));

        const kw = KH.Store.sanitizeKeyword(Object.assign({}, form, raw, { id: form.id }), cfg);

        // ① 必填：核心词为空时，必须构成"仅抓取"（有标题词 + 抓取字段），否则等于没配
        const text = String(kw.text || '').trim();
        const fetchOnly = !!(kw.cellVerifyEnabled && kw.cellVerify && !text && String(kw.fetchLabels || '').trim());
        if (!text && !fetchOnly) {
          return fail(kw.cellVerifyEnabled && kw.cellVerify
            ? '核心词为空：若要「仅抓取」，请同时填写「抓取后续字段」'
            : '请填写关键词（核心词）');
        }
        kw.fetchOnly = fetchOnly;
        if (text === KH.Store.RARE_KEYWORD) kw.kind = 'rare';

        // ② 判重：编辑自身不算重复
        const list = (cfg.keywords || []).filter(k => k && (!editing || k.id !== editing.id));
        const dup = KH.Store.findDup(list, kw);
        if (dup) return fail(KH.Store.dupMessage(kw));

        const saved = await KH.Store.upsertKeyword(Object.assign(kw, { id: editing ? editing.id : kw.id }), cfg);
        D().toast(editing ? '已保存' : '已添加「' + (text || kw.cellVerify) + '」', 'ok');
        if (typeof o.onSaved === 'function') o.onSaved(saved);
        return true;
      }
    });

    return modal;
  }

  ui.openEditor = openEditor;
  ui.KeywordEditor = { openEditor, control };
})();
