/* ============================================================================
 * options/options.js · 设置页逻辑
 * ----------------------------------------------------------------------------
 * 统一化约定（这就是"后续相关功能调用都统一"的落点）：
 *   · 读写配置 → 一律 `KH.Store.*`（不自己拼 chrome.storage 键名，不自己写默认值）
 *   · 字段映射 → 一律 `KH.FieldMap`（弹窗 / 批量栏 / CSV 同一份字段表）
 *   · 弹窗     → 一律 `KH.ui.Modal` / `KH.ui.openEditor`（底栏固定、Esc 关闭）
 *   · 版本号   → 一律 `chrome.runtime.getManifest()`（不从存储读）
 *   · 更新日志 → 一律 `window.CHANGELOG`（单源 src/ui/changelog.js）
 * 内容脚本侧无需接收"刷新"消息：写 storage 后由 `chrome.storage.onChanged`
 * 自动热更新（见 content/content.js）。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = window.KH;
  const ui = KH.ui;
  const D = ui.dom;
  const { h, clear } = D;
  /** 字段表：全页唯一的字段声明来源（src/ui/fieldmap.js）。**必须放在 KH 之后** ——
   *  放到 KH 之前会踩 TDZ（`Cannot access 'KH' before initialization`），整个设置页白屏。 */
  const fm = KH.FieldMap;
  /** 注意：这里是 **getElementById** 语义（写 id 不带 #）；要写选择器请用 document.querySelector */
  const $ = (id) => document.getElementById(id);

  let cfg = null;            // 当前配置（KH.Store.load() 的结果）
  let table = null;          // 关键词表格实例
  let filtered = [];         // 当前筛选后的关键词
  let selection = new Set(); // 选中的关键词 id
  let updating = false;      // 自己写入 → storage 事件回环抑制

  /* ==================================================================== 工具 */

  const groupOf = (id) => (cfg.groups || []).find(g => g && g.id === id) || null;

  /** 关键词"实际生效底色"＝分组色 > 词色 > 全局默认（与内核 resolveVisual 同序） */
  function effectiveBg(kw) {
    const g = groupOf(kw.groupId);
    return (g && g.bgColor) || kw.bgColor || cfg.highlightStyle.defaultBgColor || '';
  }
  function effectiveImportant(kw) {
    const g = groupOf(kw.groupId);
    return !!(kw.important || (g && g.important));
  }
  function typeOf(kw) {
    if (kw.kind === 'rare' || String(kw.text || '').trim() === KH.Store.RARE_KEYWORD) return 'rare';
    if (kw.cellVerifyEnabled && kw.cellVerify) {
      if (!String(kw.text || '').trim() && String(kw.fetchLabels || '').trim()) return 'fetch';
      return (kw.comboAxis === 'tb') ? 'tb' : 'lr';
    }
    return 'plain';
  }

  /** 写 storage → 重新载入 → 重绘（唯一入口，避免各处各写一遍）
   *  写失败**必须说出口**：配额顶满 / 存储被禁用时旧写法让异常逃逸成 unhandled rejection
   *  （用户零提示），而界面已经按"写成功"的假设重渲染（C7 F-1）。 */
  async function mutate(fn) {
    updating = true;
    try {
      await fn();
      cfg = await KH.Store.load();
      renderAll();
      return true;
    } catch (err) {
      D.toast('保存失败：' + ((err && err.message) || err), 'error');
      try { cfg = await KH.Store.load(); renderAll(); } catch (e2) { /* 读也失败：保持现状 */ }
      return false;
    } finally {
      updating = false;
    }
  }

  async function reload() { cfg = await KH.Store.load(); renderAll(); }

  /* ==================================================================== 顶部 / 页脚 */

  function renderHeader() {
    const m = chrome.runtime.getManifest();
    $('version').textContent = 'v' + m.version;
    // 侧边栏底部的版本徽标：同样动态读 manifest（单一真源，绝不写版本字面量）
    $('sidebar-version').textContent = 'v' + m.version;
    $('ver-help').textContent = m.version;
    $('ver-build').textContent = (window.KH && window.KH.BUILD_TIME) || 'dev';
    $('foot-version').textContent = 'v' + m.version + ' · build ' + ((window.KH && window.KH.BUILD_TIME) || 'dev');

    const on = cfg.globalEnabled !== false;
    $('head-state').textContent = on ? '高亮已开启' : '已暂停';
    $('btn-toggle-global').textContent = on ? '暂停高亮' : '恢复高亮';
    updateSiteButton();
  }

  /**
   * 「当前站点开关」必须反映**当前站点**的状态 —— 固定文案"当前站点开关"会让它看起来
   * 像个不知道干嘛的按钮，和旁边的状态文字语义打架（用户审查 UI 时指出的那类问题）。
   * 状态来自内容脚本协议（与 popup 同一通道）；当前页没有内容脚本（chrome:// 等）时如实说明。
   */
  async function updateSiteButton() {
    const btn = $('btn-site-toggle');
    let host = '';
    let siteOn = null;   // true=高亮中 / false=已禁用 / null=未知（无内容脚本）
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url) { try { host = new URL(tab.url).hostname || ''; } catch (_) { host = ''; } }
      if (tab && tab.id != null) {
        try {
          const st = await chrome.tabs.sendMessage(tab.id, { type: KH.MSG.STATE_QUERY });
          if (st && st.siteEnabled != null) siteOn = !!st.siteEnabled;
        } catch (_) { /* 该页没有内容脚本 */ }
      }
    } catch (_) { /* tabs 查询不可用 */ }
    const tag = host.length > 24 ? host.slice(0, 23) + '…' : host;
    btn.textContent = siteOn === null
      ? '本站开关（当前页不适用）'
      : (siteOn ? '本站：高亮中' + (tag ? ' · ' + tag : '')
                : '本站：已禁用' + (tag ? ' · ' + tag : ''));
    /* 2.0.8.11 C4 真 bug 修复：这一页没有内容脚本时按钮**必须真的禁用**。
     * 旧写法只改文案、按钮仍可点 —— 点了 SITE_TOGGLE 会走到后台用 `sender.tab.url`
     * 兜底，而在设置页里那正是 options.html（chrome-extension://…），于是把
     * **扩展自己的 id 写进 siteDisabledMap**，等于给自己加了一条永远无关的"禁用站点"。 */
    btn.disabled = (siteOn === null);
    btn.title = siteOn === null
      ? '当前页不是可高亮的网页（新标签页、扩展页面、chrome:// 等），没有本站开关'
      : (siteOn ? '点一下禁用本站高亮' : '点一下恢复本站高亮');
  }

  $('btn-toggle-global').addEventListener('click', async () => {
    // 一律走统一协议，由 background 落盘 + 广播（不自己写 globalEnabled）
    const res = await chrome.runtime.sendMessage({ type: KH.MSG.GLOBAL_TOGGLE });
    if (res && res.ok === false) D.toast('切换失败：' + res.error, 'error');
    await reload();
  });

  $('btn-site-toggle').addEventListener('click', async () => {
    if ($('btn-site-toggle').disabled) return;   /* 兜底：按钮已在 updateSiteButton 里真禁用 */
    const res = await chrome.runtime.sendMessage({ type: KH.MSG.SITE_TOGGLE });
    if (res && res.ok) D.toast(res.disabled ? ('已临时禁用 ' + res.host) : ('已恢复 ' + res.host), 'ok');
    else D.toast('无法解析当前标签页地址', 'error');
    await reload();
  });

  /* ==================================================================== ① 关键词管理 */

  const COLUMNS = [
    { key: '__check', class: 'col-check' },
    {
      key: 'text', class: 'col-kw', label: '关键词', sortable: true, width: 150,
      render(kw) {
        const txt = String(kw.text || '').trim() || (typeOf(kw) === 'fetch' ? '（仅抓取）' : '—');
        const box = h('div', { class: 'kh-kw-cell' });
        box.appendChild(h('span', { class: 'kh-kw-text', text: txt }));
        if (typeOf(kw) === 'rare') box.appendChild(h('span', { class: 'mr-chip mr-chip-rare', text: '罕见' }));
        /* 【为什么这里不再打「上下格」标签】用户实测："上下格匹配是在核心关键词增加一个上下格，
         * 左右格又没有区分 —— 这种区分方式有点怪"。方向是**这一对怎么写**的属性，
         * 挂在核心词上既不对称、也不是它自己的属性；现在统一挪到「标题词」列做前缀箭头
         * （见下面 cellVerify 列），核心词这一列只留"这个词本身是什么"的信息（如「罕见」）。 */
        return box;
      }
    },
    {
      key: 'match', class: 'col-kw-match', label: '核心词匹配', width: 104,
      title: '点击修改核心词匹配方式（在弹窗中勾选，保存即生效）',
      render(kw) {
        // 匹配规则以「胶囊 + 点开小弹窗」呈现（旧版 .kw-match-pill / .mr-chip 交互，保留）
        return ui.MatchChip.create({
          part: 'core',
          rare: typeOf(kw) === 'rare',
          value: kw,
          onChange: (patch) => mutate(() => KH.Store.patchKeywords([kw.id], () => patch))
        });
      }
    },
    {
      /* 【列名去掉"(左格)"】用户实测指出："标题词（左格）事实上，上下匹配也是这里展示" ——
       * 这一列同时承载左右格的标题词与上下格的表头词，写死"(左格)"是错的表述。
       * 方向改由**前缀箭头**表达（见 render），一眼就能区分两种组合方式。 */
      key: 'cellVerify', class: 'col-cell', label: '标题关键词', sortable: true, width: 124,
      title: '单元格组合的标题词：左右格模式下是左格标题，上下格模式下是表头列名（前缀箭头标方向：← 左格 / ↑ 表头）',
      render(kw) {
        const v = String(kw.cellVerify || '').trim();
        if (!v) return h('span', { class: 'kh-dim', text: '—' });
        const tb = kw.comboAxis === 'tb';
        /* 箭头语义：标题词**在哪个方位** —— ← 左格（左右格模式）/ ↑ 表头（上下格模式）。
         * 与核心词列解耦：方向属于"这一对"，不属于核心词自己。 */
        const arrow = h('span', {
          class: 'kh-axis-arrow' + (tb ? ' is-tb' : ''),
          text: tb ? '↑' : '←',
          title: tb ? '上下格：这个词是表头列名，核心词命中其下数据行的任意一行即算命中'
            : '左右格：这个词是左格标题，右侧单元格须含核心词'
        });
        return h('span', { class: 'kh-cell-label' }, [arrow, h('span', { text: v })]);
      }
    },
    {
      key: 'titleMatch', class: 'col-title-match', label: '标题词匹配', width: 104,
      title: '点击修改标题词匹配方式（需勾选「单元格组合」，在弹窗中勾选）',
      render(kw) {
        if (!(kw.cellVerifyEnabled && kw.cellVerify)) return h('span', { class: 'kh-dim', text: '—' });
        return ui.MatchChip.create({
          part: 'title', value: kw,
          onChange: (patch) => mutate(() => KH.Store.patchKeywords([kw.id], () => patch))
        });
      }
    },
    {
      key: 'imp', class: 'col-impnote', label: '重要笔记', width: 78,
      render(kw) {
        if (!effectiveImportant(kw)) return h('span', { class: 'kh-dim', text: '—' });
        const g = groupOf(kw.groupId);
        const fromGroup = !kw.important && g && g.important;
        return h('span', {
          class: 'imp-badge', text: '📌 重要',
          title: fromGroup ? ('由分组「' + (g.name || '') + '」标记为重要') : '该关键词标记为重要'
        });
      }
    },
    {
      /* 高亮颜色：**与编辑弹窗同形** —— 两个颜色胶囊（`●底` / `●文`），
       * 各点各开选色浮层、选完即落库（不用进编辑弹窗）。
       * 色点显示的是**有效色**（分组色 > 自身色 > 全局默认），
       * `is-on` 则表示"这个词自己设了色"（否则是继承来的）—— 两者信息都不丢，各在 tooltip 里写明。 */
      key: 'color', class: 'col-color', label: '高亮颜色', width: 104,
      render(kw) {
        const g = groupOf(kw.groupId);
        const bgEff = effectiveBg(kw);
        const fgEff = (g && g.textColor) || kw.textColor || cfg.highlightStyle.defaultTextColor;
        const fromGroupBg = !!(g && g.bgColor && !kw.bgColor);
        const fromGroupFg = !!(g && g.textColor && !kw.textColor);
        const box = h('span', { class: 'kh-row-ops' });

        const mk = (field, label, eff, own, fromGroup) => {
          const c = ui.ColorField.chip({
            label: label, dot: eff, on: !!own,
            title: label + '：' + (eff || '未设色')
              + (fromGroup ? '（继承分组「' + (g.name || '未命名') + '」）' : (own ? '（本词已设）' : '（跟随全局默认）'))
          });
          let pop = null;
          let committed = false;                 // 是否点过「确定」（决定关浮层时要不要还原色点）
          const original = kw[field] || '';
          const revertDot = () => {              // 还原色点：自己设过色 → 显示该色；否则显示继承来的有效色
            c.setValue(original);
            if (!original) c.setDot(eff);
          };
          c.el.addEventListener('click', (e) => {
            e.stopPropagation();
            pop = ui.Popover.open(c.el, ui.ColorField.panel({
              value: original,
              fallback: eff,          // 未设色时取色器从"继承来的有效色"起步
              /* 草稿预览：只更新色点，**不落库**；真正的落库在「确定」（onChange）。
               * 这样"拖动一半"或"点开看看"都不会改到配置（用户实测要求：加确认步骤）。 */
              onInput: (v) => {
                if (v) c.setValue(v);
                else { c.setValue(''); c.setDot(eff); }
              },
              onChange: (v) => {
                committed = true;
                c.setValue(v);
                if (!v) c.setDot(eff);
                mutate(() => KH.Store.patchKeywords([kw.id], () => ({ [field]: v })));
              },
              onDone: () => { if (pop) pop.close(); }        // 确定 / 取消都收浮层
            }), () => { if (!committed) revertDot(); });      // Esc / 点外面关掉 → 草稿丢弃，色点还原
          });
          return c.el;
        };

        box.appendChild(mk('bgColor', '底', bgEff, kw.bgColor, fromGroupBg));
        box.appendChild(mk('textColor', '文', fgEff, kw.textColor, fromGroupFg));
        return box;
      }
    },
    {
      key: 'group', class: 'col-group', label: '分组', sortable: true, width: 96,
      render(kw) {
        const g = groupOf(kw.groupId);
        return g ? h('span', { class: 'kh-group-tag', text: g.name || '(未命名)' })
          : h('span', { class: 'kh-dim', text: '—' });
      }
    },
    {
      key: 'note', class: 'col-note', label: '备注', sortable: true, width: 150,
      render(kw) {
        const t = String(kw.note || '').trim();
        return t ? ui.RichText.render(t, 'kh-note-cell') : h('span', { class: 'kh-dim', text: '—' });
      }
    },
    {
      key: 'status', class: 'col-status', label: '状态', width: 72,
      render(kw) {
        const on = kw.enabled !== false;
        const btn = h('button', {
          class: 'kh-switch-btn ' + (on ? 'is-on' : ''), type: 'button',
          /* 文案用「启用 / 停用」——与 v1.52.0 的胶囊口径一致，
           * 也跟同页其它地方（「点击停用」「批量 停用」）一致；原先的「已启用/已停用」是 v2 自己加长的。 */
          text: on ? '启用' : '停用', title: on ? '点击停用' : '点击启用'
        });
        btn.addEventListener('click', () => mutate(() => KH.Store.patchKeywords([kw.id], () => ({ enabled: !on }))));
        return btn;
      }
    },
    {
      /* 操作列：只剩 编辑 / 删除。
       * 「复制」已按用户要求去掉 —— v1.52.0 的操作列本来就只有 ✏️编辑 / 🗑️删除，
       * 复制是 v2 多加的；按钮样式也改成胶囊（见 options.css 的 .kh-link-btn）。
       * 列宽给到 112：两个胶囊各 ~46px + 间距 6 = 98，单元格内边距 16 → 需要 114 里的 ~98。
       * 原先的 96 正好卡在边界上（实测 78 = 78），换个字体/DPI 就会出问题
       * —— 布局不能靠"恰好装得下"，得留余量（见 设计偏好.md 第 4 条）。 */
      key: 'actions', class: 'col-actions', label: '操作', width: 112,
      render(kw) {
        const box = h('span', { class: 'kh-row-ops' });
        const edit = h('button', { class: 'kh-link-btn', type: 'button', text: '编辑' });
        const del = h('button', { class: 'kh-link-btn kh-link-danger', type: 'button', text: '删除' });
        edit.addEventListener('click', () => openKeyword(kw));
        del.addEventListener('click', () => removeKeywords([kw.id], '关键词「' + (String(kw.text || '').trim() || kw.cellVerify || '') + '」'));
        box.appendChild(edit); box.appendChild(del);
        return box;
      }
    }
  ];

/** 筛选条件在**一次重绘**里只读一次：以前每个关键词都要 4~5 次 getElementById（上千条 = 上万次 DOM 查询）。 */
  function readFilters() {
    return {
      q: ($('kw-search').value || '').trim().toLowerCase(),
      g: $('kw-filter-group').value,
      st: $('kw-filter-status').value,
      ax: $('kw-filter-axis').value
    };
  }

  function passFilter(kw, f) {
    const cur = f || readFilters();
    if (cur.q) {
      const hay = [kw.text, kw.cellVerify, kw.note, kw.importantNote, kw.fetchLabels]
        .map(v => String(v || '').toLowerCase()).join('\n');
      if (hay.indexOf(cur.q) < 0) return false;
    }
    const g = cur.g;
    if (g === '__none__') { if (kw.groupId) return false; }
    else if (g && kw.groupId !== g) return false;

    const st = cur.st;
    if (st === 'on' && kw.enabled === false) return false;
    if (st === 'off' && kw.enabled !== false) return false;

    const ax = cur.ax;
    if (ax && typeOf(kw) !== ax) return false;
    return true;
  }

  /**
   * 筛选栏「排序」的**唯一**实现（最近更新 / 最近添加 / 名称 A→Z / 名称 Z→A）。
   * `sortPref` 记在本页内存里：存储变化、批量操作都会触发整页重绘，
   * 只读 <select> 的话，用户刚选的排序会在下一次重绘时"悄悄回退成默认"。
   * 名称排序用 localeCompare('zh')：中文按拼音、英文按字母，混排不会退化成"按码点"。
   */
  const SORT_VALUES = ['updated-desc', 'created-desc', 'text-asc', 'text-desc'];
  let sortPref = SORT_VALUES[0];

  function sortState() {
    const v = ($('kw-filter-sort') || {}).value;
    if (SORT_VALUES.indexOf(v) >= 0) { sortPref = v; return v; }
    return SORT_VALUES.indexOf(sortPref) >= 0 ? sortPref : SORT_VALUES[0];
  }

  function createSortSpec() {
    const s = sortState();
    return {
      apply(a, b) {
        if (s === 'text-asc' || s === 'text-desc') {
          const dir = (s === 'text-asc') ? 1 : -1;
          const ta = String(a.text || '').trim() || String(a.cellVerify || '').trim();
          const tb = String(b.text || '').trim() || String(b.cellVerify || '').trim();
          const byName = ta.localeCompare(tb, 'zh');
          if (byName !== 0) return byName * dir;
          return (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0);   // 同名词按更新时间兜底，顺序才稳定
        }
        const key = (s === 'created-desc') ? 'createdAt' : 'updatedAt';
        return (Number(b[key]) || 0) - (Number(a[key]) || 0);
      }
    };
  }

  function renderKeywordTable() {
    const sel = $('kw-filter-group');
    const cur = sel.value;
    clear(sel);
    sel.appendChild(h('option', { value: '', text: '全部分组' }));
    sel.appendChild(h('option', { value: '__none__', text: '未分组' }));
    for (const g of cfg.groups || []) sel.appendChild(h('option', { value: g.id, text: g.name || '(未命名)' }));
    sel.value = (cur && Array.from(sel.options).some(o => o.value === cur)) ? cur : '';

    const f = readFilters();
    filtered = (cfg.keywords || []).filter((kw) => passFilter(kw, f));
    // 选中集合只保留仍存在的 id（避免"删掉不可见的选中项"或删完残留计数）
    const alive = new Set((cfg.keywords || []).map(k => k.id));
    for (const id of Array.from(selection)) if (!alive.has(id)) selection.delete(id);

    const total = (cfg.keywords || []).length;
    $('kw-count').textContent = '共 ' + total + ' 条' + (filtered.length !== total ? '（筛出 ' + filtered.length + ' 条）' : '');

    if (!table) {
      table = ui.DataTable.create({
        columns: COLUMNS,
        rows: filtered,
        pageSize: 50,
        filterSort: createSortSpec(),
        getRowId: (kw) => kw.id,
        emptyText: total ? '没有符合筛选条件的关键词' : '还没有关键词，点筛选栏「＋ 添加」开始',
        onSelectionChange(sel2) { selection = sel2; syncBatchBar(); }
      });
      $('kw-table').appendChild(table.el);
    } else {
      table.setFilterSort(createSortSpec());
      table.setRows(filtered);
      table.setSelected(selection);
    }
    toggleKeywordGuide(total === 0);
    syncBatchBar();
  }

  /**
   * 【2.0.8.12 需求·长任务的进度与取消】
   *
   * 批量删 300 条、批量改 300 条时，旧实现是一次性丢给 Store，页面在几秒里没有任何反馈，
   * 用户只能等（还以为卡死），也没法中途停手。
   *
   * 这里把「可分批」的写操作切成小批，右下角显示「已处理 N/M」，随时可以点取消：
   *   · 取消后**已经写进去的批次保留**（写操作不可回滚，硬说"已撤销"才是骗人），
   *     文案如实写「已取消：完成 N 条，剩余未处理」；
   *   · 单批失败不中断整体，最后把第一处错误原文报出来（不吞异常）。
   * 返回 { done, failed, cancelled, error }，调用方据此决定 toast 文案。
   */
  async function runLongTask(label, total, step) {
    const bar = h('div', { class: 'kh-progress-fill' });
    const num = h('span', { text: '0/' + total });
    const cancelBtn = h('button', { class: 'kh-btn', type: 'button', text: '取消' });
    const box = h('div', { class: 'kh-progress', role: 'status', 'aria-live': 'polite' }, [
      h('div', { class: 'kh-progress-label', text: label }),
      h('div', { class: 'kh-progress-bar' }, [bar]),
      h('div', { class: 'kh-progress-foot' }, [num, cancelBtn])
    ]);
    let cancelled = false;
    let busy = false;
    cancelBtn.addEventListener('click', () => {
      if (busy) return;                 // 正在写的那一批要让它写完，半批写一半更糟
      cancelled = true;
      cancelBtn.disabled = true;
      cancelBtn.textContent = '正在停止…';
    });
    document.body.appendChild(box);
    let done = 0;
    let failed = 0;
    let firstErr = null;
    for (let i = 0; i < total && !cancelled; i++) {
      busy = true;
      try { await step(i); done++; } catch (err) { failed++; if (!firstErr) firstErr = err; }
      busy = false;
      bar.style.width = Math.round((i + 1) / total * 100) + '%';
      num.textContent = (i + 1) + '/' + total;
      /* 让出一帧：否则整段同步跑完，进度条和取消按钮都来不及画出来 */
      await new Promise((r) => setTimeout(r, 0));
    }
    box.remove();
    return { done: done, failed: failed, cancelled: cancelled, error: firstErr };
  }

  /** 关键词表为空时的三步引导。表体自带一句短提示，这里补「怎么真正开始」，
   *  两条并排会重复 ⇒ 短提示只在「有数据但筛空了」时出现（`emptyText` 已按 total 分支）。 */
  function toggleKeywordGuide(empty) {
    const host = $('kw-table');
    if (!host) return;
    const old = host.querySelector('.kh-empty-guide');
    if (!empty) { if (old) old.remove(); return; }
    if (old) return;
    host.appendChild(emptyGuide('📝', '还没有关键词', [
      '点筛选栏右侧「＋ 添加」，填一个词（例如「审核不通过」）。',
      '同一个词在表格里可以改：匹配方式、颜色、分组、备注，都是逐条生效。',
      '想一次加很多：把表格粘进「从在线表格导入」，或到「导入导出」批量导入 JSON/CSV。'
    ]));
  }

  function syncBatchBar() {
    const n = selection.size;
    // 文案与策划案 §5.2.1 对齐：常驻显示「已选 N 项」
    $('batch-info').textContent = '已选 ' + n + ' 项';
    for (const id of ['batch-enable', 'batch-disable', 'batch-group', 'batch-color', 'batch-match', 'batch-scope', 'batch-note', 'batch-delete', 'batch-clear']) {
      $(id).disabled = n === 0;
    }
    /* 「撤销改指向」只在有快照时出现；隐藏时也置灰，批量栏的口径保持「没得点就禁用」 */
    const ub = $('batch-scope-undo');
    if (ub) ub.disabled = ub.hidden;
    syncPageSelectAll();
  }

  /**
   * 「本页全选」与表头复选框必须**同源**：都取 DataTable 的 pageIds()。
   * 若这里自己按 filtered 切片算"本页"，一旦表格改了分页口径就会两处不一致
   * （一处选 50 条、另一处选 30 条这类诡异现象）。
   */
  function syncPageSelectAll() {
    const cb = $('batch-select-page');
    if (!cb) return;
    const ids = table ? table.pageIds() : [];
    const picked = ids.filter(id => selection.has(id)).length;
    cb.disabled = ids.length === 0;
    cb.checked = ids.length > 0 && picked === ids.length;
    cb.indeterminate = picked > 0 && picked < ids.length;
  }

  function openKeyword(kw) {
    ui.openEditor({ keyword: kw, cfg, onSaved: reload });
  }

  async function removeKeywords(ids, label) {
    const ok = await D.confirmBox('确定删除 ' + label + '？\n此操作不可撤销。', { title: '删除确认', danger: true, saveLabel: '删除' });
    if (!ok) return;
    /* 超过 20 条才分批：小批量一次写完更省事，也没必要为它弹进度条 */
    if (ids.length > 20) {
      const CHUNK = 25;
      const chunks = [];
      for (let i = 0; i < ids.length; i += CHUNK) chunks.push(ids.slice(i, i + CHUNK));
      let wroteAnything = false;
      const res = await runLongTask('删除关键词', chunks.length, async (i) => {
        const ok2 = await mutate(() => KH.Store.removeKeywords(chunks[i]));
        if (!ok2) throw new Error('第 ' + (i + 1) + ' 批删除失败');
        wroteAnything = true;
        for (const id of chunks[i]) selection.delete(id);
      });
      syncBatchBar();
      const deleted = chunks.slice(0, res.done).reduce((n, c) => n + c.length, 0);
      if (res.error) D.toast('删除中断：' + res.error.message + '（已删 ' + deleted + ' 条）', 'error');
      else if (res.cancelled) D.toast('已取消：删除 ' + deleted + ' 条，剩余 ' + (ids.length - deleted) + ' 条未处理', 'ok');
      else D.toast('已删除 ' + ids.length + ' 条', 'ok');
      if (!wroteAnything) return;
      return;
    }
    if (!await mutate(() => KH.Store.removeKeywords(ids))) return;   /* 写失败已 toast，别再说"已删除" */
    for (const id of ids) selection.delete(id);
    syncBatchBar();
    D.toast('已删除', 'ok');
  }

  $('btn-kw-add').addEventListener('click', () => ui.openEditor({ cfg, onSaved: reload }));
/** 搜索框每敲一个字就整表重绘（上千行）会明显卡手：160ms 静止后才重绘。 */
  let kwSearchTimer = 0;
  $('kw-search').addEventListener('input', () => {
    if (kwSearchTimer) clearTimeout(kwSearchTimer);
    kwSearchTimer = setTimeout(() => { kwSearchTimer = 0; renderKeywordTable(); }, 160);
  });
  $('kw-filter-group').addEventListener('change', () => renderKeywordTable());
  $('kw-filter-status').addEventListener('change', () => renderKeywordTable());
  $('kw-filter-axis').addEventListener('change', () => renderKeywordTable());
  $('kw-filter-sort').addEventListener('change', () => { sortState(); renderKeywordTable(); });
  $('btn-filter-reset').addEventListener('click', () => {
    $('kw-search').value = ''; $('kw-filter-group').value = '';
    $('kw-filter-status').value = ''; $('kw-filter-axis').value = '';
    $('kw-filter-sort').value = SORT_VALUES[0]; sortPref = SORT_VALUES[0];
    renderKeywordTable();
  });

  // 关键词管理页内的「📥 批量导入」：与「导入导出」共用同一条导入实现（见 importJSONText / importCSVText）
  $('btn-batch-import').addEventListener('click', () => { $('file-batch-import').value = ''; $('file-batch-import').click(); });
  $('file-batch-import').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) await importAnyFile(file);
  });

  /* ===================== 【2.0.8.4 需求⑤】推荐词（在线表格） =====================
   * 需求原话：「高亮词管理界面增加一个推荐词模式，支持配置在线表格（格式需符合导出的 excel），
   *   给予其他用户参考。」
   * 读法：贴一个**公开可访问**的表格链接（插件导出的 .xls 直链，或同列头的 .csv）→ 解析 →
   *   预览勾选 → 只导入勾选的那些（重复的自动跳过，走的是与「批量导入」同一条 importCSV）。
   * 不做"猜格式"：列数 / 首列不对就直说缺什么（列头唯一真源 = KH.Store.CSV_HEADERS）。
   * 链接本身存 storage.local 的 `khRecoUrl` —— **不是配置项**：不进配置签名、不随导出走。
   * ============================================================================ */
  const RECO_SRC_KEY = 'khRecoUrl';
  let recoRecords = null;      // 解析出的原始行（含表头）；null = 还没读过
  let recoPicked = [];         // 与数据行一一对应的勾选状态

  function recoSetState(text) {
    const el = $('reco-state');
    if (el) el.textContent = String(text || '');
  }

  /** HTML（插件导出的 .xls 本质就是一张表）→ 二维文本数组 */
  function recoHtmlToRecords(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const table = doc.querySelector('table');
    if (!table) throw new Error('这个链接里没有表格（可能不是直链，或页面需要登录）');
    const rows = [];
    for (let i = 0; i < table.rows.length; i++) {
      const tr = table.rows[i];
      const cells = [];
      for (let j = 0; j < tr.cells.length; j++) cells.push(String(tr.cells[j].textContent || '').trim());
      if (cells.some((c) => c !== '')) rows.push(cells);
    }
    return rows;
  }

  /** 表头校验（格式必须符合「导出 → Excel」：18 列，旧版 17 列也认；首列必须是「关键词」） */
  function recoValidate(records) {
    const want = KH.Store.CSV_HEADERS;
    const header = (records[0] || []).map((x) => String(x).trim());
    if (header.length !== want.length && header.length !== 17) {
      throw new Error('列数不符：需要与「导出 → Excel」一致的 ' + want.length + ' 列（旧版 17 列也认），实际 ' + header.length + ' 列');
    }
    if (header[0] !== want[0]) {
      throw new Error('表头第一列应是「' + want[0] + '」，实际是「' + (header[0] || '空') + '」—— 请用与导出 Excel 同款的列头');
    }
    return header;
  }

  function recoSyncImportBtn() {
    const btn = $('reco-import');
    if (!btn) return;
    const rows = recoRecords ? recoRecords.slice(1) : [];
    let n = 0;
    for (let i = 0; i < rows.length; i++) if (recoPicked[i]) n++;
    btn.disabled = !n;
    btn.textContent = n ? ('导入勾选的词（' + n + '）') : '导入勾选的词';
  }

  /** 预览列表：一行一个词（勾选 + 词 + 分组/备注/「已有」），已有的默认不勾且不可勾。 */
  function recoRender() {
    const box = $('reco-list');
    if (!box) return;
    box.innerHTML = '';
    const rows = recoRecords ? recoRecords.slice(1) : [];
    const have = new Set((cfg.keywords || []).map((k) => String(k.text || '').trim().toLowerCase()));
    if (!rows.length) {
      box.hidden = true;
      recoSyncImportBtn();
      return;
    }
    box.hidden = false;
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i] || [];
      const text = String(r[0] || '').trim();
      /* 与 importCSV 同一条判据：首列为空的「仅抓取」词也是有效行（第 12 列=是 且第 13 列非空） */
      const comboOnly = String(r[11] || '').trim() === '是' && !!String(r[12] || '').trim();
      if (!text && !comboOnly) continue;
      const dup = !!text && have.has(text.toLowerCase());
      const row = document.createElement('label');
      row.className = 'kh-reco-row' + (dup ? ' is-dup' : '');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = !dup && recoPicked[i] !== false;
      cb.disabled = dup;
      cb.addEventListener('change', () => {
        recoPicked[i] = cb.checked;
        recoSyncImportBtn();
      });
      const name = document.createElement('span');
      name.className = 'kh-reco-name';
      name.textContent = text || ('（仅抓取）' + String(r[12] || ''));
      const meta = document.createElement('span');
      meta.className = 'kh-reco-meta';
      const bits = [];
      if (String(r[2] || '').trim()) bits.push('分组：' + String(r[2]).trim());
      if (String(r[1] || '').trim()) bits.push(String(r[1]).trim());
      if (String(r[9] || '').trim() === '是') bits.push('重要');
      if (dup) bits.push('已有');
      meta.textContent = bits.join(' · ');
      row.appendChild(cb);
      row.appendChild(name);
      row.appendChild(meta);
      box.appendChild(row);
    }
    recoSyncImportBtn();
  }

  /** 只把勾选的行拼回 CSV（保留原表头，交给 importCSV 走同一条导入/去重路径）。 */
  async function recoImport() {
    if (!recoRecords) return;
    const header = (recoRecords[0] || []).map((x) => String(x));
    const rows = recoRecords.slice(1);
    const out = [header];
    let n = 0;
    for (let i = 0; i < rows.length; i++) {
      if (!recoPicked[i]) continue;
      out.push(rows[i]);
      n++;
    }
    if (!n) { recoSetState('没有勾选任何词'); return; }
    const csv = out.map((r) => r.map((c) => {
      const s = String(c == null ? '' : c);
      return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(',')).join('\r\n');
    await importCSVText(csv);
    recoRender();                       // 导入后"已有"标记与勾选状态跟着变
    recoSetState('已提交导入 ' + n + ' 条（重复的会自动跳过）');
  }

  $('reco-fetch').addEventListener('click', async () => {
    const url = String($('reco-url').value || '').trim();
    if (!url) { recoSetState('先贴一个表格链接'); return; }
    if (!/^https?:\/\//i.test(url)) { recoSetState('链接必须以 http:// 或 https:// 开头'); return; }
    const btn = $('reco-fetch');
    btn.disabled = true;
    recoSetState('正在读取…');
    try {
      /* 设置页是扩展自己的来源，配合 host_permissions: <all_urls> 可直接跨域取（不走页面 CORS）。 */
      const res = await fetch(url, { credentials: 'omit', cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const text = await res.text();
      const trimmed = text.replace(/^\uFEFF/, '').trim();
      const records = /^</.test(trimmed) ? recoHtmlToRecords(trimmed) : KH.Store.parseCSV(trimmed);
      if (!records.length) throw new Error('表里没有任何行');
      recoValidate(records);
      recoRecords = records;
      recoPicked = records.slice(1).map(() => true);
      try { await chrome.storage.local.set({ [RECO_SRC_KEY]: url }); } catch (e) { /* 存不上不影响这次导入 */ }
      recoRender();
      recoSetState('读到 ' + Math.max(0, records.length - 1) + ' 行，确认后点「导入勾选的词」');
    } catch (err) {
      recoRecords = null;
      recoPicked = [];
      recoRender();
      recoSetState('读取失败：' + String((err && err.message) || err));
    } finally {
      btn.disabled = false;
    }
  });

  $('reco-import').addEventListener('click', async () => { await recoImport(); });

  /* 上次用过的链接就留在框里（只是本机记录，不是配置项）。 */
  try {
    chrome.storage.local.get(RECO_SRC_KEY, (r) => {
      if (r && r[RECO_SRC_KEY] && $('reco-url') && !$('reco-url').value) $('reco-url').value = r[RECO_SRC_KEY];
    });
  } catch (e) { /* 老内核 / 无 storage：跳过 */ }

  /* ---------------- 批量栏 ---------------- */

  const batchIds = () => Array.from(selection);

  /** 批量启用/停用：数量大时同样分批 + 进度 + 取消（取消后已处理的那批保留） */
  async function patchBatchEnabled(enabled) {
    const ids = batchIds();
    const CHUNK = 50;
    if (ids.length > 100) {
      const chunks = [];
      for (let i = 0; i < ids.length; i += CHUNK) chunks.push(ids.slice(i, i + CHUNK));
      const res = await runLongTask((enabled ? '启用' : '停用') + '关键词', chunks.length, async (i) => {
        const ok2 = await mutate(() => KH.Store.patchKeywords(chunks[i], () => ({ enabled: enabled })));
        if (!ok2) throw new Error('第 ' + (i + 1) + ' 批写入失败');
      });
      const n = chunks.slice(0, res.done).reduce((m, c) => m + c.length, 0);
      if (res.error) D.toast('操作中断：' + res.error.message + '（已处理 ' + n + ' 条）', 'error');
      else if (res.cancelled) D.toast('已取消：处理 ' + n + ' 条，剩余 ' + (ids.length - n) + ' 条未处理', 'ok');
      else D.toast((enabled ? '已启用 ' : '已停用 ') + ids.length + ' 条', 'ok');
      return;
    }
    if (!await mutate(() => KH.Store.patchKeywords(ids, () => ({ enabled: enabled })))) return;
    D.toast((enabled ? '已启用 ' : '已停用 ') + ids.length + ' 条', 'ok');
  }

  $('batch-enable').addEventListener('click', () => patchBatchEnabled(true));
  $('batch-disable').addEventListener('click', () => patchBatchEnabled(false));
  $('batch-clear').addEventListener('click', () => { table.clearSelection(); });

  /**
   * 「本页全选」：勾上=把**本页**所有行加入选中集合，再点一下=只把本页移出选中集合。
   * 语义刻意与表头复选框一致（旧版 `checkAllPage` 就是"本页"，跨页累选靠逐行勾选）：
   * "全选"若跨页，用户点一次删除就会清掉看不见的页，这是不可接受的破坏性误操作。
   */
  $('batch-select-page').addEventListener('change', (e) => {
    const ids = table ? table.pageIds() : [];
    if (e.target.checked) ids.forEach(id => selection.add(id));
    else ids.forEach(id => selection.delete(id));
    table.setSelected(selection);
  });

  /* ---- 批量弹窗的字段体构建：**统一走共享字段工厂** ----
   * 四个批量弹窗（分组 / 颜色 / 匹配 / 备注·笔记）原先各写一套控件形态：
   * 裸 `<select>`、旧色块、「真勾选框 + 两行文字」的行 —— 与关键词/分组弹窗的
   * 「开关胶囊 / 颜色胶囊 / id+for 契约」完全不是一套。这里统一收口。
   *
   * id 前缀用 `fld-b-`：批量字段与关键词字段有同名键（bgColor/note/importantNote…），
   * 同前缀会在弹窗堆叠时让"按 id 定位"产生歧义。
   */
  function fieldBody(specs, values, opts) {
    const o = opts || {};
    const prefix = o.idPrefix || 'fld-b-';
    const body = h('div', { class: o.cls || 'kh-editor-sec-body' });
    const controls = [], items = [], touched = new Set();
    for (const f of specs) {
      const c = ui.Fields.create(f, values[f.key], {
        idPrefix: prefix, groups: cfg.groups, imgSize: cfg.importantNote && cfg.importantNote.imgSize
      });
      controls.push(c);
      items.push({ spec: f, ctrl: c });
    }
    ui.Fields.layout(items, body);
    /* 记录"用户碰过哪些字段"：批量语义里"没碰过 = 不修改"，
     * 而 read() 只能给出当前值（胶囊未碰过也是"未选中"），所以需要单独记一笔。
     * 同时给胶囊打 `is-touched`：点两下＝显式关闭，用**虚线边框**跟"没碰过"区分开
     * （否则"关掉了"和"没动过"长得一模一样，用户没法预判保存后会写什么）。 */
    const mark = (e) => {
      const t = e.target;
      if (!t || !t.id || t.id.indexOf(prefix) !== 0) return;
      touched.add(t.id.slice(prefix.length));
      const chip = t.closest ? t.closest('.kh-fld-chip') : null;
      if (chip) chip.classList.add('is-touched');
    };
    body.addEventListener('change', mark, true);
    body.addEventListener('input', mark, true);
    return {
      body, controls, touched,
      read: () => { const out = {}; for (const c of controls) out[c.key] = c.read(); return out; }
    };
  }

  $('batch-group').addEventListener('click', () => {
    const specs = [{
      key: 'groupId', label: '移入分组', type: 'select', width: 2,
      options: [{ v: '', t: '（移出分组）' }].concat((cfg.groups || []).map(g => ({ v: g.id, t: g.name || '(未命名)' })))
    }];
    const fb = fieldBody(specs, { groupId: '' });
    ui.Modal.open({
      title: '批量设置分组（选中 ' + selection.size + ' 条）', size: 'sm',
      body: fb.body,
      onSave: async () => {
        const v = fb.read();
        await mutate(() => KH.Store.patchKeywords(batchIds(), () => ({ groupId: v.groupId || null })));
        D.toast('分组已更新', 'ok');
      }
    });
  });

  $('batch-color').addEventListener('click', () => {
    /* 颜色：与编辑弹窗同形的**颜色胶囊**（`● 底` / `● 文`），点开选色浮层。
     * "没点过 = 不修改"由 `spec.onChange` 保证 —— 只有真的选了色（或点了「清除」）才回调。 */
    let bg = null, fg = null;
    const specs = [
      { key: 'bgColor', label: '底色', short: '底', type: 'color', chip: true,
        hint: '批量设置背景色（点「清除」＝设为继承）', onChange: (v) => { bg = v; } },
      { key: 'textColor', label: '文字颜色', short: '文', type: 'color', chip: true,
        hint: '批量设置文字颜色（点「清除」＝设为继承）', onChange: (v) => { fg = v; } }
    ];
    const fb = fieldBody(specs, { bgColor: '', textColor: '' });
    ui.Modal.open({
      title: '批量设置颜色（选中 ' + selection.size + ' 条）', size: 'sm',
      body: h('div', { class: 'kh-editor-sec-body' }, [
        h('p', { class: 'kh-muted', text: '没点过的颜色不会被修改；点「清除」＝设为继承（回退到分组色 / 全局默认色）。' }),
        fb.body
      ]),
      onSave: async () => {
        const patch = {};
        if (bg !== null) patch.bgColor = bg;
        if (fg !== null) patch.textColor = fg;
        if (!Object.keys(patch).length) { D.toast('请先选择要修改的颜色（或用「清除」）', 'info'); return false; }
        await mutate(() => KH.Store.patchKeywords(batchIds(), () => patch));
        D.toast('颜色已更新', 'ok');
      }
    });
  });
  /**
   * 批量「⚙️ 匹配」—— 必须覆盖**两组共 6 个开关**：
   *   核心词：caseSensitive / wholeWord / useRegex
   *   标题词：cellVerifyMatchMode(exact) / cellVerifyCaseSensitive / cellVerifyUseRegex
   * 旧版 v1.52.0 就是 6 项；只做 3 项会让"批量设标题词规则"这个刚需整块缺失。
   *
   * 为什么用浮层而不是模态：策划案 §5.2.1 要求匹配规则"点开是小勾选弹窗"，
   * 这里复用胶囊弹窗的浮层实现（options.js 不再另写第二套浮层）。
   *
   * ★ 文案**直接取自 `chip.js` 的 PARTS**（匹配开关文案的唯一来源）——
   *   原先这里手写了 `区分大小写` / `整词`，于是「大小写 → Aa」那次全局改名它没跟上：
   *   同一个开关在表格里叫 `Aa`、在批量弹窗里叫"区分大小写"、还多一个"整词"。
   *   改成从 PARTS 派生之后，这类漂移在结构上不可能再发生。
   *
   * 标题词 3 项会**跳过非组合词**（普通词没有标题格，硬写 cellVerify* 就是脏数据）。
   */
  $('batch-match').addEventListener('click', () => {
    const ids = batchIds();
    const comboIds = ids.filter(id => {
      const kw = (cfg.keywords || []).find(k => k.id === id);
      return !!(kw && kw.cellVerifyEnabled && kw.cellVerify);
    });
    const P = ui.MatchChip.PARTS;
    /* PARTS 里 `type: "exact"` 的是"两态"字段（include ↔ exact）—— 工厂的 select+chip 支持两态胶囊 */
    const specOf = (f) => (f.type === 'exact'
      ? { key: f.key, label: f.label, hint: f.hint, type: 'select', chip: true, onValue: 'exact', offValue: 'include' }
      : { key: f.key, label: f.label, hint: f.hint, type: 'bool', chip: true });
    const coreFb = fieldBody(P.core.fields.map(specOf), {});
    const titleFb = fieldBody(P.title.fields.map(specOf), {});
    const panel = h('div', { class: 'kh-pop-inner' }, [
      h('div', { class: 'kh-pop-title', text: '批量匹配方式（共 ' + ids.length + ' 条）' }),
      h('div', { class: 'kh-pop-group-title', text: '核心词 · 全部选中项' }),
      coreFb.body,
      h('div', { class: 'kh-pop-group-title', text: '标题词（需勾选「单元格组合」）· ' + comboIds.length + ' 条' }),
      titleFb.body,
      h('div', { class: 'kh-pop-foot', text: comboIds.length
        ? '点一下就开启，再点一下=关闭（虚线框）；没点过的项不会被修改。'
        : '⚠️ 选中项里没有组合词：标题词 3 项会被跳过（普通词没有标题格）。' })
    ]);
    let pop = null;
    const applyBtn = h('button', { class: 'kh-mini-btn kh-pop-apply', type: 'button', text: '应用到选中的 ' + ids.length + ' 条' });
    applyBtn.addEventListener('click', async () => {
      /* 只有"点过"的项才写进 patch：没点过＝保持原样；点两下＝显式关闭（false / include）。
       * 胶囊的初始态是未选中，所以不能只看 read() 的布尔值（那分不出"没碰过"和"关掉了"）。 */
      const coreVals = coreFb.read(), titleVals = titleFb.read();
      const corePatch = {}, titlePatch = {};
      for (const k of Object.keys(coreVals)) if (coreFb.touched.has(k)) corePatch[k] = coreVals[k];
      for (const k of Object.keys(titleVals)) if (titleFb.touched.has(k)) titlePatch[k] = titleVals[k];
      const hasCore = Object.keys(corePatch).length > 0;
      const hasTitle = Object.keys(titlePatch).length > 0 && comboIds.length > 0;
      if (!hasCore && !hasTitle) { D.toast('请先点选要应用的匹配项', 'info'); return; }
      if (pop) pop.close();
      const wrote = await mutate(() => KH.Store.patchKeywords(ids, (kw) => {
        // 每次 patch 都重新算：标题词只给"当前这条确实是组合词"的行
        const p = Object.assign({}, corePatch);
        if (kw && kw.cellVerifyEnabled && kw.cellVerify) Object.assign(p, titlePatch);
        return p;
      }));
      if (!wrote) return;
      D.toast('已更新 ' + ids.length + ' 条匹配方式', 'ok');
    });
    panel.appendChild(h('div', { class: 'kh-pop-actions' }, [applyBtn]));
    pop = ui.Popover.open($('batch-match'), panel, null, { className: 'kh-popover-wide' });
  });

  $('batch-note').addEventListener('click', () => {
    /* 两个"开关胶囊 + 对应编辑器"：开关没勾就不写该字段（内容留空＝清空）。
     * 开关用胶囊、编辑器用 RichEditor —— 与关键词/分组弹窗同一套控件语言。 */
    const specs = [
      { key: 'setNote', label: '备注', type: 'bool', chip: true, hint: '勾选后才会覆盖选中项的备注（留空＝清空）' },
      { key: 'note', label: '备注内容', type: 'textarea', rows: 3, width: 2, placeholder: '留空＝清空该字段' },
      { key: 'setImp', label: '重要笔记', type: 'bool', chip: true, hint: '勾选后才会覆盖选中项的重要笔记（留空＝清空）' },
      { key: 'importantNote', label: '重要笔记内容', type: 'richtext', width: 2,
        placeholder: '与页面显示一致：图片、加粗、表格、链接直接在框内显示；留空＝清空' }
    ];
    const fb = fieldBody(specs, {});
    ui.Modal.open({
      title: '批量备注 / 重要笔记（选中 ' + selection.size + ' 条）', size: 'md',
      body: h('div', { class: 'kh-editor-sec-body' }, [
        h('p', { class: 'kh-muted', text: '先点选要修改的字段：没点的字段不会被修改，内容留空表示清空该字段。' }),
        fb.body
      ]),
      onSave: async () => {
        const v = fb.read();
        const patch = {};
        if (v.setNote) patch.note = v.note || '';
        if (v.setImp) patch.importantNote = v.importantNote || '';
        if (!Object.keys(patch).length) { D.toast('请先勾选要修改的字段', 'info'); return false; }
        if (!await mutate(() => KH.Store.patchKeywords(batchIds(), () => patch))) return false;
        D.toast('已更新', 'ok');
      }
    });
  });


  /* ── 批量改指向（2.0.16.8 · m21072）────────────────────────────────
   * 只改「指向的抓取字段名」：把 `@旧字段` 换成 `@新字段`，进表后缀 / 取值表达式一个字不动。
   * 为什么按字段名 remap 而不是按行号批改：不同关键词的字段集合不同，行号会错位；
   * 字段名替换是幂等的，能先给条数、能整体撤销。 */
  const SCOPE_UNDO_KEY = 'kh.batchScopeUndo';
  const SCOPE_FIELDS = ['fetchLabels', 'imgOcrKeyword', 'imgOcrNeed'];
  const SCOPE_NAME_RE = /@([^@#|｜\s]+)/g;

  function scopeNamesOf(list) {
    const out = new Set();
    for (const kw of list || []) {
      for (const f of SCOPE_FIELDS) {
        const v = String((kw && kw[f]) || '');
        SCOPE_NAME_RE.lastIndex = 0;
        let m;
        while ((m = SCOPE_NAME_RE.exec(v))) out.add(m[1]);
      }
    }
    return Array.from(out).sort();
  }

  /** 先算一遍：会动到几条词、几处 @ 指向。预览与真正写入共用这一份判据。 */
  function batchScopePlan(from, to, list) {
    const ids = [];
    const patches = new Map();
    let hits = 0;
    for (const kw of list || []) {
      if (!kw || !kw.id) continue;
      const patch = {};
      for (const f of SCOPE_FIELDS) {
        const before = String(kw[f] || '');
        const after = KH.Store.remapScopeName(before, from, to);
        if (after !== before) { patch[f] = after; hits += 1; }
      }
      if (Object.keys(patch).length) { ids.push(kw.id); patches.set(kw.id, patch); }
    }
    return { ids: ids, hits: hits, patches: patches };
  }

  async function putScopeUndo(snap) {
    const area = sessionArea();
    if (!area) return false;
    try { await area.set({ [SCOPE_UNDO_KEY]: snap }); return true; } catch (e) { return false; }
  }

  async function getScopeUndo() {
    const area = sessionArea();
    if (!area) return null;
    try {
      const got = await area.get(SCOPE_UNDO_KEY);
      const snap = got && got[SCOPE_UNDO_KEY];
      if (!snap || !Array.isArray(snap.rows) || !snap.rows.length) return null;
      if (Date.now() - Number(snap.at || 0) > UNDO_TTL_MS) { await area.remove(SCOPE_UNDO_KEY); return null; }
      return snap;
    } catch (e) { return null; }
  }

  async function clearScopeUndo() {
    const area = sessionArea();
    if (!area) return;
    try { await area.remove(SCOPE_UNDO_KEY); } catch (e) { /* 清不掉不影响主流程 */ }
  }

  async function refreshScopeUndo() {
    const btn = $('batch-scope-undo');
    if (!btn) return;
    btn.hidden = !(await getScopeUndo());
    btn.disabled = btn.hidden;   // 与 syncBatchBar 同一口径：没快照就隐藏且禁用
  }

  $('batch-scope').addEventListener('click', () => {
    const picked = (cfg.keywords || []).filter(k => k && selection.has(k.id));
    if (!picked.length) { D.toast('先勾选要改的关键词', 'info'); return; }
    const names = scopeNamesOf(picked);
    const list = h('datalist', { id: 'batch-scope-names' });
    for (const n of names) list.appendChild(h('option', { value: n }));
    const fromIn = h('input', { class: 'kh-input', id: 'batch-scope-from', list: 'batch-scope-names', placeholder: names[0] || '例如 应用截图', 'aria-label': '旧字段名' });
    const toIn = h('input', { class: 'kh-input', id: 'batch-scope-to', placeholder: '例如 软件著作权证书', 'aria-label': '新字段名' });
    const prev = h('p', { class: 'kh-muted', text: '' });
    const sync = () => {
      const from = fromIn.value.trim();
      const to = toIn.value.trim();
      if (!from) { prev.textContent = names.length ? ('这些词现在指向 ' + names.length + ' 个字段：' + names.join('、')) : '选中的词还没有「@字段」指向。'; return; }
      if (!to) { prev.textContent = '再填新字段名，就能看到会改到几条词。'; return; }
      if (from === to) { prev.textContent = '新旧字段名一样，不用改。'; return; }
      if (/^\d+$/.test(from) || /^\d+$/.test(to)) { prev.textContent = '@ 后面的纯数字是取值偏移（例如「应用截图@2」），不是字段名。'; return; }
      const plan = batchScopePlan(from, to, picked);
      prev.textContent = plan.ids.length
        ? ('会把 ' + plan.ids.length + ' 条关键词里的 ' + plan.hits + ' 处「@' + from + '」改成「@' + to + '」。')
        : ('选中的词里没有「@' + from + '」这个指向，不会有任何改动。');
    };
    fromIn.addEventListener('input', sync);
    toIn.addEventListener('input', sync);
    sync();
    ui.Modal.open({
      title: '批量改指向（选中 ' + picked.length + ' 条）', size: 'sm',
      body: h('div', { class: 'kh-editor-sec-body' }, [
        h('p', { class: 'kh-muted', text: '只改「@ 指向的抓取字段名」，进表后缀（#图 / #比 …）和取值偏移（@2）都不动。改完 10 分钟内可撤销。' }),
        h('div', { class: 'kh-form-row' }, [
          h('label', { class: 'kh-form-fld' }, [h('span', { text: '旧字段名' }), fromIn]),
          h('label', { class: 'kh-form-fld' }, [h('span', { text: '新字段名' }), toIn])
        ]),
        prev,
        list
      ]),
      onSave: async () => {
        const from = fromIn.value.trim();
        const to = toIn.value.trim();
        if (!from || !to) { D.toast('两个字段名都要填', 'info'); return false; }
        if (from === to) { D.toast('新旧字段名一样，不用改', 'info'); return false; }
        if (/^\d+$/.test(from) || /^\d+$/.test(to)) { D.toast('@ 后面的纯数字是取值偏移，不是字段名', 'error'); return false; }
        const plan = batchScopePlan(from, to, picked);
        if (!plan.ids.length) { D.toast('选中的词里没有「@' + from + '」这个指向', 'info'); return false; }
        const snapRows = plan.ids.map((id) => {
          const old = picked.filter(k => k.id === id)[0] || {};
          const row = { id: id };
          for (const f of SCOPE_FIELDS) row[f] = String(old[f] || '');
          return row;
        });
        if (!await mutate(() => KH.Store.patchKeywords(plan.ids, (k) => plan.patches.get(k.id) || {}))) return false;
        await putScopeUndo({ at: Date.now(), rows: snapRows });
        await refreshScopeUndo();
        D.toast('已把 ' + plan.ids.length + ' 条词的 @' + from + ' 改成 @' + to, 'ok');
      }
    });
  });

  $('batch-scope-undo').addEventListener('click', async () => {
    const snap = await getScopeUndo();
    if (!snap) { D.toast('撤销窗口已过期（只保留 10 分钟）', 'error'); await refreshScopeUndo(); return; }
    const ok = await D.confirmBox('把 ' + snap.rows.length + ' 条关键词的指向改回上一次？', { title: '撤销改指向', saveLabel: '撤销' });
    if (!ok) return;
    const map = new Map(snap.rows.map(r => [r.id, r]));
    const done = await mutate(() => KH.Store.patchKeywords(snap.rows.map(r => r.id), (k) => {
      const r = map.get(k.id) || {};
      const patch = {};
      for (const f of SCOPE_FIELDS) if (r[f] !== undefined) patch[f] = r[f];
      return patch;
    }));
    if (!done) return;
    await clearScopeUndo();
    await refreshScopeUndo();
    D.toast('已撤销', 'ok');
  });

  $('batch-delete').addEventListener('click', () => removeKeywords(batchIds(), '选中的 ' + selection.size + ' 条关键词'));

  /* ==================================================================== ② 分组 */

  /** 空态三步引导（2.0.8.12）：图标 + 一句标题 + 三条「从这里开始」。
   *  为什么不用 innerHTML：步骤文案里有 `＋ 添加` 这类会被当成标签的字符，
   *  走元素拼装才不会把界面写坏；同类空态共用这一处，措辞只维护一份。 */
  function emptyGuide(icon, title, steps) {
    const box = h('div', { class: 'kh-empty-guide' });
    box.appendChild(h('span', { class: 'kh-empty-guide-icon', text: icon, 'aria-hidden': 'true' }));
    box.appendChild(h('span', { class: 'kh-empty-guide-title', text: title }));
    const ol = h('ol', { class: 'kh-empty-guide-steps' });
    for (const step of steps) ol.appendChild(h('li', { text: step }));
    box.appendChild(ol);
    return box;
  }

  function renderGroups() {
    const box = $('group-list');
    clear(box);
    const groups = cfg.groups || [];
    if (!groups.length) {
      box.appendChild(emptyGuide('📁', '还没有分组', [
        '点下面的「＋ 添加分组」，给它起个名字（例如「客户」「合同条款」）。',
        '选一个底色：同一分组的关键词会用这个颜色高亮。',
        '需要整组提醒时勾上「重要」，被高亮的词会自动生成重要笔记卡片。'
      ]));
      return;
    }
    for (const g of groups) {
      const count = (cfg.keywords || []).filter(k => k.groupId === g.id).length;
      const row = h('div', { class: 'kh-group-row' }, [
        h('span', { class: 'kh-color-dot', style: 'background:' + (g.bgColor || cfg.highlightStyle.defaultBgColor), title: g.bgColor || '未设色（跟随全局默认）' }),
        h('span', { class: 'kh-group-name', text: g.name || '(未命名)' }),
        g.important ? h('span', { class: 'imp-badge', text: '📌 重要' }) : null,
        g.impNoteUseHlColor ? h('span', { class: 'kh-tag-mini', text: '复用底色' }) : null,
        h('span', { class: 'kh-group-count', text: count + ' 条关键词' })
      ]);
      const ops = h('span', { class: 'kh-row-ops' });
      const edit = h('button', { class: 'kh-link-btn', type: 'button', text: '编辑' });
      const del = h('button', { class: 'kh-link-btn kh-link-danger', type: 'button', text: '删除' });
      edit.addEventListener('click', () => openGroup(g));
      del.addEventListener('click', async () => {
        const ok = await D.confirmBox('删除分组「' + (g.name || '') + '」？\n组内 ' + count + ' 条关键词不会被删除，会移出分组。', { title: '删除分组', danger: true, saveLabel: '删除' });
        if (!ok) return;
        await mutate(() => KH.Store.removeGroup(g.id));
        D.toast('分组已删除', 'ok');
      });
      ops.appendChild(edit); ops.appendChild(del);
      row.appendChild(ops);
      box.appendChild(row);
    }
  }

  /**
   * 分组编辑弹窗：字段**全部由共享工厂渲染**（`ui.Fields.create` + `FieldMap.GROUP_FIELDS`），
   * 与关键词编辑弹窗同一套控件语言（开关胶囊 / 颜色胶囊 / 行内字段 / id+for 契约）。
   *
   * 与关键词弹窗**刻意不同**的两处（原版 1.52.0 就是如此，不是偷懒）：
   *   · 宽度 `md` 而不是 `lg` —— 原版分组弹窗是 `modal-sm`，本来就更小；6 个字段撑 1040px 会大片留白；
   *   · **没有分区卡片** —— 原版分组弹窗是 `.form-group` 平铺；只有一张卡还带折叠标题没有意义。
   * 这两条如果用户要求统一，改这里即可（字段本身不用动）。
   */
  function openGroup(group) {
    const g = group || KH.Store.newGroup({});
    const fields = fm.GROUP_FIELDS;
    const body = h('div', { class: 'kh-editor-sec-body' });
    const controls = [];
    const items = [];

    for (const f of fields) {
      /* 取值口径复用 FieldMap.coerce（按 spec.type 收口），不再为分组另写一份 */
      const c = ui.Fields.create(f, fm.coerce(f, g[f.key]), {
        idPrefix: 'fld-g-', groups: cfg.groups, imgSize: g.imgSize
      });
      controls.push(c);
      items.push({ spec: f, ctrl: c });
    }
    // 胶囊成行 / 竖线分隔 / 半行整行流式：与关键词弹窗**共用同一份排布实现**（ui.Fields.layout）
    ui.Fields.layout(items, body);

    const readAll = () => {
      const out = {};
      for (const c of controls) out[c.key] = c.read();
      return out;
    };

    ui.Modal.open({
      title: group ? '编辑分组' : '新建分组', size: 'md',
      body: body,
      onSave: async () => {
        const v = readAll();
        const nm = String(v.name || '').trim();
        if (!nm) { D.toast('请填写分组名称', 'error'); return false; }
        const dup = (cfg.groups || []).find(x => x.name === nm && (!group || x.id !== group.id));
        if (dup) { D.toast('分组「' + nm + '」已存在', 'error'); return false; }
        await mutate(() => KH.Store.upsertGroup({
          id: group ? group.id : undefined, name: nm,
          bgColor: v.bgColor || '', textColor: v.textColor || '',
          important: !!v.important, impNoteUseHlColor: !!v.impNoteUseHlColor,
          importantNote: v.importantNote || '',
          imgSize: v.imgSize === '' || v.imgSize == null ? '' : v.imgSize,
          noteFontSize: v.noteFontSize === '' || v.noteFontSize == null ? '' : v.noteFontSize
        }));
        D.toast(group ? '分组已保存' : '分组已创建', 'ok');
      }
    });
  }

  $('btn-group-add').addEventListener('click', () => openGroup(null));

  /* ==================================================================== ③ 高亮样式 */

  let hlBg = null, hlFg = null;

  async function saveNested(patch) {
    // 嵌套配置必须整体写（storage 侧只做一层合并，写半截会丢兄弟键）
    const next = {};
    for (const k of Object.keys(patch)) next[k] = Object.assign({}, cfg[k] || {}, patch[k]);
    await mutate(() => KH.Store.patch(next));
  }

  /* ===================== 【2.0.8.4 需求④】AI 助手（重要笔记面板） =====================
   * 面板里那块对话界面的**唯一配置入口**。口径（用户 2026-11-03 拍板）：
   *   默认 DeepSeek 官方；协议是 OpenAI 兼容（换别家/中转只改地址与模型）；
   *   纯自由对话（不携带页面内容）；Key 只存本机，不进导出。
   * 归一只有 `KH.Config.normalizeAi` 一处（读路径、后台请求前校验、这里的回显三处共用）。
   * ================================================================================== */
  function renderAiForm() {
    const C = KH.Config;
    const ai = C.normalizeAi(cfg && cfg.ai);
    /* 【2.0.16.4 · 用户 m19483】只剩太极AI 一条通路：没有「对话来源」可选，也没有服务商 / Base URL /
     * API Key / 单次上限 / 系统提示词这些东西（那些字段连 HTML 一起删了）。这里只回显太极AI 的账号与模型。 */
    renderTaijiForm();
    renderAiCustomForm();
    $('ai-enabled').checked = ai !== null && ai.enabled !== false;
  }

  /* 【2.0.16】太极AI 网页通路：账号/站点地址存本机，密码只用于"这一次登录"。
   * 模型清单来自站点 /api/chat/tmpl —— 只有登录后拿得到，所以这里首次回显时顺手拉一次。 */
  function renderTaijiForm() {
    const tj = KH.Config.normalizeAiTaiji(cfg && cfg.ai && cfg.ai.taiji);
    const acc = $('ai-taiji-account');
    if (acc) acc.value = tj.account || '';
    const base = $('ai-taiji-base');
    if (base) base.value = tj.base || '';
    const pwd = $('ai-taiji-password');
    if (pwd) pwd.value = '';
    fillTaijiModels([], tj.model);
    const state = $('ai-taiji-state');
    if (state) {
      state.textContent = tj.account
        ? ('已保存账号：' + tj.account + (tj.model ? '；模型：' + tj.model : '') + '（密码不保存，换密码时重新登录即可；这条通路后台直连站点，不开标签页）')
        : '填账号密码点「登录」；登录一次之后会话由浏览器记住，不用再填（后台直连站点，不开标签页）。';
    }
  }

  /** 模型下拉：清单来自站点；已选值不在清单里也保留一行（否则一切换就丢配置）。 */
  function fillTaijiModels(list, selected) {
    const sel = $('ai-taiji-model');
    if (!sel) return;
    sel.innerHTML = '';
    const cur = String(selected || '').trim();
    let has = false;
    for (let i = 0; i < (list || []).length; i++) {
      const opt = document.createElement('option');
      opt.value = list[i].id;
      opt.textContent = list[i].name || list[i].id;
      if (list[i].id === cur) has = true;
      sel.appendChild(opt);
    }
    if (cur && !has) {
      const opt = document.createElement('option');
      opt.value = cur;
      opt.textContent = cur;
      sel.appendChild(opt);
    }
    sel.value = cur || (list && list[0] ? list[0].id : '');
  }

  async function refreshTaijiModels() {
    const state = $('ai-taiji-state');
    const btn = $('ai-taiji-refresh');
    if (btn) btn.disabled = true;
    if (state) state.textContent = '正在取模型清单…';
    try {
      const res = await chrome.runtime.sendMessage({ type: KH.MSG.AI_TAIJI_MODELS });
      const list = (res && res.ok && res.models) || [];
      const cur = (cfg && cfg.ai && cfg.ai.taiji && cfg.ai.taiji.model) || '';
      fillTaijiModels(list, cur);
      if (state) {
        if (!res || !res.ok) {
          state.textContent = (res && res.needLogin ? '还没登录（或会话过期）：' : '取模型清单失败：') + ((res && res.error) || '未知原因');
        } else {
          /* 【2.0.16.1】把实际连上的域名说出来：品牌域名会跳到真实宿主，用户才知道消息发去了哪。 */
          const where = String((res && res.base) || '').replace(/^https:\/\//i, '').replace(/\/+$/, '');
          state.textContent = list.length
            ? ('模型清单已更新（' + list.length + ' 个）' + (where ? '；站点：' + where : ''))
            : '站点没有回可用模型';
        }
      }
      return list;
    } catch (err) {
      if (state) state.textContent = '取模型清单失败：' + String((err && err.message) || err);
      return [];
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  function renderHighlightStyle() {
    const hl = cfg.highlightStyle;
    /* 颜色控件统一成**颜色胶囊**（`● 底` / `● 文`），与编辑弹窗、批量弹窗同形。
     * `allowEmpty: false`：全局默认色必须有一个值（浮层里因此不会出现「清除」）。 */
    if (!hlBg) {
      hlBg = ui.ColorField.create({
        value: hl.defaultBgColor, allowEmpty: false, chip: true, label: '底',
        title: '全局默认背景色（关键词未单独设色时使用）',
        onChange: (v) => { if (v) saveNested({ highlightStyle: { defaultBgColor: v } }); }
      });
      hlFg = ui.ColorField.create({
        value: hl.defaultTextColor, allowEmpty: false, chip: true, label: '文',
        title: '全局默认文字色（关键词未单独设色时使用）',
        onChange: (v) => { if (v) saveNested({ highlightStyle: { defaultTextColor: v } }); }
      });
      $('hl-bg').appendChild(hlBg);
      $('hl-fg').appendChild(hlFg);
    } else {
      hlBg.setValue(hl.defaultBgColor);
      hlFg.setValue(hl.defaultTextColor);
    }
    $('hl-preview').style.background = hl.defaultBgColor;
    $('hl-preview').style.color = hl.defaultTextColor;
  }

  $('btn-hl-reset').addEventListener('click', async () => {
    if (!await mutate(() => KH.Store.patch({ highlightStyle: KH.Config.defaults.highlightStyle }))) return;
    D.toast('已恢复默认高亮色', 'ok');
  });

  /* ==================================================================== ④ 备注卡片 */

  /* 字段清单已收进 `fm.NOTE_CARD_FIELDS`（原先这里另有一份 NC_FIELDS，与其它表单各写一套） */

  function renderNoteCardStyle() {
    const box = $('nc-fields');
    clear(box);
    /* 统一走共享字段工厂：三个颜色是与编辑弹窗同形的**颜色胶囊**，
     * 其余是带 `id=fld-nc-<key>` + label for 的文本字段（原来手写、没有 id）。 */
    const values = {};
    for (const f of fm.NOTE_CARD_FIELDS) values[f.key] = cfg.noteCardStyle[f.key];
    const items = [];
    for (const f of fm.NOTE_CARD_FIELDS) {
      const spec = f.type === 'color'
        ? Object.assign({}, f, { onChange: (v) => { if (v) saveNested({ noteCardStyle: { [f.key]: v } }); } })
        : Object.assign({}, f, { onChange: undefined });
      const c = ui.Fields.create(spec, values[f.key], { idPrefix: 'fld-nc-' });
      items.push({ spec, ctrl: c });
      if (f.type !== 'color') {
        /* 文本类字段没有 spec.onChange 通道：直接监听内部 input 的 change（与旧实现同语义） */
        const inp = c.el.querySelector('input');
        if (inp) inp.addEventListener('change', () => saveNested({ noteCardStyle: { [f.key]: inp.value } }));
      }
    }
    ui.Fields.layout(items, box);
    const s = cfg.noteCardStyle;
    const pv = $('nc-preview');
    pv.style.background = s.bgColor;
    pv.style.color = s.textColor;
    pv.style.border = s.borderWidth + ' solid ' + s.borderColor;
    pv.style.borderRadius = s.borderRadius;
    pv.style.boxShadow = s.shadow;
    pv.style.maxWidth = s.maxWidth;
    pv.style.opacity = s.opacity;
    pv.style.fontSize = s.fontSize;
  }

  $('btn-nc-reset').addEventListener('click', async () => {
    if (!await mutate(() => KH.Store.patch({ noteCardStyle: KH.Config.defaults.noteCardStyle }))) return;
    D.toast('已恢复默认卡片样式', 'ok');
  });

  /* ==================================================================== ⑤ 站点 */

  /* 文案单一来源在 FieldMap（弹窗下拉与列表展示共用一套，避免"同一个下拉两套说法"） */
  const SCOPE_TEXT = fm.SITE_SCOPE_TEXT;
  const MATCH_TEXT = fm.SITE_MATCH_TEXT;

  function renderSites() {
    const box = $('site-rule-list');
    clear(box);
    const rules = cfg.siteRules || [];
    if (!rules.length) {
      box.appendChild(emptyGuide('🌐', '还没有站点规则：默认所有网站都会高亮', [
        '只想在某几个站生效 → 加一条「白名单」，写上域名。',
        '某个站太吵想关掉 → 加一条「黑名单」，写上域名。',
        '规则按域名匹配；不确定时就先留空，默认全站生效。'
      ]));
    } else {
      for (const r of rules) {
        const isWhite = r.type === 'whitelist';
        const row = h('div', { class: 'kh-site-row' }, [
          h('span', { class: 'kh-tag ' + (isWhite ? 'kh-tag-ok' : 'kh-tag-no'), text: isWhite ? '✅ 白名单' : '🚫 黑名单' }),
          h('span', { class: 'kh-site-pattern', text: r.pattern }),
          h('span', { class: 'kh-site-meta', text: (SCOPE_TEXT[r.scope] || '域名') + ' · ' + (MATCH_TEXT[r.matchType] || '精确') })
        ]);
        const ops = h('span', { class: 'kh-row-ops' });
        const edit = h('button', { class: 'kh-link-btn', type: 'button', text: '编辑' });
        const del = h('button', { class: 'kh-link-btn kh-link-danger', type: 'button', text: '删除' });
        edit.addEventListener('click', () => openSiteRule(r));
        del.addEventListener('click', async () => {
          const ok = await D.confirmBox('删除规则「' + r.pattern + '」？', { title: '删除站点规则', danger: true, saveLabel: '删除' });
          if (!ok) return;
          await mutate(() => KH.Store.patch({ siteRules: (cfg.siteRules || []).filter(x => x !== r) }));
        });
        ops.appendChild(edit); ops.appendChild(del);
        row.appendChild(ops);
        box.appendChild(row);
      }
    }

    const dis = $('site-disabled-list');
    clear(dis);
    const hosts = Object.keys(cfg.siteDisabledMap || {});
    if (!hosts.length) {
      dis.appendChild(h('span', { class: 'kh-muted', text: '当前没有被临时禁用的站点。' }));
    } else {
      for (const host of hosts) {
        const btn = h('button', { class: 'kh-mini-btn', type: 'button', text: host + ' ✕', title: '点击恢复该站点高亮' });
        btn.addEventListener('click', async () => {
          const map = Object.assign({}, cfg.siteDisabledMap);
          delete map[host];
          await mutate(() => KH.Store.patch({ siteDisabledMap: map }));
        });
        dis.appendChild(btn);
      }
    }
  }

  function openSiteRule(rule) {
    const r = rule || { type: 'blacklist', pattern: '', matchType: 'exact', scope: 'domain' };
    /* 统一走共享字段工厂（原先是四处手写 `.kh-fld`，没有 id/for） */
    const fb = fieldBody(fm.SITE_RULE_FIELDS, r, { idPrefix: 'fld-sr-' });

    ui.Modal.open({
      title: rule ? '编辑站点规则' : '添加站点规则', size: 'sm',
      body: fb.body,
      onSave: async () => {
        const v = fb.read();
        const p = String(v.pattern || '').trim();
        if (!p) { D.toast('请填写站点或网址', 'error'); return false; }
        const item = { type: v.type, pattern: p, matchType: v.matchType, scope: v.scope };
        const list = (cfg.siteRules || []).slice();
        const idx = rule ? list.indexOf(rule) : -1;
        if (idx >= 0) list[idx] = item; else list.push(item);
        await mutate(() => KH.Store.patch({ siteRules: list }));
        D.toast('站点规则已保存', 'ok');
      }
    });
  }

  $('btn-site-add').addEventListener('click', () => openSiteRule(null));

  /* ==================================================================== ⑥ 导入导出 */

  const expScope = () => ({
    keywords: $('exp-keywords').checked,
    siteRules: $('exp-site').checked,
    siteDisabled: $('exp-disabled').checked,
    styles: $('exp-styles').checked
  });
  const impScope = () => ({
    keywords: $('imp-keywords').checked,
    siteRules: $('imp-site').checked,
    siteDisabled: $('imp-disabled').checked,
    styles: $('imp-styles').checked
  });
  const impMode = () => (document.querySelector('input[name=imp-mode]:checked') || {}).value || 'merge';

  function stamp() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes());
  }

  $('btn-export-json').addEventListener('click', () => {
    const sc = expScope();
    if (!sc.keywords && !sc.siteRules && !sc.siteDisabled && !sc.styles) { D.toast('请至少勾选一块内容', 'error'); return; }
    KH.Store.download('keyword-highlighter-' + stamp() + '.json', KH.Store.exportJSON(sc, cfg), 'application/json');
    D.toast('已导出 JSON', 'ok');
  });

  $('btn-export-csv').addEventListener('click', () => {
    KH.Store.download('keyword-highlighter-keywords-' + stamp() + '.csv', KH.Store.exportCSV(cfg), 'text/csv');
    D.toast('已导出 CSV（关键词、组合方向等 18 列）', 'ok');
  });

  /* Excel 表格导出：.xls = HTML 单表，Excel 原生识别 */

  $('btn-export-xls').addEventListener('click', () => {

    KH.Store.download('keyword-highlighter-keywords-' + stamp() + '.xls', KH.Store.exportExcelTable(cfg), 'application/vnd.ms-excel');

    D.toast('已导出 Excel 表格（可直接用 Excel 打开）', 'ok');

  });

  $('btn-import-json').addEventListener('click', () => { $('file-json').value = ''; $('file-json').click(); });
  $('btn-import-csv').addEventListener('click', () => { $('file-csv').value = ''; $('file-csv').click(); });

  /* ---------------- 分享码（2.0.16.8 · m21072） ----------------
   * 把「关键词 + 图片识别 + 进表后缀 + 指向」打包成一段文本，粘给别人就能收到。
   * 与导出 JSON 同源（KH.Store.exportShare → sharePayload → exportJSON），所以不会出现
   * 「分享码里有、导出文件里没有」这种两套白名单的漂移。导入复用 importJSON 的合并口径。 */
  $('btn-share-copy').addEventListener('click', async () => {
    const res = await KH.Store.exportShare(cfg);
    if (!res.ok) { D.toast('生成分享码失败：' + res.error, 'error'); return; }
    const ta = $('share-code-text');
    if (ta) ta.value = res.code;
    let copied = false;
    try { await navigator.clipboard.writeText(res.code); copied = true; } catch (e) { /* 没有剪贴板权限就退化成手抄 */ }
    const hint = $('share-code-hint');
    if (hint) {
      hint.textContent = res.code.length + ' 个字符（' + Math.max(1, Math.round(res.jsonBytes / 1024)) + ' KB 配置压到 '
        + Math.max(1, Math.round(res.bytes / 1024)) + ' KB）' + (copied ? '，已复制到剪贴板' : '；下面文本框里已填好，可手动复制');
    }
    D.toast(copied ? '分享码已复制' : '分享码已生成，请从下面的文本框复制', copied ? 'ok' : 'error');
  });

  /**
   * 分享码导入清单（2.0.18 · m24051）
   * 用户口径：「导入时候要能列出有哪些词，自主选择添加哪个」；重复项标出来、默认不勾，
   * **勾上重复项 = 覆盖本机那一条**（不是跳过）。三类数据各一组，组头是全选。
   */
  function sharePickBody(plan, state) {
    const wrap = h('div', { class: 'kh-share-pick' });
    const SECS = [
      { key: 'keywords', title: '关键词', unit: '条', rows: plan.keywords || [] },
      { key: 'groups', title: '分组', unit: '个', rows: plan.groups || [] },
      { key: 'siteRules', title: '站点规则', unit: '条', rows: plan.siteRules || [] }
    ];
    for (const sec of SECS) {
      if (!sec.rows.length) continue;
      const dupN = sec.rows.filter(r => r.dup).length;
      const all = h('input', { type: 'checkbox', class: 'kh-share-all' });
      const cnt = h('span', { class: 'kh-share-cnt' });
      const syncAll = () => {
        const n = sec.rows.filter(r => state[sec.key].has(r.idx)).length;
        all.checked = n === sec.rows.length;
        all.indeterminate = n > 0 && n < sec.rows.length;
        cnt.textContent = '已选 ' + n + ' / ' + sec.rows.length;
      };
      all.addEventListener('change', () => {
        state[sec.key] = new Set(all.checked ? sec.rows.map(r => r.idx) : []);
        for (const el of wrap.querySelectorAll('[data-sec="' + sec.key + '"]')) el.checked = all.checked;
        syncAll();
      });
      const head = h('div', { class: 'kh-share-sec-hd' }, [
        all,
        h('b', { text: sec.title + ' ' + sec.rows.length + ' ' + sec.unit + (dupN ? '（本机已有 ' + dupN + ' 项）' : '') }),
        cnt
      ]);
      const list = h('div', { class: 'kh-share-sec-body' });
      for (const r of sec.rows) {
        const cb = h('input', { type: 'checkbox' });
        cb.checked = state[sec.key].has(r.idx);
        cb.setAttribute('data-sec', sec.key);
        cb.setAttribute('data-idx', String(r.idx));
        cb.addEventListener('change', () => {
          if (cb.checked) state[sec.key].add(r.idx); else state[sec.key].delete(r.idx);
          syncAll();
        });
        list.appendChild(h('label', { class: 'kh-share-row' + (r.dup ? ' is-dup' : '') }, [
          cb,
          h('span', { class: 'kh-share-txt', text: r.label || '（空）' }),
          r.dup ? h('span', { class: 'kh-share-tag', text: '已有，勾上覆盖' }) : null
        ]));
      }
      const boxEl = h('section', { class: 'kh-share-sec' }, [head, list]);
      boxEl.setAttribute('data-key', sec.key);
      wrap.appendChild(boxEl);
      syncAll();
    }
    /* 样式与图片识别档位是整块配置，没有逐条口径：给一个开关，默认勾 */
    const scb = h('input', { type: 'checkbox' });
    scb.checked = state.styles !== false;
    scb.addEventListener('change', () => { state.styles = scb.checked; });
    wrap.appendChild(h('label', { class: 'kh-share-row kh-share-style' }, [
      scb, h('span', { class: 'kh-share-txt', text: '连带样式 / 比对设置 / 图片识别档位（整块按合并口径写入）' })
    ]));
    return wrap;
  }

  $('btn-share-import').addEventListener('click', async () => {
    const ta = $('share-code-text');
    const code = String((ta && ta.value) || '').trim();
    if (!code) { D.toast('先把别人给你的分享码粘贴到下面的文本框', 'error'); if (ta) ta.focus(); return; }
    let plan = null;
    try { plan = await KH.Store.planShare(code, cfg); }
    catch (err) { D.toast('分享码读不出来：' + ((err && err.message) || err), 'error'); return; }
    const empty = !plan.keywords.length && !plan.groups.length && !plan.siteRules.length;
    if (empty && !plan.hasStyles) { D.toast('这份分享码里没有可导入的内容', 'error'); return; }
    /* 默认只勾「本机没有的」：同名/同内容的默认不勾，用户手动勾上就是覆盖 */
    const state = {
      keywords: new Set(plan.keywords.filter(r => !r.dup).map(r => r.idx)),
      groups: new Set(plan.groups.filter(r => !r.dup).map(r => r.idx)),
      siteRules: new Set(plan.siteRules.filter(r => !r.dup).map(r => r.idx)),
      styles: !!plan.hasStyles
    };
    const ok = await new Promise((resolve) => {
      KH.ui.Modal.open({
        title: '导入分享码（选择要添加的项）',
        body: sharePickBody(plan, state),
        size: 'md',
        saveLabel: '导入所选',
        onSave: () => {
          if (!state.keywords.size && !state.groups.size && !state.siteRules.size && !state.styles) {
            D.toast('一项都没选：勾上要导入的内容再点「导入所选」', 'error');
            return false;
          }
          resolve(true);
          return true;
        },
        onClose: () => resolve(false)
      });
    });
    if (!ok) return;
    const pick = {
      keywords: Array.from(state.keywords), groups: Array.from(state.groups),
      siteRules: Array.from(state.siteRules), styles: state.styles !== false
    };
    let stats = null;
    const wrote = await mutate(async () => { stats = await KH.Store.importPicked(code, pick, cfg); });
    if (!wrote) return;
    const parts = ['新增关键词 ' + stats.keywords + ' 条'];
    if (stats.groups) parts.push('分组 ' + stats.groups + ' 个');
    if (stats.siteRules) parts.push('站点规则 ' + stats.siteRules + ' 条');
    if (stats.replaced) parts.push('覆盖本机已有 ' + stats.replaced + ' 项');
    D.toast('分享码导入完成：' + parts.join(' / '), 'ok');
  });

  /**
   * JSON 导入 —— **唯一实现**。
   * 「导入导出」页两个按钮和「关键词管理」页的批量导入都走这里：
   * 导入是要覆盖/合并用户数据的破坏性操作，绝不能存在第二份"简化版"逻辑
   * （两份逻辑迟早一份忘了确认框、一份忘了勾选范围）。
   */
  async function importJSONText(text) {
    let preview = null;
    try { preview = KH.Store.previewJSON(text); } catch (err) { D.toast('JSON 解析失败：' + err.message, 'error'); return; }
    const has = preview.has;
    const sc = impScope();
    const nothing = !(sc.keywords && has.keywords) && !(sc.siteRules && has.siteRules)
      && !(sc.siteDisabled && has.siteDisabled) && !(sc.styles && has.styles);
    if (nothing) { D.toast('文件内容与勾选范围没有交集，请调整勾选', 'error'); return; }

    const mode = impMode();
    const lines = [
      '文件包含：' + [has.keywords ? '关键词' : '', has.siteRules ? '站点规则' : '', has.siteDisabled ? '禁用状态' : '', has.styles ? '样式配置' : ''].filter(Boolean).join('、'),
      '导入方式：' + (mode === 'merge' ? '合并（追加去重）' : '覆盖（替换被勾选的块）')
    ];
    if (mode === 'overwrite') lines.push('', '⚠️ 覆盖会清掉现有对应数据，建议先导出备份。');
    const ok = await D.confirmBox(lines.join('\n'), { title: '确认导入', danger: mode === 'overwrite', saveLabel: '开始导入' });
    if (!ok) return;
    try {
      let stats = null;
      const wrote = await mutate(async () => { stats = await KH.Store.importJSON(text, { include: sc, mode }, cfg); });
      if (!wrote) return;
      D.toast('导入完成：新增关键词 ' + stats.keywords + ' 条 / 分组 ' + stats.groups + ' 个 / 站点规则 ' + stats.siteRules + ' 条', 'ok');
    } catch (err) {
      D.toast('导入失败：' + err.message, 'error');
    }
  }

  /* ---------------- CSV 导入：预览 → 写盘 → 可撤销（2.0.8.13 需求②） ----------------
   * 旧版选完文件就直接写，导错一次只能重置或手工删。现在三件事：
   *   ① 预览：新增 / 重复跳过 / 无法解析三类计数 + 前 20 行明细（坏行标红给原因）；
   *   ② 确认才写，写之前把 keywords/groups 快照进 `chrome.storage.session`；
   *   ③ 十分钟内可「撤销上次导入」，一键回滚到导入前。
   * 判据只有一份：`KH.Store.previewCSV` 与 `KH.Store.importCSV` 共用 `planCSV`，
   * 否则"预览说 12 条、进去 9 条"这种漂移迟早会出现。 */
  const UNDO_KEY = 'kh.importUndo';
  const UNDO_TTL_MS = 10 * 60 * 1000;

  function sessionArea() {
    try { return (chrome.storage && chrome.storage.session) ? chrome.storage.session : null; } catch (e) { return null; }
  }

  async function putUndo(snap) {
    const area = sessionArea();
    if (!area) return false;
    try { await area.set({ [UNDO_KEY]: snap }); return true; } catch (e) { return false; }
  }

  async function getUndo() {
    const area = sessionArea();
    if (!area) return null;
    try {
      const got = await area.get(UNDO_KEY);
      const snap = got && got[UNDO_KEY];
      if (!snap || !Array.isArray(snap.keywords)) return null;
      if (Date.now() - Number(snap.at || 0) > UNDO_TTL_MS) { await area.remove(UNDO_KEY); return null; }
      return snap;
    } catch (e) { return null; }
  }

  async function clearUndo() {
    const area = sessionArea();
    if (!area) return;
    try { await area.remove(UNDO_KEY); } catch (e) { /* 清不掉不影响主流程 */ }
  }

  /** 撤销行：有快照才出现；显示"刚才导入了什么、还剩几分钟" */
  async function refreshUndoRow() {
    const row = $('undo-row');
    if (!row) return;
    const snap = await getUndo();
    row.hidden = !snap;
    if (snap) {
      const hint = $('undo-hint');
      const mins = Math.max(1, Math.ceil((UNDO_TTL_MS - (Date.now() - Number(snap.at || 0))) / 60000));
      if (hint) {
        hint.textContent = '上一次导入：新增 ' + Number(snap.added || 0) + ' 条、跳过重复 '
          + Number(snap.skipped || 0) + ' 条（' + mins + ' 分钟内可撤销）';
      }
    }
  }

  /** 预览表：三类计数 + 前 20 行（坏行标红并写原因） */
  function csvPreviewBody(plan) {
    const st = plan.stats || {};
    const wrap = h('div', { class: 'kh-csv-prev' });
    wrap.appendChild(h('div', { class: 'kh-csv-prev-sum' }, [
      h('span', { class: 'kh-csv-badge is-add', text: '新增 ' + (st.added || 0) }),
      h('span', { class: 'kh-csv-badge is-dup', text: '重复跳过 ' + (st.skipped || 0) }),
      h('span', { class: 'kh-csv-badge is-bad', text: '无法解析 ' + (st.bad || 0) })
    ]));
    if (st.groupsCreated) {
      wrap.appendChild(h('p', { class: 'kh-dim', text: '会顺带新建分组 ' + st.groupsCreated + ' 个（按 CSV 里的组名）' }));
    }
    const rows = (plan.rows || []).slice(0, 20);
    const table = h('table', { class: 'kh-csv-table' });
    table.appendChild(h('thead', {}, [h('tr', {}, [
      h('th', { text: '行' }), h('th', { text: '关键词' }), h('th', { text: '分组' }), h('th', { text: '结果' })
    ])]));
    const tb = h('tbody');
    for (const r of rows) {
      const cls = r.action === 'bad' ? 'is-bad' : (r.action === 'dup' ? 'is-dup' : '');
      tb.appendChild(h('tr', { class: cls }, [
        h('td', { text: String(r.line) }),
        h('td', { text: r.kwText || '（空）' }),
        h('td', { text: r.group || '—' }),
        h('td', { text: r.action === 'add' ? '新增' : (r.action === 'dup' ? '跳过：重复' : String(r.reason || '无法解析')) })
      ]));
    }
    table.appendChild(tb);
    wrap.appendChild(table);
    if ((plan.rows || []).length > rows.length) {
      wrap.appendChild(h('p', { class: 'kh-dim', text: '只列出前 ' + rows.length + ' 行，文件里共 ' + plan.rows.length + ' 行' }));
    }
    return wrap;
  }

  async function importCSVText(text) {
    let plan = null;
    try { plan = KH.Store.previewCSV(text, cfg); }
    catch (err) { D.toast('CSV 导入失败：' + err.message, 'error'); return; }

    const st = plan.stats || {};
    const added = Number(st.added || 0);
    if (!added) {
      D.toast('这份 CSV 没有可导入的新关键词（重复 ' + (st.skipped || 0) + ' 条、无法解析 ' + (st.bad || 0) + ' 条）', 'error');
      return;
    }

    const ok = await new Promise((resolve) => {
      KH.ui.Modal.open({
        title: '导入 CSV 预览',
        body: csvPreviewBody(plan),
        size: 'md',
        saveLabel: '导入 ' + added + ' 条',
        onSave: () => { resolve(true); return true; },
        onClose: () => resolve(false)
      });
    });
    if (!ok) return;

    const snap = {
      keywords: (cfg.keywords || []).slice(),
      groups: (cfg.groups || []).slice(),
      at: Date.now(),
      added: added,
      skipped: Number(st.skipped || 0)
    };
    const hasUndo = await putUndo(snap);
    let stats = null;
    const wrote = await mutate(async () => { stats = await KH.Store.importCSV(text, cfg); });
    if (!wrote) { await clearUndo(); return; }
    await refreshUndoRow();
    D.toast('CSV 导入完成：新增 ' + stats.added + ' 条，跳过重复 ' + stats.skipped + ' 条'
      + (stats.groupsCreated ? '，新建分组 ' + stats.groupsCreated + ' 个' : '')
      + (hasUndo ? '。可在「导入导出」撤销这次导入' : ''), 'ok');
  }

  /**
   * 「📥 批量导入」：一个入口吃 CSV + JSON（按扩展名分发，扩展名缺失时按 MIME 兜底）。
   * 比让用户先想清楚"我要导的是哪种格式"更省事，且两条分支各自复用的仍是同一份实现。
   */
  async function importAnyFile(file) {
    if (!file) return;
    const name = String(file.name || '');
    const isCsv = /\.csv$/i.test(name) || (!/\.json$/i.test(name) && /csv/i.test(file.type || ''));
    const text = await file.text();
    if (isCsv) await importCSVText(text);
    else await importJSONText(text);
  }

  $('file-json').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) await importJSONText(await file.text());
  });

  $('file-csv').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) await importCSVText(await file.text());
  });

  const uiThemeSel = $('ui-theme');
  if (uiThemeSel) {
    uiThemeSel.addEventListener('change', async () => {
      const next = uiThemeSel.value;
      const ok = await mutate(() => KH.Store.patch({ uiTheme: next }));
      if (!ok) { syncTheme(); return; }
      syncTheme();
      D.toast('外观已切换：' + (next === 'auto' ? '跟随系统' : (next === 'dark' ? '深色' : '浅色')), 'ok');
    });
  }

  const undoImportBtn = $('btn-undo-import');
  if (undoImportBtn) {
    undoImportBtn.addEventListener('click', async () => {
      const snap = await getUndo();
      if (!snap) { D.toast('撤销窗口已过期（只保留 10 分钟）', 'error'); await refreshUndoRow(); return; }
      const ok = await D.confirmBox(
        '撤销会把这期间的关键词与分组回滚到导入前（导入后你手动改过的也会一起回滚）。确定撤销？',
        { title: '撤销上次导入', danger: true, saveLabel: '撤销' }
      );
      if (!ok) return;
      const wrote = await mutate(() => KH.Store.patch({ keywords: snap.keywords, groups: snap.groups }));
      if (!wrote) return;
      await clearUndo();
      await refreshUndoRow();
      D.toast('已撤销上次导入', 'ok');
    });
  }

  $('btn-reset').addEventListener('click', async () => {
    const sc = {
      keywords: $('rst-keywords').checked,
      siteRules: $('rst-site').checked,
      siteDisabled: $('rst-site').checked,
      styles: $('rst-styles').checked
    };
    /* 【2.0.15】读正文缓存也进这组勾选：隐私说明里承诺「设置页可随时清空」，
     * 而它不在配置里（chrome.storage.local 的 khPolicyCacheV3），得单独请后台清。 */
    const clearCache = $('rst-cache').checked;
    if (!sc.keywords && !sc.siteRules && !sc.styles && !clearCache) { D.toast('请至少勾选一块内容', 'error'); return; }
    const ok = await D.confirmBox(
      '将清空：' + [sc.keywords ? '关键词与分组' : '', sc.siteRules ? '站点规则/禁用状态' : '', sc.styles ? '样式与配置' : '', clearCache ? '读正文缓存' : ''].filter(Boolean).join('、')
      + '\n\n⚠️ 此操作不可撤销，建议先导出备份。',
      { title: '重置数据', danger: true, saveLabel: '确认重置' }
    );
    if (!ok) return;
    /* 只勾了缓存时不要去动配置：Store.reset 对空选择没有意义，还会白写一次。 */
    if (sc.keywords || sc.siteRules || sc.styles) {
      if (!await mutate(() => KH.Store.reset(sc, cfg))) return;
    }
    if (clearCache) {
      try { chrome.runtime.sendMessage({ type: KH.MSG.POLICY_CACHE_CLEAR }, () => { void chrome.runtime.lastError; }); } catch (e) { /* 后台没醒就算了 */ }
    }
    D.toast('已重置', 'ok');
  });

  /* ==================================================================== ⑦ 匹配默认值与性能 */

  const PF_KEYS = ['shadowDOMEnabled', 'suspendInactiveTab', 'pageResidualClean', 'pageRebuildOnChange', 'scanCollapsedCustom'];

  /** 数字输入框的 min/max 注入（唯一入口）。HTML 里一个数字边界都不写死 —— 属性只是提示，
   *  浏览器不禁手填，真值只认 config 的边界常量（T26 立的样板，2.0.2.6 需求③ 补齐其余字段）。 */
  function limitInput(el, min, max) { el.min = min; el.max = max; }

  /* ---- 置顶排序（2.0.2.6 需求②）：下拉框选择 + 胶囊展示 ---- */

  /** 候选分组：label 与筛选栏「全部类型」逐字一致（类型判定只认 `typeOf` 一处，别养第二套说法）。 */
  const PIN_GROUPS = [
    ['plain', '普通词'],
    ['lr', '组合词（左右格）'],
    ['tb', '组合词（上下格）'],
    ['fetch', '仅抓取'],
    ['rare', '罕见字']
  ];

  /** 一个候选关键词在下拉里的名字 */
  function pinLabel(kw, t) {
    if (t === 'rare') return '罕见字';
    const core = String(kw.text || '').trim();
    if (t === 'fetch') return String(kw.cellVerify || '').trim() || core || '（未命名）';
    const base = core || '（未命名）';
    /* 组合词带上标题词才分得清「价格（左右格）」与「价格（上下格）」——这个 × 与关键词表格同形 */
    if (t === 'lr' || t === 'tb') return base + ' × ' + (String(kw.cellVerify || '').trim() || '（未设标题词）');
    return base;
  }

  /**
   * 置顶排序的**回显 + 候选重建**（每次 renderAll 都跑：关键词增删改后候选要跟着变）。
   *
   * 落盘的是**关键词 id**，不是卡片文本（2.0.2.6 换的口径）。原因两条，都绕不过去：
   *   ① 正则词的卡片文本是**运行时命中的页面文本**、罕见字的卡片文本是那个生僻字 ——
   *      配置侧枚举不出来，做成候选就是永远匹配不上的死选项；
   *   ② 「普通词 价格」与「组合词 价格×单价」的卡片文本都是「价格」（`head.build` 里 `kw` 取
   *      `meta.text`，组合词只有命中时才带上片段），只有 id 分得开。
   * 面板按 `meta.pinId`（= 规则 `ruleId`）匹配：id 是配置侧与卡片侧**唯一都有的**稳定键。
   * 2.0.2.5 存下来的手写文本仍然生效（`head.sortByPins` 两路都认），所以这里对认不出 id 的旧值
   * 就**原样显示**、不做"未生效"的判定 —— 它很可能正是靠文本匹配生效的那个。
   */
  function renderPinOrder() {
    const sel = $('pf-notePinOrder');
    const caps = $('pin-caps');
    $('pin-max').textContent = KH.Config.NOTE_PIN_MAX;    // 上限只有 NOTE_PIN_MAX 一处，标签里的数字也从它来
    const cur = KH.Config.pinOrderKeys((cfg.importantNote || {}).pinOrder);
    const live = (cfg.keywords || []).filter((kw) => kw && kw.enabled !== false);
    const byId = new Map();
    for (const kw of live) if (kw.id) byId.set(String(kw.id).toLowerCase(), kw);
    /** 种类 → 分组标题（`PIN_GROUPS` 是唯一真源；下面两处都要用它，别各查一遍） */
    const groupLabel = new Map(PIN_GROUPS);

    clear(sel);
    sel.appendChild(h('option', { value: '', text: '选择要置顶的关键词…' }));
    for (const [t, glabel] of PIN_GROUPS) {
      const list = live.filter((kw) => typeOf(kw) === t);
      if (!list.length) continue;
      const og = h('optgroup', { label: glabel });
      for (const kw of list) {
        const id = String(kw.id);
        /* 已置顶的不再出现在候选里：同一个词只能占一个位次，要换位置先 ✕ 掉再选。 */
        const taken = cur.some((v) => String(v).toLowerCase() === id.toLowerCase());
        og.appendChild(h('option', { value: id, disabled: taken, text: pinLabel(kw, t) + (taken ? '（已置顶）' : '') }));
      }
      sel.appendChild(og);
    }
    sel.value = '';

    clear(caps);
    cur.forEach((v, i) => {
      const kw = byId.get(String(v).toLowerCase());
      const t = kw ? typeOf(kw) : '';
      const name = kw ? ((groupLabel.get(t) || '') + ' · ' + pinLabel(kw, t)) : v;
      /* 胶囊骨架走共享工厂（与「抓取字段」那排胶囊同一份结构，见 fields.js labelChip）。
       * 这里**不传 onClick** —— 置顶位次不可原地改，要换先 ✕ 再选。 */
      caps.appendChild(ui.Fields.labelChip({
        name: (i + 1) + '. ' + name,
        chipTitle: kw ? ('置顶第 ' + (i + 1) + ' 位 · ' + name) : ('按关键词文字匹配（旧写法）· ' + v),
        delTitle: kw ? ('取消置顶：' + name) : ('取消这一项（按文字匹配的旧写法）'),
        onDelete: async () => {
          await saveNested({ importantNote: { pinOrder: KH.Config.normalizePinOrder(cur.filter((x) => x !== v)) } });
        }
      }));
    });
  }

  function renderPerf() {
    const ms = cfg.matchSettings || {};
    $('ms-defaultCaseSensitive').checked = !!ms.defaultCaseSensitive;
    $('ms-defaultWholeWord').checked = !!ms.defaultWholeWord;
    $('ms-defaultUseRegex').checked = !!ms.defaultUseRegex;

    for (const k of PF_KEYS) $('pf-' + k).checked = !!cfg[k];
    $('pf-changeHandling').value = (cfg.changeHandling === 'always') ? 'always' : 'smart';
    /* 变更处理方式只在「页面内容变化时自动重建」开着时才生效：那一条关掉后 `scheduler.setupObserver`
     * 连 MutationObserver 都不建（scheduler.js），这个下拉怎么切都不会有任何作用。
     * 禁用 + 一行说明，好过让用户对着一个不生效的值反复切。`mutate()` 走 `renderAll()`，
     * 所以勾选状态一变这里会自己刷新，不需要额外接线。 */
    const chOn = cfg.pageRebuildOnChange !== false;
    $('pf-changeHandling').disabled = !chOn;
    $('pf-changeHandling-hint').textContent = chOn
      ? ''
      : '上面「页面内容变化时自动重建」关着 ⇒ 这一项无论选哪个都不生效';
    $('pf-silent').value = cfg.pageRebuildSilentMs;
    $('pf-gap').value = cfg.pageRebuildGapMs;
    /* 有区间的三个数字输入，min/max 一律从 config 的边界常量注入（HTML 里不写死）：属性、JS 校验、
     * 面板夹紧各抄一份就是"能填进非法值 / 填了不生效"的种子。（`pf-silent`/`pf-gap` 只有下界 0、
     * 没有上界，两侧写的是同一个 0、没有可漂的余地，就不为这个恒等常量再建一层常量了。） */
    limitInput($('pf-imgSize'), KH.Config.IMG_SIZE_MIN, KH.Config.IMG_SIZE_MAX);
    $('pf-imgSize').value = (cfg.importantNote || {}).imgSize || '';
    limitInput($('pf-noteFontSize'), KH.Config.NOTE_FONT_MIN, KH.Config.NOTE_FONT_MAX);
    $('pf-noteFontSize').value = (cfg.importantNote || {}).fontSize || '';
    limitInput($('pf-notePanelWidth'), KH.Config.PANEL_WIDTH_MIN, KH.Config.PANEL_WIDTH_MAX);
    $('pf-notePanelWidth').value = cfg.notePanelWidth;
    /* 置顶排序（2.0.2.6 需求②）：候选与回显都要重建（关键词表变了候选就得跟着变）。 */
    renderPinOrder();
    /* 【2.0.14 需求二】分页开关回显（默认关）。 */
    $('pf-notePaged').checked = !!(cfg.importantNote || {}).pagedTabs;
    /* 【2.0.15 · 问题②】同法人校验回显（默认关）。 */
    $('pf-noteEntityCheck').checked = !!(cfg.importantNote || {}).entityCheck;
    /* 【2.0.16.7 · m20763】四条通道开关回显：只有明确的 false 算关，缺键按开。 */
    const ech = (cfg.importantNote || {}).entityChannels || {};
    [['sogou', 'pf-ent-sogou'], ['aiqicha', 'pf-ent-aiqicha'], ['so360', 'pf-ent-so360'], ['ai', 'pf-ent-ai']].forEach((pair) => {
      const box = $(pair[1]);
      if (box) box.checked = ech[pair[0]] !== false;
    });
    syncEntityChannelBoxes();
  /* 【2.0.16.4 · m19385】默认开：读不到正文时允许开后台标签页（用户选 P4-A）。 */
  $('pf-policyRenderTab').checked = ((cfg.policy || {}).renderTab !== false);
    /* 【2.0.8.4 需求④】AI 助手的接口配置（与上面那块"重要笔记"同属样式/配置页）。 */
    renderAiForm();
    /* 【2.0.17.5 · m26374】AI 深查开关 + 风险词库（内置基线 + 自定义 + 逐词停用）。 */
    $('pf-riskAuto').checked = ((cfg.importantNote || {}).riskAuto !== false);
    renderRiskLexicon();
    wireRiskLexiconButtons();
    /* 【2.0.8.6 需求①】图文合并的标题表（字段 → 自定义标题 + 默认不展示）。 */
    renderMergeForm();
    /* 【T5】校验中心：只画不判，口径全在 compare/center.js 的 summary(cfg)。 */
    renderCheckCenter();
  }

  /* ---- 【2.0.17.5 · 用户 m26374】风险词库 ----
   * C 档口径：内置词表（源码常量）直接生效，用户只能**逐词停用**；自定义词可增删；
   * 导入 / 导出 JSON 让词表能跨机搬；D 档（远端订阅清单）只存地址，本版不联网拉取。
   * 归一的真源是 `KH.Config.normalizeRiskLexicon`（保存前归一、回显也走它），本文件不另写一套口径。 */
  let riskLexWired = false;
  const RISK_CAT_LABEL = { app: '违规应用名', brand: '品牌', gamble: '赌博', porn: '色情低俗', fund: '资金盘', fraud: '诈骗', loan: '违规贷款', other: '其它' };
  const RISK_CAT_OPTS = [
    ['app', '违规应用名（判仿冒）'],
    ['brand', '正规品牌（判同名 / 蹭品牌）'],
    ['gamble', '赌博'],
    ['porn', '色情低俗'],
    ['fund', '资金盘'],
    ['fraud', '诈骗'],
    ['loan', '违规贷款'],
    ['other', '其它']
  ];

  function riskLexOf() {
    const n = KH.Config.normalizeRiskLexicon;
    return (typeof n === 'function') ? n(cfg.riskLexicon) : (cfg.riskLexicon || { custom: [], disabled: [], remoteUrl: '' });
  }

  function riskLexSave(patch) {
    const next = KH.Config.normalizeRiskLexicon(Object.assign({}, riskLexOf(), patch || {}));
    return saveNested({ riskLexicon: next }).then(renderRiskLexicon);
  }

  function riskLexEl(tag, cls, props) {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    Object.keys(props || {}).forEach((k) => {
      if (k === 'text') el.textContent = props[k];
      else el.setAttribute(k, props[k]);
    });
    return el;
  }

  function renderRiskLexicon() {
    const box = $('risk-lex-list');
    if (!box) return;
    if (!riskLexWired) { riskLexWired = true; wireRiskLexicon(); }
    const lx = riskLexOf();
    const RA = KH.RiskAudit;
    const norm = (w) => (RA && RA.normalizeName ? RA.normalizeName(w) : String(w || '').toLowerCase());
    const off = {};
    (lx.disabled || []).forEach((w) => { const k = norm(w); if (k) off[k] = true; });
    const customs = lx.custom || [];
    const builtins = [];
    const groups = [];
    (RA ? RA.BRANDS : []).forEach((w) => builtins.push(w));
    /* 【2.0.19 · 用户 m27658】违规应用名单独一组：这一组判的是「像哪款违规应用」。 */
    const appWords = [];
    (RA && RA.APPS ? RA.APPS : []).forEach((g) => { (g.words || []).forEach((w) => appWords.push(w)); });
    if (appWords.length) groups.push({ cat: 'app', tag: '违规应用名', words: appWords });
    groups.push({ cat: 'brand', tag: '品牌', words: (RA ? RA.BRANDS : []).slice() });
    (RA ? RA.SENSITIVE : []).forEach((g) => {
      const cat = Object.keys(RISK_CAT_LABEL).find((k) => RISK_CAT_LABEL[k] === g.tag) || 'other';
      groups.push({ cat: cat, tag: g.tag, words: g.words.slice() });
    });
    customs.forEach((c) => {
      const cat = RISK_CAT_LABEL[c.cat] ? c.cat : 'other';
      let g = groups.find((x) => x.cat === cat);
      if (!g) { g = { cat: cat, tag: RISK_CAT_LABEL[cat], words: [], custom: true }; groups.push(g); }
      if (g.words.indexOf(c.w) < 0) g.words.push(c.w);
    });
    box.innerHTML = '';
    let total = 0;
    let offN = 0;
    groups.forEach((g) => {
      if (!g.words.length) return;
      const wrap = riskLexEl('div', 'kh-lex-grp');
      const hd = riskLexEl('div', 'kh-lex-grp-hd', { text: g.tag + ' · ' + g.words.length });
      wrap.appendChild(hd);
      const words = riskLexEl('div', 'kh-lex-words');
      g.words.forEach((w) => {
        const isCustom = customs.some((c) => norm(c.w) === norm(w));
        const on = !off[norm(w)];
        total += 1;
        if (!on) offN += 1;
        const row = riskLexEl('label', 'kh-lex-w' + (on ? '' : ' is-off'), { 'data-w': w, 'data-custom': isCustom ? '1' : '0' });
        const cb = riskLexEl('input', '', { type: 'checkbox' });
        cb.checked = on;
        row.appendChild(cb);
        row.appendChild(document.createTextNode(w));
        /* 备注放在 label 外面：label 里点输入框会顺手切换勾选。 */
        const item = riskLexEl('span', 'kh-lex-item', {});
        item.appendChild(row);
        if (isCustom) {
          const c0 = customs.find((c) => norm(c.w) === norm(w)) || {};
          row.appendChild(riskLexEl('span', 'kh-lex-tag', { text: '自定义' }));
          const del = riskLexEl('button', 'kh-lex-del', { type: 'button', 'data-del': w, title: '删掉这个词' });
          del.textContent = '✕';
          row.appendChild(del);
          item.appendChild(riskLexEl('input', 'kh-input kh-lex-note', { type: 'text', maxlength: '60', placeholder: '备注', 'data-note': w, value: String(c0.note || ''), title: '这个词的备注（只存本机，随导入导出走）' }));
        }
        words.appendChild(item);
      });
      wrap.appendChild(words);
      box.appendChild(wrap);
    });
    if (!total) box.appendChild(riskLexEl('p', 'kh-muted', { text: '词表是空的。' }));
    const sum = $('risk-lex-sum');
    if (sum) sum.textContent = '内置 ' + builtins.length + ' 个 · 自定义 ' + customs.length + ' 个 · 已停用 ' + offN + ' 个';
    const rem = $('risk-lex-remote');
    if (rem && document.activeElement !== rem) rem.value = lx.remoteUrl || '';
    const sel = $('risk-lex-cat');
    if (sel && !sel.options.length) {
      RISK_CAT_OPTS.forEach((pair) => sel.appendChild(riskLexEl('option', '', { value: pair[0], text: pair[1] })));
    }
  }

  function wireRiskLexicon() {
    const box = $('risk-lex-list');
    if (box) {
      box.addEventListener('change', (e) => {
        const nt = e.target;
        if (nt && nt.getAttribute && nt.getAttribute('data-note')) {
          const w = nt.getAttribute('data-note');
          const cur = riskLexOf();
          const next = cur.custom.map((c) => (c.w === w ? { w: c.w, cat: c.cat, note: String(nt.value || '').trim() } : c));
          riskLexSave({ custom: next });
          return;
        }
        const cb = e.target;
        if (!cb || cb.type !== 'checkbox') return;
        const row = cb.parentNode;
        const w = row ? row.getAttribute('data-w') : '';
        if (!w) return;
        const off = [];
        const all = box.querySelectorAll('.kh-lex-w');
        for (let i = 0; i < all.length; i++) {
          const c = all[i].querySelector('input');
          if (c && !c.checked) off.push(all[i].getAttribute('data-w'));
        }
        riskLexSave({ disabled: off });
      });
      box.addEventListener('click', (e) => {
        const btn = e.target && e.target.getAttribute ? e.target : null;
        const w = btn ? btn.getAttribute('data-del') : '';
        if (!w) return;
        const cur = riskLexOf();
        riskLexSave({ custom: cur.custom.filter((c) => c.w !== w) });
      });
      return;
    }
    /* 词表容器还没画出来时（首屏之前）不接事件 —— renderRiskLexicon 会在画出来后再进来一次。 */
  }

  function wireRiskLexiconButtons() {
    const add = $('btn-risk-lex-add');
    if (add) {
      add.addEventListener('click', () => {
        const input = $('risk-lex-word');
        const sel = $('risk-lex-cat');
        const noteEl = $('risk-lex-note');
        const w = String((input && input.value) || '').trim();
        if (!w) { D.toast('先填一个词'); return; }
        const cat = (sel && sel.value) || 'other';
        const note = String((noteEl && noteEl.value) || '').trim();
        const cur = riskLexOf();
        const next = cur.custom.filter((c) => c.w !== w).concat([{ w: w, cat: cat, note: note }]);
        riskLexSave({ custom: next }).then(() => { if (input) input.value = ''; if (noteEl) noteEl.value = ''; });
      });
    }
    const exp = $('btn-risk-lex-export');
    if (exp) {
      exp.addEventListener('click', () => {
        KH.Store.download('risk-lexicon-' + stamp() + '.json', JSON.stringify(riskLexOf(), null, 2), 'application/json');
      });
    }
    const imp = $('btn-risk-lex-import');
    const file = $('risk-lex-file');
    if (imp && file) {
      imp.addEventListener('click', () => file.click());
      file.addEventListener('change', () => {
        const f = file.files && file.files[0];
        if (!f) return;
        const rd = new FileReader();
        rd.onload = () => {
          try {
            const data = JSON.parse(String(rd.result || '{}'));
            riskLexSave({ custom: data.custom || [], disabled: data.disabled || [], remoteUrl: data.remoteUrl || '' })
              .then(() => D.toast('词表已导入'));
          } catch (err) { D.toast('这个文件不是有效的词表 JSON'); }
          file.value = '';
        };
        rd.readAsText(f);
      });
    }
    const rem = $('risk-lex-remote');
    if (rem) rem.addEventListener('change', () => riskLexSave({ remoteUrl: String(rem.value || '').trim() }));
    const ra = $('pf-riskAuto');
    if (ra) {
      ra.addEventListener('change', () => {
        saveNested({ importantNote: { riskAuto: ra.checked === true } });
      });
    }
  }

  /* ---- 【2.0.8.6 需求①】图文合并 ----
   * 用户口径：抓取字段的图片 + 它的 OCR 动态词命中 ⇒ 卡片里多一行「自定义标题 ｜ 该字段的值」，
   * 并且能配「默认不展示」。所以这里只做一件事：维护 `imgMerge.rows = [{field,title,hidden}]`。
   * 归一的真源是 `KH.Config.normalizeImgMerge`（保存前归一、回显也走它），本文件不另写一套口径。 */
  let mergeWired = false;
  function mergeRowsOf() {
    const n = KH.Config.normalizeImgMerge;
    const cur = (typeof n === 'function') ? n(cfg.imgMerge) : (cfg.imgMerge || { rows: [] });
    return cur.rows || [];
  }

  function mergeRowEl(row) {
    const box = document.createElement('div');
    box.className = 'kh-merge-row';
    const mk = (tag, cls, attrs) => {
      const el = document.createElement(tag);
      if (cls) el.className = cls;
      Object.keys(attrs || {}).forEach((k) => {
        if (k === 'text') el.textContent = attrs[k];
        else el.setAttribute(k, attrs[k]);
      });
      return el;
    };
    const field = mk('input', 'kh-input', { type: 'text', placeholder: '抓取字段名（如：登记号）' });
    field.value = row.field || '';
    const title = mk('input', 'kh-input', { type: 'text', placeholder: '卡片里的标题（留空＝字段名）' });
    title.value = row.title || '';
    const wrap = mk('label', 'kh-check');
    const hid = mk('input', '', { type: 'checkbox' });
    hid.checked = row.hidden === true;
    wrap.appendChild(hid);
    wrap.appendChild(document.createTextNode(' 默认不展示'));
    const del = mk('button', 'kh-mini-btn', { type: 'button', text: '删掉' });
    /* 【2.0.8.18 需求②·P1】两路值不一致时这一行怎么显示（默认最保守的「标注」：
     * 值照常显示，悬停能看到另一路，绝不因为拿不准就吞掉整行）。 */
    const pick = mk('select', 'kh-input kh-merge-conflict');
    pick.title = '两路值不一致时这一行怎么显示';
    [
      ['mark', '冲突：标注'],
      ['both', '冲突：两值并列'],
      ['ocr', '冲突：取图上值'],
      ['fetch', '冲突：取页面值'],
      ['skip', '冲突：不显示']
    ].forEach((pair) => {
      const o = mk('option', '', { value: pair[0], text: pair[1] });
      pick.appendChild(o);
    });
    pick.value = row.onConflict || 'mark';
    box.appendChild(field);
    box.appendChild(title);
    box.appendChild(pick);
    box.appendChild(wrap);
    box.appendChild(del);
    const collect = () => {
      const rows = [];
      const all = $('merge-rows').querySelectorAll('.kh-merge-row');
      for (let i = 0; i < all.length; i++) {
        const ins = all[i].querySelectorAll('input');
        const f = ins[0] ? String(ins[0].value || '').trim() : '';
        if (!f) continue;
        rows.push({
          field: f,
          title: ins[1] ? String(ins[1].value || '').trim() : '',
          hidden: !!(ins[2] && ins[2].checked),
          onConflict: (() => {
            const sel = all[i].querySelector('.kh-merge-conflict');
            return sel ? String(sel.value || 'mark') : 'mark';
          })()
        });
      }
      return rows;
    };
    const save = () => saveNested({ imgMerge: { on: true, rows: collect() } }).then(renderMergeForm);
    field.addEventListener('change', save);
    title.addEventListener('change', save);
    pick.addEventListener('change', save);
    hid.addEventListener('change', save);
    del.addEventListener('click', () => saveNested({ imgMerge: { on: true, rows: collect().filter((r) => r.field !== field.value.trim()) } }).then(renderMergeForm));
    return box;
  }

  function renderMergeForm() {
    const box = $('merge-rows');
    if (!box) return;
    if (!mergeWired) { mergeWired = true; wireMergeForm(); }
    box.innerHTML = '';
    const rows = mergeRowsOf();
    if (!rows.length) {
      const empty = document.createElement('div');
      empty.className = 'kh-muted';
      empty.textContent = '还没配。点「+ 添加一行」，字段名写「抓取后续字段」里的名字（例如：登记号）。';
      box.appendChild(empty);
      return;
    }
    for (let i = 0; i < rows.length; i++) box.appendChild(mergeRowEl(rows[i]));
  }

  /* ---- 【T5】校验中心 ----
   * 「图怎么取 / 谁和谁比」的汇总。判定与文案都在 compare/center.js，
   * 这里只负责把 summary(cfg) 画成两行；要改配置，行尾 hint 会指到对应位置
   * （谁和谁比只汇总各关键词里标的「比对」，真源在关键词编辑弹窗）。 */
  function renderCheckCenter() {
    const box = $('check-center');
    if (!box) return;
    box.innerHTML = '';
    const C = (KH.Compare && KH.Compare.Center) || null;
    if (!C || typeof C.summary !== 'function') return;
    const items = C.summary(cfg) || [];
    for (let i = 0; i < items.length; i += 1) {
      const it = items[i];
      const li = document.createElement('li');
      li.className = 'kh-cc-item';
      li.setAttribute('data-cc', it.key || '');
      const name = document.createElement('strong');
      name.textContent = it.title || '';
      const tag = document.createElement('span');
      tag.className = 'kh-cc-tag' + (it.changed ? ' is-changed' : '');
      tag.textContent = it.tag || '';
      const text = document.createElement('span');
      text.className = 'kh-cc-text';
      text.textContent = it.text || '';
      const hint = document.createElement('span');
      hint.className = 'kh-cc-hint';
      hint.textContent = it.hint || '';
      li.appendChild(name);
      li.appendChild(tag);
      li.appendChild(text);
      li.appendChild(hint);
      box.appendChild(li);
    }
  }

  function wireMergeForm() {
    const add = $('merge-add');
    if (!add) return;
    add.addEventListener('click', () => {
      const rows = mergeRowsOf().concat([{ field: '', title: '', hidden: false }]);
      /* 空字段不会落盘（归一函数会丢掉），所以这里只把空行画出来给用户填：
       * 用 DOM 直接追加一行，input 的 change 会带着 collect() 一起保存。 */
      const box = $('merge-rows');
      if (!box) return;
      const empty = box.querySelector('.kh-muted');
      if (empty && !box.querySelector('.kh-merge-row')) box.innerHTML = '';
      box.appendChild(mergeRowEl({ field: '', title: '', hidden: false }));
      const ins = box.querySelectorAll('.kh-merge-row');
      const last = ins[ins.length - 1];
      if (last) { const f = last.querySelector('input'); if (f) f.focus(); }
      void rows;
    });
  }

  for (const k of ['defaultCaseSensitive', 'defaultWholeWord', 'defaultUseRegex']) {
    $('ms-' + k).addEventListener('change', async (e) => {
      const on = e.target.checked;
      await saveNested({ matchSettings: { [k]: on } });
      D.toast(on ? '已设为新建默认（仅影响以后新建）' : '已取消该默认值', 'ok');
    });
  }

  for (const k of PF_KEYS) {
    $('pf-' + k).addEventListener('change', async (e) => {
      await mutate(() => KH.Store.patch({ [k]: e.target.checked }));
    });
  }

  /* 变更处理方式（K58）：smart = 相关性预筛（默认）；always = 任何变动都整页重建（旧行为、最保守） */
  $('pf-changeHandling').addEventListener('change', async () => {
    const v = ($('pf-changeHandling').value === 'always') ? 'always' : 'smart';
    await mutate(() => KH.Store.patch({ changeHandling: v }));
    D.toast(v === 'always'
      ? '已切换为保守：任何页面变动都会整页重建（更费资源）'
      : '已切换为智能：只在与命中相关时重建（省资源）', 'ok');
  });

  $('pf-silent').addEventListener('change', async () => {
    const v = Math.max(0, parseInt($('pf-silent').value, 10) || 0);
    await mutate(() => KH.Store.patch({ pageRebuildSilentMs: v }));
  });
  $('pf-gap').addEventListener('change', async () => {
    const v = Math.max(0, parseInt($('pf-gap').value, 10) || 0);
    await mutate(() => KH.Store.patch({ pageRebuildGapMs: v }));
  });
  $('pf-imgSize').addEventListener('change', async () => {
    const v = KH.Config.normalizeImgSize($('pf-imgSize').value);
    $('pf-imgSize').value = v;
    await saveNested({ importantNote: { imgSize: v } });
  });
  /* 面板字号（2026-10-09 用户裁决：默认比上一版小一号，且可配）。
   * 边界与归一**只调 config 的唯一函数**（面板侧那一处也调它），设置页不再抄 10/20。 */
  $('pf-noteFontSize').addEventListener('change', async () => {
    const v = KH.Config.normalizeNoteFontSize($('pf-noteFontSize').value);
    $('pf-noteFontSize').value = v;
    await saveNested({ importantNote: { fontSize: v } });
  });
  /* 面板默认宽度（T26 / 用户 2026-10-12：200 → 250，且可配）。
   * 归一**只调 config 的唯一函数**（越界夹到边界、坏值回默认 250）；然后把归一后的值回显进框里，
   * 别让框里停着一个没生效的数（用户填 9999 → 框里显示 600，他才知道真的被收进合法区了）。 */
  $('pf-notePanelWidth').addEventListener('change', async () => {
    const w = KH.Config.normalizePanelWidth($('pf-notePanelWidth').value);
    $('pf-notePanelWidth').value = w;
    await mutate(() => KH.Store.patch({ notePanelWidth: w }));
  });
  /* 【2.0.14 需求二】重要笔记分页开关。落盘走嵌套子键 importantNote.pagedTabs（不新增顶层键）。 */
  $('pf-notePaged').addEventListener('change', async () => {
    await saveNested({ importantNote: { pagedTabs: $('pf-notePaged').checked === true } });
  });
  /* 【2.0.15 · 问题②】同法人校验开关（默认关）。落 importantNote.entityCheck。 */
  $('pf-policyRenderTab').addEventListener('change', async () => {
    await saveNested({ policy: { renderTab: $('pf-policyRenderTab').checked === true } });
    D.toast('已保存：' + ($('pf-policyRenderTab').checked ? '读不到正文时会开后台标签页' : '只读已打开的页面'), 'ok');
  });
  $('pf-noteEntityCheck').addEventListener('change', async () => {
    await saveNested({ importantNote: { entityCheck: $('pf-noteEntityCheck').checked === true } });
    syncEntityChannelBoxes();
  });

  /* 【2.0.16.7 · m20763 / m20998】四条法人通道单独开关：关掉的通道后台不发请求、也不计入「等齐」。
   * 存储侧只做一层合并 ⇒ entityChannels 必须整份写（四把开关一起带上）。
   * 界面口径：总闸关着时整张清单置灰（还能改，只是不生效），标题旁一直显示「已开 n/4」。 */
  const ENT_CHANNEL_BOXES = [['sogou', 'pf-ent-sogou', '搜狗企业卡'], ['aiqicha', 'pf-ent-aiqicha', '爱企查'], ['so360', 'pf-ent-so360', '360 搜索'], ['ai', 'pf-ent-ai', '太极AI 推断']];
  const ENT_CHANNEL_ALL_ON = { sogou: true, aiqicha: true, so360: true, ai: true };

  /** 读当前界面上的四把开关（缺键按开，与 config.normalizeEntityChannels 同口径）。 */
  function entChannelsNow() {
    const cur = Object.assign({}, ENT_CHANNEL_ALL_ON, (cfg.importantNote || {}).entityChannels || {});
    ENT_CHANNEL_BOXES.forEach((pair) => { const box = $(pair[1]); if (box) cur[pair[0]] = box.checked === true; });
    return cur;
  }

  /** 总闸 → 清单可编辑性 + 批量按钮可用性 + 「已开 n/4」摘要。回显与每次改动后都调它。 */
  function syncEntityChannelBoxes() {
    const on = $('pf-noteEntityCheck') && $('pf-noteEntityCheck').checked === true;
    let n = 0;
    ENT_CHANNEL_BOXES.forEach((pair) => {
      const box = $(pair[1]);
      if (!box) return;
      box.disabled = !on;
      if (box.checked) n += 1;
    });
    const list = $('pf-entity-channels');
    if (list) list.classList.toggle('is-disabled', !on);
    ['btn-ent-all-on', 'btn-ent-all-off'].forEach((id) => { const b = $(id); if (b) b.disabled = !on; });
    const sum = $('ent-ch-summary');
    if (sum) sum.textContent = on ? '已开 ' + n + ' / 4' : '总闸关着（已开 ' + n + ' / 4，暂不查询）';
  }

  /** 整份写回（storage 一层合并：少一个键就会把兄弟开关打回默认）。 */
  async function saveEntityChannels(next, note) {
    await saveNested({ importantNote: { entityChannels: next } });
    cfg.importantNote = Object.assign({}, cfg.importantNote || {}, { entityChannels: next });
    syncEntityChannelBoxes();
    if (note) D.toast(note, 'ok');
  }

  ENT_CHANNEL_BOXES.forEach((pair) => {
    const box = $(pair[1]);
    if (!box) return;
    box.addEventListener('change', async () => {
      const next = entChannelsNow();
      await saveEntityChannels(next, '已保存：' + (box.checked ? '打开' : '关闭') + '「' + pair[2] + '」通道');
    });
  });

  /* 批量：全部打开 / 全部关闭（一眼能改完，不用逐个点四次）。 */
  $('btn-ent-all-on').addEventListener('click', async () => {
    ENT_CHANNEL_BOXES.forEach((pair) => { const b = $(pair[1]); if (b) b.checked = true; });
    await saveEntityChannels(Object.assign({}, ENT_CHANNEL_ALL_ON), '已保存：四条渠道全部打开');
  });
  $('btn-ent-all-off').addEventListener('click', async () => {
    ENT_CHANNEL_BOXES.forEach((pair) => { const b = $(pair[1]); if (b) b.checked = false; });
    await saveEntityChannels({ sogou: false, aiqicha: false, so360: false, ai: false }, '已保存：四条渠道全部关闭');
  });

  /* ---- 【2.0.16.4 · m19483】只剩太极AI：改了任一项都清掉上一次的结论，免得"刚才通了"被当成本次结果。 ---- */
  function aiChanged() {
    const st = $('ai-taiji-state');
    if (st) st.textContent = '';
  }

  /* ---- 【2.0.16】太极AI：登录 / 刷新模型 / 测试连接 / 选模型 ---- */
  $('ai-taiji-login').addEventListener('click', async () => {
    const btns = [$('ai-taiji-login'), $('ai-taiji-refresh'), $('ai-taiji-test')];
    const state = $('ai-taiji-state');
    const account = String($('ai-taiji-account').value || '').trim();
    const password = String($('ai-taiji-password').value || '');
    if (!account) { if (state) state.textContent = '请先填账号'; return; }
    if (!password) { if (state) state.textContent = '请填密码（只用于这次登录，不保存）'; return; }
    btns.forEach((b) => { if (b) b.disabled = true; });
    if (state) state.textContent = '正在登录…';
    try {
      /* 账号存本机（下次不用重填）；密码只在这一次消息里传，保存动作里没有 password 这个键。 */
      await saveNested({ ai: { taiji: { account: account } } });
      const res = await chrome.runtime.sendMessage({ type: KH.MSG.AI_TAIJI_LOGIN, account: account, password: password });
      const pwd = $('ai-taiji-password');
      if (pwd) pwd.value = '';
      if (!res || !res.ok) {
        if (state) state.textContent = '登录失败：' + ((res && res.error) || '未知原因');
        D.toast('登录失败', 'warn');
      } else {
        fillTaijiModels(res.models || [], (cfg && cfg.ai && cfg.ai.taiji && cfg.ai.taiji.model) || '');
        const first = (res.models && res.models[0]) ? res.models[0].id : '';
        if (state) state.textContent = '已登录；模型 ' + ((res.models || []).length) + ' 个' + (first ? '（默认选第一个，可自行更换）' : '');
        D.toast('登录成功', 'ok');
      }
    } catch (err) {
      if (state) state.textContent = '登录失败：' + String((err && err.message) || err);
    } finally {
      btns.forEach((b) => { if (b) b.disabled = false; });
    }
  });

  $('ai-taiji-refresh').addEventListener('click', () => { aiChanged(); refreshTaijiModels(); });

  $('ai-taiji-test').addEventListener('click', async () => {
    const btn = $('ai-taiji-test');
    const state = $('ai-taiji-state');
    if (btn) btn.disabled = true;
    if (state) state.textContent = '正在测试（发一句最短的话）…';
    try {
      const model = String($('ai-taiji-model').value || '').trim();
      const res = await chrome.runtime.sendMessage({ type: KH.MSG.AI_CHAT, messages: [{ role: 'user', content: '你好' }], override: model ? { model: model } : null });
      if (state) state.textContent = (res && res.ok) ? ('连接正常；示例回复：' + String(res.text || '').slice(0, 60)) : ('测试失败：' + ((res && res.error) || '未知原因'));
    } catch (err) {
      if (state) state.textContent = '测试失败：' + String((err && err.message) || err);
    }
    if (btn) btn.disabled = false;
  });

  $('ai-taiji-model').addEventListener('change', async () => {
    aiChanged();
    const model = String($('ai-taiji-model').value || '').trim();
    await saveNested({ ai: { taiji: { model: model } } });
    D.toast(model ? ('模型已选：' + model) : '模型已清空', 'ok');
  });

  $('ai-taiji-account').addEventListener('change', async () => {
    aiChanged();
    const account = String($('ai-taiji-account').value || '').trim();
    $('ai-taiji-account').value = account;
    await saveNested({ ai: { taiji: { account: account } } });
  });

  $('ai-taiji-base').addEventListener('change', async () => {
    aiChanged();
    const base = String($('ai-taiji-base').value || '').trim().replace(/\/+$/, '');
    $('ai-taiji-base').value = base;
    await saveNested({ ai: { taiji: { base: base } } });
    if (base) refreshTaijiModels();
  });

  /* 【2.0.16.4】退出登录：只清本机浏览器里的太极AI 会话 cookie，账号保留（下次不用重填）。 */
  $('ai-taiji-logout').addEventListener('click', async () => {
    const state = $('ai-taiji-state');
    const btn = $('ai-taiji-logout');
    if (btn) btn.disabled = true;
    if (state) state.textContent = '正在退出…';
    try {
      const res = await chrome.runtime.sendMessage({ type: KH.MSG.AI_TAIJI_LOGOUT });
      if (state) state.textContent = (res && res.ok) ? ('已退出登录（清掉 ' + ((res.cleared == null) ? 0 : res.cleared) + ' 个会话 cookie），重新登录即可继续用') : ('退出失败：' + ((res && res.error) || '未知原因'));
    } catch (err) {
      if (state) state.textContent = '退出失败：' + String((err && err.message) || err);
    }
    if (btn) btn.disabled = false;
  });

  /* ===================== 【2.0.19 · 用户 m28030】自定义网页 AI =====================
   * 公司内网 AI 只有网页版，网址只该留在本机：四个值全部由用户填，代码里不出现任何站点。
   * 流程：开一个不抢前台的标签页 → 写输入框 → 点发送（或回车）→ 轮询回答区，安静下来即答完。
   * ============================================================================== */
  function aiCustomOf() {
    return KH.Config.normalizeAiCustom(cfg && cfg.ai && cfg.ai.custom);
  }

  async function saveAiCustom(patch) {
    const next = Object.assign({}, aiCustomOf(), patch);
    await saveNested({ ai: { custom: next } });
  }

  function renderAiCustomForm() {
    const c = aiCustomOf();
    const ai = KH.Config.normalizeAi(cfg && cfg.ai);
    const ch = $('ai-channel');
    if (ch) ch.value = (ai.channel === 'custom') ? 'custom' : 'taiji';
    const set = (id, v) => { const el = $(id); if (el) el.value = v; };
    set('ai-web-url', c.url);
    set('ai-web-input', c.input);
    set('ai-web-send', c.send);
    set('ai-web-answer', c.answer);
    set('ai-web-idle', String(c.idleMs));
    const keep = $('ai-web-keep');
    if (keep) keep.checked = c.keepTab !== false;
    const out = $('ai-web-test-out');
    if (out && !out.textContent) out.textContent = c.url ? '' : '先填网址，再点「测试这一页」。';
  }

  /* 点选元素：先开一张该网页的标签页（要真加载，选择器才有意义），再让后台注入遮罩。 */
  async function pickWebAiElement(fieldId, key) {
    const url = String((($('ai-web-url') || {}).value) || '').trim();
    if (!/^https?:\/\//i.test(url)) { D.toast('先填网页地址（http:// 或 https://）', 'error'); return; }
    await saveAiCustom({ url: url });
    let tab = null;
    try { tab = await chrome.tabs.create({ url: url, active: true }); }
    catch (e) { D.toast('打不开这个网址', 'error'); return; }
    /* 等页面把输入框渲染出来（单页应用常常是秒回，1.2 秒够用）。 */
    await new Promise((r) => setTimeout(r, 1200));
    try {
      const res = await chrome.runtime.sendMessage({ type: KH.MSG.WEB_AI_PICK, tabId: tab.id });
      if (!res || !res.ok) { D.toast((res && res.error) || '没取到元素', 'error'); return; }
      const el = $(fieldId);
      if (el) el.value = res.selector;
      const patch = {};
      patch[key] = res.selector;
      await saveAiCustom(patch);
      D.toast('已取到选择器', 'ok');
    } catch (e) {
      D.toast('点选失败：' + String((e && e.message) || e), 'error');
    }
  }

  async function testWebAi() {
    const out = $('ai-web-test-out');
    if (out) out.textContent = '正在打开页面测试…';
    try {
      const r = await chrome.runtime.sendMessage({ type: KH.MSG.WEB_AI_PROBE });
      if (!out) return;
      if (!r || !r.ok) { out.textContent = '✗ ' + ((r && r.error) || '测试失败'); return; }
      const marks = [
        r.input ? '输入框 ✓' : '输入框 ✗',
        r.send ? '发送按钮 ✓' : '发送按钮 ✗',
        r.answer ? '回答区 ✓' : '回答区 ✗'
      ];
      out.textContent = '页面「' + (r.title || '') + '」：' + marks.join(' · ');
    } catch (e) {
      if (out) out.textContent = '✗ ' + String((e && e.message) || e);
    }
  }

  if ($('ai-channel')) {
    $('ai-channel').addEventListener('change', async (e) => {
      const want = (e.target.value === 'custom') ? 'custom' : 'taiji';
      await saveNested({ ai: { channel: want } });
      renderAiCustomForm();
    });
  }
  ['ai-web-url', 'ai-web-input', 'ai-web-send', 'ai-web-answer'].forEach((id) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('change', () => {
      const patch = {};
      patch[id.slice('ai-web-'.length)] = String(el.value || '').trim();
      saveAiCustom(patch);
    });
  });
  if ($('ai-web-idle')) {
    $('ai-web-idle').addEventListener('change', () => {
      saveAiCustom({ idleMs: Number($('ai-web-idle').value) || 1200 });
    });
  }
  if ($('ai-web-keep')) {
    $('ai-web-keep').addEventListener('change', () => {
      saveAiCustom({ keepTab: $('ai-web-keep').checked === true });
    });
  }
  if ($('ai-web-pick-input')) $('ai-web-pick-input').addEventListener('click', () => pickWebAiElement('ai-web-input', 'input'));
  if ($('ai-web-pick-send')) $('ai-web-pick-send').addEventListener('click', () => pickWebAiElement('ai-web-send', 'send'));
  if ($('ai-web-pick-answer')) $('ai-web-pick-answer').addEventListener('click', () => pickWebAiElement('ai-web-answer', 'answer'));
  if ($('ai-web-test')) $('ai-web-test').addEventListener('click', testWebAi);

  $('ai-enabled').addEventListener('change', async (e) => {
    aiChanged();
    await saveNested({ ai: { enabled: !!e.target.checked } });
  });

  /* 置顶排序（2.0.2.6 需求②）：**选中即追加到末位**（顺序 = 选择先后），要换位置先 ✕ 掉再选。
   * 口径（trim / 丢空 / 去重 / 最多 3 个）只由 `KH.Config.normalizePinOrder` 一处判，这里不抄。
   * 落盘走嵌套子键 `importantNote.pinOrder`（不新增顶层键 ⇒ 导出/导入、字段单源、UI_ONLY_KEYS 都不用动）。 */
  $('pf-notePinOrder').addEventListener('change', async () => {
    const sel = $('pf-notePinOrder');
    const id = String(sel.value || '').trim();
    sel.value = '';                                  // 选完立刻回到占位项（它是个"添加"动作，不是"当前值"）
    if (!id) return;
    const cur = KH.Config.pinOrderKeys((cfg.importantNote || {}).pinOrder);
    if (cur.length >= KH.Config.NOTE_PIN_MAX) {
      D.toast('最多置顶 ' + KH.Config.NOTE_PIN_MAX + ' 个，先取消一个再选', 'error');
      return;
    }
    await saveNested({ importantNote: { pinOrder: KH.Config.normalizePinOrder(cur.concat([id])) } });
  });

  /* ==================================================================== ⑧ 更新日志（单源） */

  /* 条目与版本块的 DOM 结构只在 `src/ui/changelog-render.js` 里定义一次（台账 #10）；
   * 这里不再留第二套 `changelogLi`，否则又会回到「改一处漏一处」。 */
  function logRenderer() {
    const R = KH && KH.ChangelogRender;
    if (R && typeof R.renderInto === 'function' && typeof R.entryEl === 'function') return R;
    return null;
  }

  /* 关于页默认只看最近 RECENT 条（用户 2026-10-11 现场：183 条全量渲染把「关于」页撑到 49,567px，
   * 一屏只看得见 1.6%）。要翻全就点「展开全部」——就地切换，不必跳欢迎页；完整历史在欢迎页也一直有。
   * 目录最多列 TOC_MAX 条：目录比正文还长本来就没意义（183 条版本号曾把目录撑到 525px）。
   * 想改「默认几条」只改 RECENT 一处，目录与脚注文案都跟着它。 */
  let chgExpanded = false;

  function renderChangelog() {
    const box = $('changelog-list');
    clear(box);
    const toc = $('ver-toc');
    if (toc) clear(toc);
    const list = (typeof window.CHANGELOG !== 'undefined' && Array.isArray(window.CHANGELOG)) ? window.CHANGELOG : [];
    if (!list.length) { box.appendChild(h('div', { class: 'kh-muted', text: '暂无更新日志' })); return; }
    const R = logRenderer();
    if (!R) {
      /* 渲染器没就绪就如实说，不假装「没有日志」（C7 F-10 同一条原则） */
      box.appendChild(h('div', { class: 'kh-muted', text: '更新日志渲染器没加载（changelog-render.js 未就绪），请重新打开本页' }));
      return;
    }
    const RECENT = 8;
    const TOC_MAX = 20;
    const shown = chgExpanded ? list : list.slice(0, RECENT);
    let tocShown = 0;
    // 每条版本一个锚点，右侧悬浮目录可点击跳转；版本块结构由唯一渲染入口产出
    for (const entry of shown) {
      const ver = String(entry.version || '');
      const lid = 'chg-' + ver.replace(/[^\w.]/g, '_');
      box.appendChild(R.entryEl(entry, { anchorId: () => lid }));
      if (toc && tocShown < TOC_MAX) {
        tocShown++;
        toc.appendChild(h('a', {
          class: 'kh-ver-toc-item', href: '#' + lid, text: ver,
          on: { click: (ev) => {
            ev.preventDefault();
            const t = document.getElementById(lid);
            if (t && t.scrollIntoView) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
          } }
        }));
      }
    }
    const foot = h('div', { class: 'kh-ver-foot' });
    if (list.length > shown.length) {
      foot.appendChild(h('div', {
        class: 'kh-muted',
        text: '共 ' + list.length + ' 个版本，这里只列最近 ' + shown.length + ' 个。'
      }));
    }
    if (list.length > RECENT) {
      const toggle = h('button', {
        class: 'kh-mini-btn', type: 'button',
        text: chgExpanded ? '只看最近 ' + RECENT + ' 个' : '展开全部 ' + list.length + ' 个版本'
      });
      toggle.addEventListener('click', () => { chgExpanded = !chgExpanded; renderChangelog(); });
      foot.appendChild(toggle);
    }
    const more = h('button', { class: 'kh-mini-btn', type: 'button', text: '查看完整更新日志（欢迎页）' });
    more.addEventListener('click', () => window.open('../welcome/welcome.html', '_blank'));
    foot.appendChild(more);
    box.appendChild(foot);
  }

  /* ==================================================================== 启动 */

  /**
   * 左侧固定侧边栏的分区（id 与 .kh-tab 的 data-tab 一一对应）。
   * 变更记录：
   *   · 原「匹配与性能」不再单独成区 —— 控件已并入「帮助与隐私」；
   *   · 原「高亮样式」+「备注卡片样式」两个分区**合并为「样式」**（用户 2026-09 要求：
   *     ⚠️ 2.0.16.7（用户 m20966/m20977）把设置页从 7 分区拆成 9 分区：重要笔记（note）与 AI 助手（ai）
   *     从「样式」里独立成页 —— 它们本来就不是外观配置。
   *     与导航里 9 个「.kh-tab」、e2e 的"侧边栏分区"断言一致）。改导航前先看那条断言。
   *     与导航里 7 个 `.kh-tab`、e2e 的"侧边栏分区"断言一致）。改导航前先看那条断言。
   */
  const SECTIONS = ['keywords', 'groups', 'style', 'note', 'ai', 'ocr', 'sites', 'data', 'help'];

  function showSection(id) {
    const target = SECTIONS.indexOf(id) >= 0 ? id : 'keywords';
    for (const s of SECTIONS) {
      const sec = $('sec-' + s);
      if (sec) sec.hidden = (s !== target);
    }
    setActiveTab(target);
  }

  /** 高亮当前分区（点击与 hash 直达共用同一处，避免两套"谁在激活"的判断） */
  function setActiveTab(id) {
    for (const a of document.querySelectorAll('.kh-tab')) {
      const on = a.dataset.tab === id;
      a.classList.toggle('is-active', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    }
  }

  /** 帮助与隐私里的**二级** Tab（隐私/功能/数据/常见/安全/性能/关于）切成 `pan` 那一页，
   *  返回该面板元素（没有就 null）。顶部二级 Tab 的点击与正文指路链接共用这一处。 */
  function activateHelpTab(pan) {
    if (!pan) return null;
    const sec = $('sec-help');
    const helpTabs = document.getElementById('help-tabs');
    if (sec) {
      for (const p of sec.querySelectorAll('.kh-hpanel')) p.classList.toggle('active', p.getAttribute('data-hpan') === pan);
    }
    if (helpTabs) {
      for (const b of helpTabs.querySelectorAll('.kh-htab')) b.classList.toggle('active', b.getAttribute('data-hpan') === pan);
    }
    return sec ? sec.querySelector('[data-hpan="' + pan + '"]') : null;
  }

  /** 切分区：顶部 Tab / hash 直达 / **正文里的指路链接**共用同一处（谁在激活只判一次）。
   *  `hspan` 给了就顺手把帮助区的二级 Tab 切到那一页并滚到它（「关于 → 版本信息」用）。 */
  function goSection(id, hspan) {
    if (SECTIONS.indexOf(id) < 0) return;
    const sec = $('sec-' + id);
    if (sec && sec.id) { try { history.replaceState(null, '', '#' + sec.id); } catch (err) { /* file:// 等场景忽略 */ } }
    showSection(id);
    const pan = hspan ? activateHelpTab(hspan) : null;
    const main = document.querySelector('.kh-main');
    if (pan && pan.scrollIntoView) pan.scrollIntoView({ block: 'start' });
    else if (main && main.scrollIntoView) main.scrollIntoView({ block: 'start' });
    else window.scrollTo(0, 0);
  }

  /** 正文里的指路链接：`<a href="#sec-help" data-hspan="about">` —— 走 `goSection` 同一条通道。
   *  ⚠️ 不能靠浏览器原生锚点：非当前分区带 `hidden`，原生滚动落空 ⇒ 点了像什么都没发生。
   *  只绑一次（`renderTabs` 会被重复调用）。 */
  let jumpBound = false;
  function bindCopyJumps() {
    if (jumpBound) return;
    jumpBound = true;
    document.addEventListener('click', (e) => {
      const t = e.target;
      const a = (t && t.closest) ? t.closest('a[href^="#sec-"]') : null;
      if (!a) return;
      e.preventDefault();
      goSection(String(a.getAttribute('href')).replace(/^#sec-/, ''), a.getAttribute('data-hspan'));
    });
  }

  function renderTabs() {
    const tabs = Array.prototype.slice.call(document.querySelectorAll('.kh-tab'));
    for (const a of tabs) {
      a.addEventListener('click', (e) => {
        // 自己切分区（不依赖浏览器对 #hash 的滚动）：切完回到内容顶部，否则会停在上一节的中段
        e.preventDefault();
        goSection(a.dataset.tab);
      });
    }
    // 帮助与隐私：内部二级 Tab 分页（一屏一类，逻辑独立、不干扰外层分区切换）
    const helpTabs = document.getElementById('help-tabs');
    if (helpTabs) {
      helpTabs.addEventListener('click', (e) => {
        const b = e.target.closest('.kh-htab');
        if (!b) return;
        activateHelpTab(b.dataset.hpan);
      });
    }
    // 正文里的指路链接（「关于 → 版本信息」「欢迎页」等）与顶部 Tab 走同一条通道
    bindCopyJumps();

    // 支持从 popup / 欢迎页带 hash 跳进来（如 options.html#help）
    const fromHash = String(location.hash || '').replace(/^#sec-/, '').replace(/^#/, '');
    showSection(SECTIONS.indexOf(fromHash) >= 0 ? fromHash : 'keywords');
  }

  /** 界面主题：把 cfg.uiTheme 落到 <html> 上，并让下拉框回显。
   *  读不到主题模块（旧包/测试垫片）时**静默跳过** —— 主题不该成为页面起不来的原因。 */
  function syncTheme() {
    const t = (KH.ui && KH.ui.theme) ? KH.ui.theme : null;
    const mode = cfg && cfg.uiTheme ? cfg.uiTheme : 'auto';
    if (t && typeof t.apply === 'function') {
      try { t.apply(mode); } catch (e) { /* 主题失败不影响页面 */ }
    }
    const sel = $('ui-theme');
    if (sel) sel.value = (t && typeof t.normMode === 'function') ? t.normMode(mode) : mode;
  }

  function renderAll() {
    syncTheme();
    renderHeader();
    renderKeywordTable();
    renderGroups();
    renderHighlightStyle();
    renderNoteCardStyle();
    renderOcr();
    renderSites();
    renderPerf();
  }

  /* ============================================================ 图片识别（OCR）
   * 语言包管理（下载 / 手动导入 / 清除 / 自检）+ 跨域图片的**按站点**授权。
   *
   * 【为什么语言包要有"手动导入"】隐私承诺是"除了本项目自己的语言包地址，不访问任何网络"。
   * 有些环境（内网/离线机）连那一次下载都不该发生 —— 那就把 `chi_sim.traineddata.gz` /
   * `eng.traineddata.gz` 手动选进来，全程零联网（校验里会标出"与官方包一致/来自本地文件"）。
   */
  let ocrWired = false;

  function ocrSend(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (res) => { void chrome.runtime.lastError; resolve(res || null); });
      } catch (e) { resolve(null); }
    });
  }

  function ocrRow(key, info) {
    const row = document.createElement('div');
    row.className = 'kh-form-row';
    row.setAttribute('data-ocr-lang', key);

    const fld = document.createElement('div');
    fld.className = 'kh-form-fld';
    const name = document.createElement('div');
    name.className = 'kh-fld-label';
    name.textContent = (info.label || key) + '（' + key + '，' + Math.round((info.fileBytes || 0) / 1024) + ' KB）';
    const state = document.createElement('div');
    state.className = 'kh-muted';
    state.setAttribute('data-ocr-state', key);
    state.textContent = info.cached ? ('已就绪（本地缓存 ' + Math.round((info.cachedBytes || 0) / 1024) + ' KB）')
      : (info.local ? '已就绪（扩展目录里的离线包）' : '未下载');
    fld.appendChild(name);
    fld.appendChild(state);
    row.appendChild(fld);

    const mkBtn = (id, text, title) => {
      const b = document.createElement('button');
      b.className = 'kh-mini-btn';
      b.type = 'button';
      b.id = id;
      b.textContent = text;
      b.title = title;
      return b;
    };
    row.appendChild(mkBtn('btn-ocr-dl-' + key, '下载', '从项目主页下载并校验（sha256）后存到本地'));
    row.appendChild(mkBtn('btn-ocr-import-' + key, '手动导入', '选择本地的 ' + info.file + '（完全离线）'));
    row.appendChild(mkBtn('btn-ocr-clear-' + key, '清除', '删除本地缓存（下次需要重新下载或导入）'));
    return row;
  }

  /** 主引擎模型的一行（三件各有自己的下载/导入/清除；整套下载与清除在列表末尾） */
  function ocrModelRow(slot, info) {
    const row = document.createElement('div');
    row.className = 'kh-form-row';
    row.setAttribute('data-ocr-model', slot);

    const fld = document.createElement('div');
    fld.className = 'kh-form-fld';
    const name = document.createElement('div');
    name.className = 'kh-fld-label';
    name.textContent = (info.label || slot) + '（' + info.file + '，' + Math.round((info.bytes || 0) / 1024) + ' KB）';
    const state = document.createElement('div');
    state.className = 'kh-muted';
    state.setAttribute('data-ocr-model-state', slot);
    state.textContent = info.cached
      ? ('已就绪（本地缓存 ' + Math.round((info.cachedBytes || 0) / 1024) + ' KB）')
      : '未下载';
    fld.appendChild(name);
    fld.appendChild(state);
    row.appendChild(fld);

    const mkBtn = (id, text, title) => {
      const b = document.createElement('button');
      b.className = 'kh-mini-btn';
      b.type = 'button';
      b.id = id;
      b.textContent = text;
      b.title = title;
      return b;
    };
    row.appendChild(mkBtn('btn-ocr-mdl-dl-' + slot, '下载', '只下这一件（校验 sha256 + 字节数后存到本机）'));
    row.appendChild(mkBtn('btn-ocr-mdl-import-' + slot, '手动导入', '选择本地的 ' + info.file + '（完全离线）'));
    row.appendChild(mkBtn('btn-ocr-mdl-clear-' + slot, '清除', '删除这一件的本地缓存'));
    return row;
  }

  /** 当前识别引擎（S2 取代旧的「识别档位」）：auto（默认）/ ppocr / tesseract */
  function ocrEngine() {
    const v = (cfg && cfg.imgOcr && cfg.imgOcr.engine) || '';
    return (v === 'ppocr' || v === 'tesseract') ? v : 'auto';
  }

  /**
   * 只读「高级信息」的内容（票 #17 D-17.7：**10 个引擎参数一律不给可配**，但用户有权看到
   * "现在到底按什么在跑"、并把这一块复制给我们排查）。
   * 每行的值是**代码常量的真值**（分布在本文件同级的两处：`offscreen/ocr.js` 与
   * `src/features/img-ocr.js`），由 `tests/specs/ocr-options.test.js` 逐条去源码里对账 ——
   * 改了常量不改这里就会红，所以这张表不会悄悄变成谎话。
   */
  const OCR_ENGINE_PARAMS = [
    ['MAX_EDGE', '识别前最长边上限（兼容引擎）', '1600'],
    ['TARGET_H', '小图放大目标高度', '96'],
    ['MAX_SCALE', '小图放大倍数上限', '4'],
    ['CHUNK_H', '长图切块高度', '1600'],
    ['CHUNK_OVERLAP', '相邻块重叠高度', '240'],
    ['MIN_OVERLAP', '重叠下限（块高很小时）', '128'],
    ['CHUNK_MAX', '长图最多识别块数', '40'],
    ['CHUNK_H_RELAXED', '撞到块数上限时放宽到的块高', '2000'],
    ['PSM_BLOCK', '兼容引擎版式模式（整块正文）', '6'],
    ['PSM_SINGLE', '兼容引擎版式模式（单行）', '7'],
    ['IDLE_MS', '引擎空闲多久释放（毫秒）', '90000'],
    ['CANVAS_MAX_EDGE', '取图用画布最长边上限', '1200'],
    ['MIN_EDGE', '小于这个边长直接跳过', '24'],
    ['CACHE_MAX', '识别结果缓存条数上限', '200'],
    ['MAX_INFLIGHT', '同时最多识别几张', '4']
  ];

  /** 只读高级信息那一段的正文（纯文本，复制出去的也是它） */
  function ocrAdvText() {
    const ver = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '?';
    const lines = [
      '关键词高亮 v' + ver + ' · 图片文字识别（OCR）',
      '引擎设置：' + ocrEngine(),
      '浏览器：' + (navigator.userAgent || '?'),
      ''
    ];
    for (const p of OCR_ENGINE_PARAMS) lines.push(p[0] + ' = ' + p[2] + '　（' + p[1] + '）');
    return lines.join('\n');
  }

  function renderOcrAdv() {
    const box = $('ocr-adv-body');
    if (!box) return;
    box.textContent = '';
    const pre = document.createElement('pre');
    pre.className = 'kh-muted';
    pre.style.whiteSpace = 'pre-wrap';
    pre.style.margin = '0';
    pre.textContent = ocrAdvText();
    box.appendChild(pre);
  }

  function renderOcrLangs() {
    const box = $('ocr-lang-list');
    if (!box) return;
    box.textContent = '语言包状态读取中…';
    return ocrSend({ type: KH.MSG.OCR_LANG_STATE }).then((res) => {
      if (!res || !res.ok) { box.textContent = '读取失败：' + ((res && res.error) || '未知错误'); return; }
      box.textContent = '';
      const langs = (res.state && res.state.langs) || {};
      /* 【S2 起没有档位】这里原来写的是"本机还没有**高精度**语言包" —— 档位取消后那句话已经
       * 指向不存在的东西；现在只在"清单里一个包都没有"（站点/清单出问题）时才提示。 */
      if (res.state && res.state.available === false) {
        const p = document.createElement('p');
        p.className = 'kh-muted';
        p.textContent = '清单里没有可用的语言包（清单没读到或站点未提供）—— 兼容引擎将无法使用，'
          + '主引擎不受影响。';
        box.appendChild(p);
      }
      for (const key of Object.keys(langs)) box.appendChild(ocrRow(key, langs[key]));
      const tip = document.createElement('p');
      tip.className = 'kh-muted';
      tip.textContent = '说明：下载只发生在本项目主页（moxiaoren.github.io），下载后会做 sha256 校验，校验不一致直接丢弃；'
        + '手动导入的包若与官方包一致会标注「校验一致」。引擎空闲约 90 秒后自动释放。';
      box.appendChild(tip);
    });
  }

  /** 主引擎模型那一栏（S2-c）：三件各自一行，下载/导入/清除；状态由 offscreen 读缓存给出 */
  let ocrModelState = null;
  function renderOcrModels() {
    const box = $('ocr-model-list');
    if (!box) return;
    box.textContent = '模型状态读取中…';
    return ocrSend({ type: KH.MSG.OCR_MODEL_STATE }).then((res) => {
      if (!res || !res.ok) { box.textContent = '读取失败：' + ((res && res.error) || '未知错误'); return; }
      box.textContent = '';
      const state = res || {};
      const files = state.files || {};
      ocrModelState = state;                       // 成套导入要靠它把文件名映射回槽位
      const slots = Object.keys(files);
      if (!slots.length) {
        const p = document.createElement('p');
        p.className = 'kh-muted';
        p.textContent = '模型清单是空的（清单没读到，或站点未提供）—— 主引擎不可用。';
        box.appendChild(p);
        return;
      }
      for (const slot of slots) box.appendChild(ocrModelRow(slot, files[slot]));
      const ready = slots.filter((s) => files[s].cached).length;
      const p = document.createElement('p');
      p.className = 'kh-muted';
      p.textContent = '已就绪 ' + ready + '/' + slots.length + ' 件（共约 '
        + (Math.round((state.totalBytes || 0) / 1024 / 102.4) / 10) + 'MB，本机已存 '
        + (Math.round((state.cachedBytes || 0) / 1024 / 102.4) / 10) + 'MB）。'
        + '三件**成套**才有用：少一件时主引擎会直接报「模型文件没准备好」，不会静默退回兼容引擎。';
      box.appendChild(p);

      const row = document.createElement('div');
      row.className = 'kh-form-row';
      const dl = document.createElement('button');
      dl.className = 'kh-btn';
      dl.type = 'button';
      dl.id = 'btn-ocr-mdl-dl';
      dl.textContent = '下载模型';
      const imp = document.createElement('button');
      imp.className = 'kh-btn';
      imp.type = 'button';
      imp.id = 'btn-ocr-mdl-import';
      imp.textContent = '整套手动导入';
      const clr = document.createElement('button');
      clr.className = 'kh-mini-btn';
      clr.type = 'button';
      clr.id = 'btn-ocr-mdl-clear';
      clr.textContent = '清除全部模型';
      row.appendChild(dl); row.appendChild(imp); row.appendChild(clr);
      box.appendChild(row);
    });
  }

  /** 迁移提示（S2 / 票 #17 D-17.4）：存量档位被取消时显示**一次**，点掉即写回 migrated.ocrEngine=false */
  function renderOcrMigrate() {
    const box = $('ocr-migrate-note');
    if (!box) return;
    box.hidden = !(cfg && cfg.migrated && cfg.migrated.ocrEngine === true);
  }

  function renderOcrSites() {
    const box = $('ocr-site-list');
    if (!box) return;
    const map = (cfg && cfg.imgOcr && cfg.imgOcr.crossOriginSites) || {};
    const hosts = Object.keys(map).filter((h) => map[h]);
    box.textContent = '';
    if (!hosts.length) {
      const p = document.createElement('p');
      p.className = 'kh-muted';
      p.textContent = '（还没有授权任何站点：跨域图片会被标成「跨域（未授权）」）';
      box.appendChild(p);
      return;
    }
    for (const host of hosts) {
      const row = document.createElement('div');
      row.className = 'kh-form-row';
      row.setAttribute('data-ocr-site', host);
      const fld = document.createElement('div');
      fld.className = 'kh-form-fld';
      const t = document.createElement('div');
      t.className = 'kh-fld-label';
      t.textContent = host;
      fld.appendChild(t);
      row.appendChild(fld);
      const del = document.createElement('button');
      del.className = 'kh-mini-btn';
      del.type = 'button';
      del.textContent = '移除';
      del.addEventListener('click', () => {
        const next = Object.assign({}, (cfg.imgOcr && cfg.imgOcr.crossOriginSites) || {});
        delete next[host];
        mutate(() => KH.Store.patch({ imgOcr: Object.assign({}, cfg.imgOcr, { crossOriginSites: next }) }))
          .then(() => renderOcrSites());
      });
      row.appendChild(del);
      box.appendChild(row);
    }
  }

  function renderOcr() {
    if (!$('sec-ocr')) return;
    if (!ocrWired) { ocrWired = true; wireOcr(); }
    const sel = $('ocr-engine');
    if (sel) sel.value = ocrEngine();
    renderOcrMigrate();
    renderOcrModels();
    renderOcrLangs();
    renderOcrSites();
    renderOcrAdv();
  }

  function wireOcr() {
    const importFile = $('ocr-import-file');
    const modelFile = $('ocr-model-import-file');
    let importLang = '';
    let importSlot = '';

    /** 主引擎模型的一件：下载（单件）/ 清除（单件）—— 与语言包那两个 id 前缀分开，避免误命中 */
    const modelOp = (slot, btn) => {
      if (btn) { btn.disabled = true; btn.textContent = '下载中…'; }
      ocrSend({ type: KH.MSG.OCR_MODEL_DOWNLOAD }).then((res) => {
        if (btn) { btn.disabled = false; btn.textContent = '下载'; }
        if (!res || !res.ok) { D.toast('模型下载失败：' + ((res && res.error) || '未知错误'), 'error'); return; }
        D.toast('模型已下载并校验通过', 'ok');
        renderOcrModels();
      });
    };

    document.addEventListener('click', (e) => {
      const id = e.target && e.target.id ? String(e.target.id) : '';
      let m = /^btn-ocr-mdl-dl-(.+)$/.exec(id);
      if (m) { modelOp(m[1], e.target); return; }
      m = /^btn-ocr-mdl-import-(.+)$/.exec(id);
      if (m && modelFile) { importSlot = m[1]; modelFile.value = ''; modelFile.click(); return; }
      m = /^btn-ocr-mdl-clear-(.+)$/.exec(id);
      if (m) {
        ocrSend({ type: KH.MSG.OCR_MODEL_CLEAR, slots: [m[1]] }).then((res) => {
          if (!res || !res.ok) { D.toast('清除失败', 'error'); return; }
          D.toast('已清除这一件模型缓存', 'ok');
          renderOcrModels();
        });
        return;
      }
      if (id === 'btn-ocr-mdl-dl') { modelOp('all', e.target); return; }
      if (id === 'btn-ocr-mdl-clear') {
        ocrSend({ type: KH.MSG.OCR_MODEL_CLEAR }).then((res) => {
          if (!res || !res.ok) { D.toast('清除失败', 'error'); return; }
          D.toast('已清除全部模型缓存', 'ok');
          renderOcrModels();
        });
        return;
      }
      if (id === 'btn-ocr-mdl-import' && modelFile) { importSlot = ''; modelFile.value = ''; modelFile.click(); return; }

      m = /^btn-ocr-dl-(.+)$/.exec(id);
      if (m) {
        const lang = m[1];
        e.target.disabled = true;
        e.target.textContent = '下载中…';
        ocrSend({ type: KH.MSG.OCR_LANG_DOWNLOAD, lang: lang }).then((res) => {
          e.target.disabled = false;
          e.target.textContent = '下载';
          if (!res || !res.ok) { D.toast('下载失败：' + ((res && res.error) || '未知错误'), 'error'); return; }
          D.toast((res.verified ? '语言包已下载并校验通过' : '语言包已保存') + '（' + Math.round(res.bytes / 1024) + ' KB）', 'ok');
          renderOcrLangs();
        });
        return;
      }
      m = /^btn-ocr-import-(.+)$/.exec(id);
      if (m && importFile) { importLang = m[1]; importFile.value = ''; importFile.click(); return; }
      m = /^btn-ocr-clear-(.+)$/.exec(id);
      if (m) {
        ocrSend({ type: KH.MSG.OCR_LANG_CLEAR, langs: [m[1]] }).then((res) => {
          if (!res || !res.ok) { D.toast('清除失败', 'error'); return; }
          D.toast('已清除本地语言包', 'ok');
          renderOcrLangs();
        });
      }
    });

    if (importFile) {
      importFile.addEventListener('change', () => {
        const f = importFile.files && importFile.files[0];
        if (!f) return;
        const fr = new FileReader();
        fr.onload = () => {
          const b64 = String(fr.result || '').split(',')[1] || '';
          ocrSend({ type: KH.MSG.OCR_LANG_IMPORT, lang: importLang, base64: b64, name: f.name }).then((res) => {
            if (!res || !res.ok) { D.toast('导入失败：' + ((res && res.error) || '未知错误'), 'error'); return; }
            D.toast(res.official ? '导入成功（sha256 与官方包一致）' : '导入成功（本地文件，未与官方包比对）', 'ok');
            renderOcrLangs();
          });
        };
        fr.readAsDataURL(f);
      });
    }

    if (modelFile) {
      /* 【成套导入】一次挑多件（也可以分几次逐件挑）：按**文件名**与清单对上号，
       * 对不上的如实跳过并报出来 —— 模型文件名是 sha256 之外唯一能确认"这是哪一件"的线索。 */
      modelFile.addEventListener('change', () => {
        const list = Array.from(modelFile.files || []);
        if (!list.length) return;
        const files = (ocrModelState && ocrModelState.files) || {};
        const byName = {};
        for (const slot of Object.keys(files)) byName[String(files[slot].file).toLowerCase()] = slot;
        const jobs = [];
        const skipped = [];
        for (const f of list) {
          const slot = byName[String(f.name || '').toLowerCase()] || (importSlot && list.length === 1 ? importSlot : null);
          if (slot) jobs.push({ slot: slot, f: f });
          else skipped.push(f.name);
        }
        if (!jobs.length) {
          D.toast('文件名与清单对不上（应为 ' + Object.keys(files).map((s) => files[s].file).join(' / ') + '）', 'error');
          return;
        }
        const readOne = (job) => new Promise((resolve) => {
          const fr = new FileReader();
          fr.onload = () => {
            const b64 = String(fr.result || '').split(',')[1] || '';
            resolve(ocrSend({ type: KH.MSG.OCR_MODEL_IMPORT, slot: job.slot, base64: b64, name: job.f.name })
              .then((res) => (res && res.ok ? { slot: job.slot, official: !!res.official } : null)));
          };
          fr.readAsDataURL(job.f);
        });
        let chain = Promise.resolve([]);
        for (const job of jobs) chain = chain.then((acc) => readOne(job).then((r) => acc.concat([r])));
        chain.then((results) => {
          const ok = results.filter(Boolean);
          const official = ok.filter((r) => r.official).length;
          const bad = results.length - ok.length;
          if (ok.length) D.toast('已导入 ' + ok.length + ' 件（其中 ' + official + ' 件与清单 sha256 一致）', 'ok');
          if (bad) D.toast(bad + ' 件导入失败，其余已就位', 'error');
          if (skipped.length) D.toast('跳过 ' + skipped.length + ' 个文件名对不上的文件：' + skipped.join('、'), 'error');
          renderOcrModels();
        });
      });
    }

    const engineSel = $('ocr-engine');
    if (engineSel) {
      engineSel.addEventListener('change', async () => {
        const e = engineSel.value === 'ppocr' || engineSel.value === 'tesseract' ? engineSel.value : 'auto';
        await mutate(() => KH.Store.patch({ imgOcr: Object.assign({}, cfg.imgOcr, { engine: e }) }));
        D.toast(e === 'ppocr' ? '已设为「只用主引擎」：主引擎不可用时会如实报错，不会偷偷退回兼容引擎'
          : (e === 'tesseract' ? '已设为「只用兼容引擎」：更省内存，识别质量与速度由 Tesseract 决定'
            : '已设为「自动」：先用主引擎，起不来就用兼容引擎兜底（并会在结果里告知你）'), 'ok');
        renderOcrAdv();
      });
    }

    const migOk = $('btn-ocr-migrate-ok');
    if (migOk) {
      migOk.addEventListener('click', async () => {
        /* 【必须一起写 imgOcr】**`migrated` 只是"还没告知过"的标记，真正要落的是"把存量
         * `imgOcr.quality` 从存储里删掉"** —— 只写 migrated 的话那个废弃键还在，下次读又置真，
         * 提示就永远关不掉。`KH.Store.patch` 会经 `Config.stripDeprecated` 把 `imgOcr.quality` 剔掉，
         * 而这里写的是**整份 imgOcr 对象**（`cfg.imgOcr` 已不含 quality）⇒ 存储里的脏键随之消失。 */
        await mutate(() => KH.Store.patch({
          imgOcr: Object.assign({}, cfg.imgOcr),
          migrated: { ocrEngine: false }
        }));
        renderOcrMigrate();
        D.toast('知道了：识别档位已取消，现在按「引擎」设置走', 'ok');
      });
    }

    const advCopy = $('btn-ocr-adv-copy');
    if (advCopy) {
      advCopy.addEventListener('click', () => {
        const text = ocrAdvText();
        const done = () => D.toast('已复制高级信息', 'ok');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(done, () => D.toast('复制失败（可手动选中后复制）', 'error'));
        } else {
          D.toast('这个环境不给剪贴板权限，请手动选中后复制', 'error');
        }
      });
    }

    const addBtn = $('btn-ocr-site-add');
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        const inp = $('ocr-site-input');
        const host = String((inp && inp.value) || '').trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase();
        if (!host) { D.toast('请输入站点域名，如 example.com', 'error'); return; }
        const next = Object.assign({}, (cfg.imgOcr && cfg.imgOcr.crossOriginSites) || {});
        next[host] = true;
        mutate(() => KH.Store.patch({ imgOcr: Object.assign({}, cfg.imgOcr, { crossOriginSites: next }) })).then(() => {
          if (inp) inp.value = '';
          D.toast('已允许读取 ' + host + ' 的跨域图片', 'ok');
          renderOcrSites();
        });
      });
    }

    const testBtn = $('btn-ocr-selftest');
    if (testBtn) {
      testBtn.addEventListener('click', () => {
        const out = $('ocr-selftest-result');
        const cv = document.createElement('canvas');
        cv.width = 520; cv.height = 80;
        const g = cv.getContext('2d');
        g.fillStyle = '#fff'; g.fillRect(0, 0, 520, 80);
        g.fillStyle = '#000'; g.font = '30px "Microsoft YaHei", SimHei, sans-serif';
        g.fillText('关键词自检 A12345', 12, 50);
        if (out) out.textContent = '识别中…';
        /* 【自检＝"引擎真的能用吗"的唯一自测入口】（#16 D-16.6：requestId 比对 + 30s 超时 + 回显**实际引擎**）
         * 三件事都必须有，少一件都会骗人：不比对 requestId ⇒ 页面里别的识别的结果会把自检"点亮"；
         * 没有超时 ⇒ 引擎卡死时这里永远停在「识别中…」；不回显引擎 ⇒ 用户以为自己在测主引擎，
         * 其实测的是回落后的兼容引擎。 */
        let selftestId = '';
        let selftestTimer = null;
        const done = (msg) => {
          if (selftestTimer) { clearTimeout(selftestTimer); selftestTimer = null; }
          chrome.runtime.onMessage.removeListener(once);
          if (!out) return;
          if (msg && msg.timeout) {
            out.textContent = '✗ 30 秒没有回应（首次可能要下载模型，稍等后再点一次）';
          } else if (msg && msg.ok) {
            out.textContent = '✓ 引擎 ' + (msg.engine || '未知')
              + '（' + Math.round(msg.confidence || 0) + '% / ' + (msg.ocrMs == null ? '?' : msg.ocrMs) + 'ms'
              + '）：' + String(msg.text || '').replace(/\s+/g, ' ').trim()
              + (msg.engineReason ? '　⚠ 已从主引擎回落（原因：' + msg.engineReason + '）' : '');
          } else {
            out.textContent = '✗ ' + ((msg && msg.error) || '识别失败')
              + (msg && msg.code === 'lang-missing' ? ' —— 请先下载或导入语言包' : '')
              + (msg && msg.code === 'engine-unavailable' ? ' —— 主引擎不可用；可把「引擎」改成「自动」或「只用兼容引擎」' : '');
          }
        };
        function once(m) {
          if (!m || m.type !== KH.MSG.OCR_RESULT || m.to !== 'ui') return false;
          if (selftestId && m.requestId !== selftestId) return false;   // 别人的结果不认
          done(m);
          return false;
        }
        chrome.runtime.onMessage.addListener(once);
        selftestTimer = setTimeout(() => { done({ timeout: true }); }, 30000);
        ocrSend({ type: KH.MSG.OCR_IMAGE, dataUrl: cv.toDataURL('image/png'), keyword: '关键词' }).then((res) => {
          selftestId = (res && res.requestId) || '';
        });
      });
    }
  }

  // 存储变化即重绘（popup 或其它标签页改配置时本页跟随；自己写入时跳过，避免抖动）
  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || updating) return;
      reload().catch(() => { /* 扩展上下文失效时忽略 */ });
    });
  }

  /* 帮助卡里的快捷键 = `chrome.commands.getAll()` 的**真值**，不抄 manifest 的愿望。
   * 真机教训：open-settings 原本建议 `Ctrl+Shift+O`，被 Chrome 自带「书签管理器」占用后
   * 建议键被**静默丢弃**（getAll 回 shortcut:""），写死的卡面教用户按一个不存在的键。 */
  const KH_MAC = /Mac|iPhone|iPad/.test(navigator.platform || '') || /Mac OS X/.test(navigator.userAgent || '');
  const KH_MAC_LABEL = { Command: '⌘', Ctrl: '⌘', MacCtrl: '⌃', Alt: '⌥' };
  async function renderShortcuts() {
    let cmds = null;
    try { cmds = await chrome.commands.getAll(); } catch (e) { return; }   // 读不到 → 保留静态兜底
    if (!Array.isArray(cmds)) return;
    for (const el of document.querySelectorAll('kbd[data-kh-cmd]')) {
      const hit = cmds.find((c) => c && c.name === el.dataset.khCmd);
      const parts = String((hit && hit.shortcut) || '').split('+').map(s => s.trim()).filter(Boolean);
      if (!parts.length) {
        el.textContent = '未分配';
        el.classList.add('is-unset');
        el.title = '浏览器没给这条命令分按键（多半被浏览器自带快捷键占用），可在扩展快捷键页自行设置';
        continue;
      }
      const shown = KH_MAC ? parts.map(p => KH_MAC_LABEL[p] || p) : parts;
      el.textContent = shown.join('+');
    }
  }

  if (KH.ui && KH.ui.theme && KH.ui.theme.boot) KH.ui.theme.boot();
  reload().then(() => { renderChangelog(); renderTabs(); renderShortcuts(); refreshUndoRow(); refreshScopeUndo(); }).catch(err => {
    console.error('[KH] 设置页初始化失败', err);
    D.toast('初始化失败：' + (err && err.message), 'error');
  });
})();
