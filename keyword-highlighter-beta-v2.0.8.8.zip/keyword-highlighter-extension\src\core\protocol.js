/* ============================================================================
 * src/core/protocol.js · 全工程唯一消息协议
 * ----------------------------------------------------------------------------
 * 为什么要有这个文件：旧版消息类型散落三套写法 ——
 *   background: { action: 'toggleGlobal' } / { action: 'refresh' }
 *   popup:      { action: 'checkUpdate' } / { action: 'updatePopup' }
 *   content:    无统一约定
 * 结果是"同一件事有多套名字、加了新消息不知道要不要兼容旧名"。v2 收敛为唯一协议：
 *
 *   { type: 'kh:<域>:<动作>', ...payload }
 *
 * 域固定几类：state（读状态）、global（全局开关）、site（站点开关）、
 * rebuild / debug / editor / ocr。
 * 【2026-10-05 变更】原先的 update 域（kh:update:check / kh:update:info）随"插件入口取消线上更新"
 * 一并删除 —— 插件不再检查更新、不再弹更新提示条；更新通道只是本机设置（src/core/channel.js）。
 * 新增消息 = 在 MSG 里登记一个常量，**禁止在业务代码里硬编码字符串**。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** 消息类型唯一清单 */
  const MSG = {
    /* ---- state ---- */
    STATE_QUERY: 'kh:state:query',          // 查询当前标签页状态（站内是否高亮/命中数/规则数）
    STATE_REPLY: 'kh:state:reply',          // （广播用）状态回执

    /* ---- rebuild ---- */
    REBUILD_REQUEST: 'kh:rebuild:request',  // 请求内容脚本立即重扫（popup/自动化用）
    REBUILD_DONE: 'kh:rebuild:done',        // 重扫完成回执

    /* ---- global ---- */
    GLOBAL_TOGGLE: 'kh:global:toggle',      // 切换全局开关；payload: { value?: boolean }
    GLOBAL_CHANGED: 'kh:global:changed',    // background 广播给所有标签页

    /* ---- site ---- */
    SITE_TOGGLE: 'kh:site:toggle',          // 临时禁用/启用当前站点
    SITE_CHANGED: 'kh:site:changed',        // 广播

    /* ---- tab ---- */
    /* 【2.0.6.2 需求⑤】切页广播：background 在 `tabs.onActivated` 时把"新页是谁"发给所有标签页，
     * 由**内容脚本自己**用本地配置判定新页可不可高亮（判定只有一份实现：`SiteRules.shouldHighlight`）。
     * payload: { url, tabId } */
    TAB_SWITCH: 'kh:tab:switch',

    /* 【2.0.7.2 需求⑤】标签页级临时禁用的三条（新增，不动上面的 site 域：SITE_TOGGLE 与
     * SITE_CHANGED 仍归"历史站点级禁用"（siteDisabledMap 存量）那条老路径）。
     * 为什么非得经 background 判：`chrome.storage.session` 只有扩展自己的页面/后台能读，内容脚本读不到；
     * 而 tabId 也只有 background 从 `sender.tab` 拿得到（内容脚本不知道自己属于哪个标签页）。
     * 于是：问 `TAB_DISABLED_QUERY`（payload { tabId? }）→ 回 { disabled }；
     *       设 `TAB_DISABLED_SET`（payload { tabId?, disabled? }，省略 disabled = 翻转）；
     *       改完 background 用 `TAB_DISABLED_CHANGED`（payload { disabled }）推给该标签页热生效。 */
    TAB_DISABLED_QUERY: 'kh:tab:disabledQuery',
    TAB_DISABLED_SET: 'kh:tab:disabledSet',
    TAB_DISABLED_CHANGED: 'kh:tab:disabledChanged',

    /* ---- debug（只读诊断；联调 / 真浏览器回归用） ---- */
    DEBUG_HITS: 'kh:debug:hits',            // 返回当前命中注册表快照（不改任何行为）
    DEBUG_DIAG: 'kh:debug:diag',            // 只读诊断：重建计数 / 最近触发来源 / 仅消费次数 / 相关性判定

    /* ---- editor ---- */
    /* popup 的「＋ 快速添加」→ 让**当前网页**弹出与选项页 1:1 的编辑器。
     * 为什么不在 popup 里弹：Chrome 弹窗上限 800×600，而编辑器是三列 1040px，
     * 挤进去只会塌成一列（用户实测："实现方式很奇怪，我设想的是直接在当前页一比一复刻"）。 */
    EDITOR_OPEN: 'kh:editor:open',

    /* ---- ai（【2.0.8.4 需求④】重要笔记面板的 AI 对话助手）----
     * 为什么必须经 background 转发：内容脚本里的 fetch 按**页面来源**走 CORS，
     * 各家 API 不会给任意网站放行；service worker 是扩展来源 + `host_permissions: <all_urls>`，
     * 才发得出去。设置页的「测试连接」也走这一条（只有一份实现，测的就是真正跑的那条路）。
     * payload: { messages:[{role,content}], override?:{baseUrl,apiKey,model,maxTokens,system,provider} }
     * 回执:   { ok:true, text } | { ok:false, error }
     * AI_OPEN_OPTIONS：面板没配置时的一键入口（内容脚本自己不能稳定地开设置页）。 */
    AI_CHAT: 'kh:ai:chat',
    /* 【2.0.8.7 需求②】AI 审核（应用名称 / 图标）。与 AI_CHAT 分开的原因：这条要带图片，
     * 走多模态 content 数组（AI_CHAT 只发纯文本），且默认通道是 Cloudflare 免费额度。
     * payload: { name, image?:dataURL, override? } → { ok:true, audit:{...} } | { ok:false, error } */
    AI_AUDIT: 'kh:ai:audit',
    AI_OPEN_OPTIONS: 'kh:ai:openOptions',
    /* ---- entity（【2.0.8.8 需求③】查「开发者 / 核准主体」的法定代表人）----
     * payload: { name } → { ok:true, rep, source } | { ok:false, error }
     * 为什么必须经 background：内容脚本里的 fetch 按页面来源走 CORS，企业信息站不会给任意
     * 商店页放行；service worker 有 `host_permissions:<all_urls>`，且查询结果能落
     * `chrome.storage.local` 缓存（同一家公司在很多卡片里重复出现）。
     * 通道顺序（用户拍板）：爱企查 → 必应搜索摘要 → 都失败就标「未查明」（面板不改底色）。 */
    ENTITY_LOOKUP: 'kh:entity:lookup',
    /* 【2.0.8.5】网页对话：面板要求打开/聚焦对话页、以及对对话页做一次自检（选择器是否还认得出）。 */
    AI_WEB_OPEN: 'kh:ai:webOpen',
    AI_WEB_PROBE: 'kh:ai:webProbe',
    AI_WEB_NEW: 'kh:ai:webNew',
    /* 流式回包走长连接：面板 `chrome.runtime.connect({name:'kh:ai'})`，后台按 requestId 推 chunk/done。 */
    AI_PORT: 'kh:ai',
    /* 后台 → 网页对话内容脚本（chat.deepseek.com 上的 content/web-chat.js）。 */
    WEB_PING: 'kh:web:ping',
    WEB_ASK: 'kh:web:ask',
    WEB_NEW: 'kh:web:new',
    WEB_STOP: 'kh:web:stop',
    WEB_CHUNK: 'kh:web:chunk',

    /* ---- ocr（图片文字识别；内容脚本 ↔ background ↔ offscreen 文档三段中转） ----
     * 【为什么必须有 offscreen 这一层】MV3 的内容脚本不能建扩展本地 worker（要跨源 + 页面 CSP
     * 会拦 wasm），后台 service worker 又不能建 worker（且 30s 空闲即被杀）——
     * 真浏览器实测（`_e2e/probe-ocr*.js`）：只有在**扩展自己的页面**（offscreen 文档）里
     * `new Worker(chrome.runtime.getURL(...))` + 本地 wasm 才稳。
     * 消息一律经 background 中转（内容脚本不直接与 offscreen 通信），并带 `to` 标记防回环。 */
    OCR_IMAGE: 'kh:ocr:image',              // 识别一张图：{src|dataUrl, keyword, via?} → {requestId}
    OCR_QUEUED: 'kh:ocr:queued',            // background **受理即回执**（只发给发起的那一帧）：{requestId, src, via}
    OCR_CANCEL: 'kh:ocr:cancel',            // 丢弃某标签页待处理的识别任务（重建/离页时）
    OCR_RESULT: 'kh:ocr:result',            // offscreen → background（再按 requestId 送回发起方）
    OCR_LANG_STATE: 'kh:ocr:langState',     // 语言包状态：每个语言是否已就绪 + 占用字节
    OCR_LANG_DOWNLOAD: 'kh:ocr:langDownload', // 运行时下载（sha256 校验后落本地缓存）
    OCR_LANG_IMPORT: 'kh:ocr:langImport',   // 手动导入（离线；base64 传字节）
    OCR_LANG_CLEAR: 'kh:ocr:langClear',     // 清除本地语言包缓存
    /* ---- 主引擎（PP-OCR）的模型资产（S2-c）----
     * 与语言包那四条一一对应，但**语义是"三件成套"**：det（找框）/ rec（认字）/ dict（字符集），
     * 少一件都识别不出东西 ⇒ state/download/clear 都以整组为单位（只有导入按件，便于断点续传）。 */
    OCR_MODEL_STATE: 'kh:ocr:modelState',       // 模型状态：三件各自是否已就绪 + 占用字节
    OCR_MODEL_DOWNLOAD: 'kh:ocr:modelDownload', // 运行时下载（逐件卡 sha256 + 字节数后落缓存）
    OCR_MODEL_IMPORT: 'kh:ocr:modelImport',     // 手动导入单件（离线；base64 传字节）
    OCR_MODEL_CLEAR: 'kh:ocr:modelClear',       // 清除模型缓存（清掉后主引擎需重新下载/导入）
    OCR_PROGRESS: 'kh:ocr:progress',        // 进度（语言包/模型下载各阶段 / 排队情况）

    /* ---- pdf（PDF 文本抽取）----
     * 为什么复用 OCR 这条三段中转：`fetch` + 解压 + 解析都要在**扩展自己的页面**里跑
     * （内容脚本受页面 CSP 约束，service worker 30s 会被杀），offscreen 文档已经是那个地方。
     * 但它**不进 OCR 队列**（不需要引擎、不占额度），回执仍走 `OCR_RESULT`（background 按
     * requestId 认领，天然复用）。用户口径（2.0.6.5 需求②）：不需要展示 PDF 源文件，只要占位。 */
    OCR_PDF: 'kh:ocr:pdf'                   // 抽一份 PDF 的文字：{src, keyword} → 结果仍是 OCR_RESULT
  };

  const ACTION_RESULT = { OK: 'ok', ERROR: 'error' };

  KH.MSG = MSG;
  KH.ACTION_RESULT = ACTION_RESULT;

  if (typeof module !== 'undefined' && module.exports) module.exports = { MSG, ACTION_RESULT };
})();
