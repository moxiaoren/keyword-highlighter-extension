/* ============================================================================
 * src/features/img-ocr.js · 图片文字识别（命中口径：图里的字也算命中）
 * ----------------------------------------------------------------------------
 * 解决的真实场景：表格里"金额/供应商/结论"这些值经常是一张截图，文字不在 DOM 里，
 * 现有匹配（只看文本节点）对它无能为力 —— 用户要的是"这个词出现在图片里也算命中"。
 *
 * ============================ 职责与边界 ============================
 *   · 本文件（内容脚本）：**只做采集与结果聚合** —— 从"命中所在表里各个抓取字段的值格"取图，
 *     分类（能不能读）、排队、把识别结果按"图上是否真的出现这个词"标出来。
 *   · offscreen/ocr.js：真正跑 OCR（引擎/语言包都在那边，见该文件顶部注释）。
 *   · important-note.js：只负责把 `KH.ImgOcr.items()` 画进面板最上面那张「截图」表。
 *
 * ============================ 图片命中 = 「抓取后续字段」的一个分支 ============================
 * 【用户确认的口径】取图范围**以抓取字段为准**：
 *   · 前置条件：必须配了「抓取后续字段」+「图片命中关键词」（否则本文件不产生任何条目）；
 *   · 取哪些格：该命中所在表里**所有已配置抓取字段的值格**（值格指向走 `fetchLabels` 的
 *     `@表达式`，见 `Fetch.cellsForHit`），不管字段有没有 `#图` 修饰；
 *   · 匹配口径：「图片命中关键词」当作**正则**（不全词、不区分大小写），
 *     走内核唯一匹配入口 `Scanner.util.matchIn`；**不回落**成规则核心词。
 * 触发（**只看真命中**，K75）：
 *   · 普通词与组合词都走**命中所在格**（`consume(hits…)` 里的命中记录，同一套 `cellOfHit`）。
 *   锚点只用来**定位表/行**，取图仍一律以抓取字段为准；`ruleId|src` 建键天然去重，
 *   所以同一条规则的多条命中不会把同一张图识别两次。
 * 【K75 作废口径】原来还有一条"组合词 Probe 在标题词定位到那一格时就交锚点"的来源
 *   （`ctx.imgAnchors`）—— 它**不看核心词有没有命中**，于是"没命中也在跑 OCR"。
 *   用户口径：「判断命中了普通词/组合词没有…如果没有命中，那就不需要考虑图片 ocr 和图片关键词」。
 *
 * 三条硬边界（与既有纪律一致，meta-check 有红线看着）：
 *   ① **识别结果绝不产生文本高亮**，也不写 `_hits` —— 命中注册表的写入单源仍在 src/core/index.js。
 *   ② 取图范围与**抓取的字段口径同一套定位**：值格由 `KH.Fetch.cellsForHit` 唯一给出，
 *      本文件不自己找格子（否则就会出现"抓取看到的图"和"识别看到的图"不一致）。
 *   ③ 采集只在 ⑦Consume（同步管线）里登记任务；OCR 是**异步**的，结果回来时页面可能已经重建过，
 *      所以按「规则 + 图片地址」做键，并保留一份按地址的识别缓存，重建后直接复用。
 *
 * ============================ 为什么默认只认"读得懂的图" ============================
 * 页面 canvas 读跨域图片会被污染，直接 `fetch` 别人的图又等于替页面发请求。
 * 所以默认只处理：`data:` / `blob:` / 同源 / 页面自己声明过 CORS（`img.crossOrigin`）的图；
 * 跨域图片要**按站点**显式允许（`config.imgOcr.crossOriginSites`，设置页里那个开关）。
 * 不允许时那条会在面板里标成「跨域，未授权识别」，而不是悄悄不显示。
 * ========================================================================= */
'use strict';

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));
  const MSG = KH.MSG;

  /** 传给 OCR 前在内容脚本里缩放的上限（只有 blob: 需要在这里读像素） */
  const CANVAS_MAX_EDGE = 1200;
  /** 小于这个尺寸的图不识别（图标/角标/分隔线，识别出来只会是噪声） */
  const MIN_EDGE = 24;
  /** 按图片地址缓存识别文本（跨重建复用）；上限防止长会话里无限增长 */
  const CACHE_MAX = 200;
  /** 同时最多提交几张（引擎侧本来就是串行的，这里只是别把消息队列灌爆） */
  const MAX_INFLIGHT = 4;
  /* 【2.0.12.10 性能·旧页拖累】这一"页"的身份。
   * 取消不能只按 tabId：B → A 是同一个标签页，而 B 的 pagehide 是**异步**到后台的 ——
   * 等它到时 A 已经排上了图，一刀切会把新页的任务当旧页的撤掉（实测：A 首图 14.9s → 20.0s，
   * 就是被撤掉后重跑了一遍）。让取消带上 pageId，只撤"同一页"的任务。 */
  const PAGE_ID = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  /** 当前这轮扫描的图片命中项：key = ruleId|src */
  let items = new Map();
  /** src → {text, conf, at}，跨重建复用（LRU：超上限丢最旧的） */
  const textCache = new Map();
  /**
   * 【S1-b · 额度按 **token** 记账，不再按 src 数数】
   * 旧实现用 `inflightCount` + `inflight`(Set of src)，结果回来时靠 `if (msg.src)` 才归还 ——
   * 而 `viaCanvas`（blob:/画布那条路）的回执**没有 src** ⇒ 额度只减不增，
   * 累积 4 次（MAX_INFLIGHT）整页 OCR 静默全废（票 #16 ③ 的根因）。
   * 现在 `held`(token → 记账) 是唯一真源、`pending`(requestId → token) 负责认领，
   * 归还＝`held.delete(token)` ⇒ **天然幂等**（重复归还不会多减，也不会还成负数）。
   */
  const held = new Map();          // token -> { key, src, reqId, at }
  /** requestId → token（结果回来时定位该还哪一笔） */
  const pending = new Map();
  /** 已经发出去、还没拿到 requestId 的那几笔（窗口极短，但额度必须算上） */
  let awaitingId = 0;
  /** 正在识别中的 src：只用于"同一张图别重复提交"的去重（**与额度无关**） */
  const inflight = new Set();
  /**
   * 【2.0.1.17 右键任意图 OCR】用户手动点名的图（key = `ctxmenu|<src>`）。
   * 为什么单开一张表、而不是塞进 `items`：`items` 每轮扫描都被**整体重造**（`items = next`），
   * 而右键识别的结果不属于任何规则、不会由 `build()` 重新产出来 —— 塞进去下一次页面变动就没了。
   * 它与 `items` 的关系是"并集"：面板读 `items()`，本表在 `build()` 里并回去、`clear()` 时按档清。
   */
  const manual = new Map();
  /**
   * 【2.0.6.1 需求⑨】失败备忘：src → 失败时刻。引擎报错 / 超时后，同一张图在本会话里
   * 不再自动重排（`FAIL_MEMO_MS` 后放行一次）。没有这张表时，页面每次重扫都会把它当新条目
   * 再提交一遍 —— 用户体感就是"图里根本没字，却一直很慢、页面还卡"。
   * 右键手动识别**不写这张表**（用户主动点名的那一次，必须真的再跑）。
   */
  const failSrc = new Map();
  const FAIL_MEMO_MS = 10 * 60 * 1000;
  /**
   * 【2.0.10 性能体检】这张表原来**没有上限**：长会话里一批图逐个失败（引擎报错 / 超时 /
   * 图里没字）就会一直往里堆，虽然每条只有几十字节，但它是"只进不出"的。
   * 现在给硬上限 300：超了先清已过期的，再按插入顺序丢最旧的（Map 天然保序）。
   * 丢掉的代价只是"再失败一次"，不会影响正确性。
   */
  const FAIL_MAX = 300;
  function noteFail(src, at) {
    if (!src) return;
    failSrc.set(src, at || Date.now());
    if (failSrc.size <= FAIL_MAX) return;
    const now = Date.now();
    for (const [k, t] of Array.from(failSrc.entries())) {
      if (now - t >= FAIL_MEMO_MS) failSrc.delete(k);
    }
    while (failSrc.size > FAIL_MAX) {
      const first = failSrc.keys().next();
      if (first.done) break;
      failSrc.delete(first.value);
    }
  }
  let tokenSeq = 0;
  /**
   * 超过这么久还没有终态 → 内容脚本**自己判死**。
   * 比后台硬顶（120s）宽，是为了"后台先判"这条优先级：正常情况下后台的 `timeout` 先到，
   * 这一层只兜真实存在的场景 —— MV3 把 service worker 杀了，回执永远不会来。
   */
  const JOB_STALE_MS = 150000;
  /** 收口定时器（只在有在途请求时武装；`unref` 是不拖住 node 单测进程） */
  let sweepTimer = null;
  /** 订阅者（面板） */
  const listeners = [];

  /** 当前占用了几笔额度（在途 + 刚发出还没拿到 requestId 的） */
  function quotaUsed() { return held.size + awaitingId; }

  /** 归还一笔额度（**幂等**：认领不到就什么都不做） */
  function releaseHold(token) {
    if (!token) return false;
    const rec = held.get(token);
    if (!rec) return false;
    held.delete(token);
    if (rec.reqId) pending.delete(rec.reqId);
    if (rec.src) inflight.delete(rec.src);
    return true;
  }

  function onChange(fn) { if (typeof fn === 'function') listeners.push(fn); }
  function notify() {
    for (const fn of listeners) {
      try { fn(); } catch (e) { console.error('[KH] 图片命中订阅者异常:', e); }
    }
  }

  function cachePut(src, rec) {
    textCache.set(src, rec);
    if (textCache.size > CACHE_MAX) {
      const oldest = textCache.keys().next();
      if (!oldest.done) textCache.delete(oldest.value);
    }
  }

  /* ---------------- 取图与分类 ---------------- */

  function isExtUi(el) {
    // 插件自己的 UI（面板/编辑器）不参与识别
    for (let n = el; n; n = n.parentElement) {
      if (n.getAttribute && n.getAttribute('data-kh-ext-ui')) return true;
    }
    return false;
  }

  /**
   * 「这张图值不值得识别」——**看原图像素，不看容器显示尺寸**（K68）。
   *
   * 实测缺陷（用户报的）：表格里把缩略图用 CSS 压成很小（`width:8px`），而原图其实是
   * 1000×600 的截图、足够 OCR；旧判据只看 `getBoundingClientRect()`，于是判成
   * 「图当前不可见」直接跳过 —— 明明是能识别的。
   * 现在：
   *   ① **原图**最小边 ≥ MIN_EDGE → 识别（我们本来就是取**原图**去识别，容器多小都无所谓，
   *      识别前的预处理还会按需放大）；
   *   ② 原图尺寸**未知**（还没加载完 / SVG 无内在尺寸）→ 退回看显示尺寸：够大就识别、0×0 判 `invisible`；
   *   ③ 原图明确小于 MIN_EDGE → `too-small`（放大显示也变不出像素来，识别认不出）。
   * @returns {'ok'|'invisible'|'too-small'}
   */
  function pixelVerdict(img) {
    const natW = img.naturalWidth || 0;
    const natH = img.naturalHeight || 0;
    let rw = 0;
    let rh = 0;
    if (img.getBoundingClientRect) {
      try { const r = img.getBoundingClientRect(); rw = r.width || 0; rh = r.height || 0; } catch (e) { /* 忽略 */ }
    }
    const naturalKnown = natW > 0 || natH > 0;
    const naturalEnough = natW >= MIN_EDGE && natH >= MIN_EDGE;
    /* ① 原图像素够 → 识别（**容器压得再小都不算"不可见"** —— 我们识别的是原图） */
    if (naturalEnough) return 'ok';
    /* ② 完全没有布局盒（0×0）= 真的没渲染 → 报"不可见"（对用户可操作：展开/滚动出来） */
    if (!(rw > 0 && rh > 0)) return 'invisible';
    /* ③ 渲染着但原图尺寸未知（还没加载完 / SVG 无内在尺寸）→ 用显示尺寸兜底判断 */
    if (!naturalKnown) return (rw >= MIN_EDGE && rh >= MIN_EDGE) ? 'ok' : 'too-small';
    /* ④ 原图明确小于 MIN_EDGE → 放大显示也变不出像素来，直接判"原图太小" */
    return 'too-small';
  }

  function hostOfSite() {
    try { return location.hostname || ''; } catch (e) { return ''; }
  }

  /** 归一化域名：去协议 / 去路径 / 去端口 / 小写 —— 用户手输 `https://cdn.a.com/x.png` 或带端口也要能匹配 */
  function normHost(s) {
    return String(s == null ? '' : s)
      .trim().toLowerCase()
      .replace(/^[a-z][a-z0-9+.-]*:\/\//, '')
      .replace(/^\/\//, '')
      .replace(/[/?#].*$/, '')
      .replace(/:\d+$/, '');
  }

  /** 图片地址所在的域名（拿不到就空串） */
  function hostOfSrc(src) {
    try { return normHost(new URL(src, location.href).hostname); } catch (e) { return ''; }
  }

  /** 绝对化图片地址（缓存/等待者的键必须统一：相对地址在不同上下文里指的不是同一张图） */
  function absOf(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    try {
      const base = (typeof document !== 'undefined' && document.baseURI) || location.href;
      return new URL(s, base).href;
    } catch (e) { return s; }
  }

  /**
   * 该域名是否被授权读取跨域图片。
   * 【K63 修的关键点：**两个域名都认**】旧实现只比对 `location.hostname`（当前页面所在站点），
   * 可用户看到「这张图来自其它网站」时的自然做法是**把图片所在域名**加进白名单 ——
   * 于是授权了却依然提示未授权（实测用户反馈）。现在：
   *   ① 授权"当前站点"→ 该站点上的所有跨域图都放行（旧口径，保持兼容）；
   *   ② 授权"图片所在域名"→ 只放行这个域名的图（更精确，也更符合直觉）。
   * 两侧都做归一化，避免 `https://a.com/`、`a.com:443` 这类写法匹配不上。
   */
  function crossOriginAllowed(cfg, src) {
    const map = (cfg && cfg.imgOcr && cfg.imgOcr.crossOriginSites) || {};
    const keys = Object.keys(map).filter((k) => map[k]).map(normHost);
    if (!keys.length) return false;
    const page = normHost(hostOfSite());
    if (page && keys.indexOf(page) >= 0) return true;
    const img = hostOfSrc(src);
    return !!(img && keys.indexOf(img) >= 0);
  }

  /**
   * 懒加载的"真地址"藏在哪个属性上（进视口才写进 `src`）。
   * 只用于**报告原因**：我们不替页面发请求，所以拿到 data-* 也不直接去取；
   * 等它真加载出来（`load` 事件）会由调度器补一次重建（见 scheduler 的图片 load 通道）。
   */
  function lazySrcOf(img) {
    if (!img || !img.getAttribute) return '';
    const attrs = ['data-src', 'data-original', 'data-lazy-src', 'data-url', 'data-echo', 'data-original-src'];
    for (const a of attrs) {
      const v = img.getAttribute(a);
      if (v) return v;
    }
    return '';
  }

  /**
   * 这张图能不能识别、怎么把像素送到引擎。
   * 【必须始终带上 src（K62）】失败分支也要把地址带出来 —— 否则 `build()` 里那句
   * `if (!src) continue` 会把"跨域未授权 / 懒加载没加载 / 协议不认识"这些条目**整条丢掉**，
   * 面板上什么都不显示、诊断里 `条目=0`，用户完全看不出发生了什么
   * （实测：跨域图与 display:none 里的图都表现为"OCR 毫无反应"）。
   * @returns {{ok:boolean, why?:string, src?:string, viaCanvas?:boolean}}
   */
  function classify(img, cfg) {
    const src = img.currentSrc || img.getAttribute('src') || img.src || '';
    if (!src) {
      const lazy = lazySrcOf(img);
      if (lazy) return { ok: false, why: 'lazy', src: lazy };   // 懒加载：等 load 之后再扫
      return { ok: false, why: 'no-src' };
    }
    if (/^data:/i.test(src)) return { ok: true, src: src };
    if (/^blob:/i.test(src)) return { ok: true, src: src, viaCanvas: true };
    if (!/^https?:/i.test(src)) return { ok: false, why: 'scheme', src: src };
    let sameOrigin = false;
    try { sameOrigin = new URL(src, location.href).origin === location.origin; } catch (e) { return { ok: false, why: 'bad-url', src: src }; }
    if (sameOrigin) return { ok: true, src: src };
    if (img.crossOrigin) return { ok: true, src: src };          // 页面自己声明了 CORS：像素可读
    if (crossOriginAllowed(cfg, src)) return { ok: true, src: src };  // 站点级显式授权（当前站点 或 图片域名）
    /* 未授权时**必须带上图片所在域名**：面板与诊断要能直接告诉用户"把哪个域名加进白名单" */
    return { ok: false, why: 'cross-origin', src: src, host: hostOfSrc(src) };
  }

  /** blob: 只能在这里读像素（跨源画布会抛异常 → 交给上层标成"读不出来"） */
  function canvasDataUrl(img) {
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (!w || !h) return null;
    const scale = Math.min(1, CANVAS_MAX_EDGE / Math.max(w, h));
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(w * scale));
    cv.height = Math.max(1, Math.round(h * scale));
    const g = cv.getContext('2d');
    g.drawImage(img, 0, 0, cv.width, cv.height);
    return cv.toDataURL('image/png');
  }

  /** 一个锚点（= 一次标题命中定位到的一个/一列取值格）里要识别的图片，按文档序、受每锚点上限约束 */
  function collectImages(anchor, cfg) {
    const rule = anchor.rule;
    const max = Math.max(1, (rule.meta && rule.meta.imgOcrMax) || 1);
    const out = [];
    const seen = new Set();
    /* 【名额只算"真能识别的图"（2.0.2.5 需求① · 多抓取字段时 OCR 不拉起）】
     * 老口径 `out.length >= max` 连**根本识别不了**的图（跨域未授权 / 懒加载 / 无 src / 原图太小）
     * 一起吃名额，而且当场 `return` ⇒ 排在前面的字段里放 logo、图标、懒加载占位图的那些，
     * 会把额度吃光，真正的「截图」字段连条目都建不出来（探针 B/C 现场：好图连一条都没有）。
     * 现在：`okCount` 只数能识别并提交的图，名额被它独占；扫描**不再因坏图提前终止**（继续往后找好图）。
     * 坏图仍留"原因条目"给面板诊断（K62），但另用一个 whyCount 限流，最多 `max` 条 ——
     * 免得一个格子里几十张懒加载占位图把面板刷满。 */
    let okCount = 0;
    let whyCount = 0;
    const pushWhy = (img, cls) => {
      if (whyCount >= max) return;
      whyCount++;
      out.push({ img: img, cls: cls, idx: out.length });
    };
    for (const cell of (anchor.valueCells || [])) {
      if (!cell || !cell.querySelectorAll) continue;
      for (const img of cell.querySelectorAll('img')) {
        if (okCount >= max) return out;
        if (isExtUi(img)) continue;
        const cls = classify(img, cfg);
        const key = cls.src || '';
        if (key && seen.has(key)) continue;          // 同一格里重复贴同一张图只算一次
        if (key) seen.add(key);
        if (img.getAttribute && img.getAttribute('data-kh-ocr-skip') != null) continue;
        /* 【不可见也要留条目（K62）】以前这里直接 `continue` —— 于是"值在图里、但那一块当前是折叠的"
         * 表现成"条目=0、面板什么都没有"，用户完全看不出原因。
         * 但**分类失败的原因更具体，要优先保留**：懒加载的图本来就可能还没尺寸，
         * 那时报 'lazy'（等它加载）比报 'invisible' 有用得多。 */
        if (!cls.ok) { pushWhy(img, cls); continue; }
        /* 【按原图判"值不值得识别"（K68）】容器把图压得很小不算"不可见" —— 见 pixelVerdict 顶部注释 */
        const pv = pixelVerdict(img);
        if (pv !== 'ok') { pushWhy(img, { ok: false, why: pv, src: cls.src }); continue; }
        okCount++;
        out.push({ img: img, cls: cls, idx: out.length });
      }
    }
    return out;
  }

  /* ---------------- 图上是否真的出现这个词（与文本同一套匹配实现） ---------------- */

  /** `imgOcrKeyword` → 正则（编译一次、多处复用）。留空 = 没有匹配口径（不再回落核心词）。 */
  const ocrPatternCache = new Map();
  /* 【2.0.7.1 需求①】字面兜底模式的缓存（键＝关键词原文，与正则缓存分开：两者语义不同） */
  const ocrLiteralCache = new Map();

  /* ---------------- 【2.0.4 需求①】「键值行进表」后缀标记 ----------------
   * 用户口径：图上 `X：Y` 这种键值行并进重要笔记的抓取表，**必须先对那个词配一个后缀标记**才生效。
   * 旧行为是"凡是命中行的 `X：Y` 都进表"⇒ 范围过大：`一对一时间选择范围11:30.` 会被拆成
   * 「一对一时间选择范围 | 11:30.」塞进卡片（用户报的就是这条）。
   * 现在标记写在「图片命中关键词」的**那一个胶囊末尾**，`#表` / `#kv` 两种写法都认：
   * `一对一#表|包名` ⇒ 只有「一对一」会往表里补行，「包名」只做命中判定。
   * 标记必须**逐词**给 —— 一个词误配不波及其它词，这就是"收严"的全部含义。 */
  const KV_MARK = /(?:#|＃)\s*(?:表|kv)\s*$/i;
  /* 【2.0.11 需求】`#比`（`#cmp` 同义）：**逐词**的比对标记 —— 同一张图上，所有带这个标记的项
   * 都得在（静态词本身 / 动态字段抓到的值），缺一个就判「不一致」并点名缺哪个。
   * 与 `#表` 相互独立，可以写在一起（顺序不限），都不写＝不比对。 */
  const KV_CMP = /(?:#|＃)\s*(?:比|cmp)\s*$/i;
  /* 【2.0.6.5 需求③】标记后面跟着**分隔符**（逗号/顿号/分号/空白）时，那里也是断词点：
   * 用户常写 `登记号#表,著作权人#表`，旧实现整串当一个 chip、而它恰好以 `#表` 结尾 ⇒
   * `stripKvMarks` 只剥末尾那一个标记，剩下的 `登记号#表,著作权人` 会被当**字面量**编译进正则
   * ⇒ 永不命中（用户报的「显示无命中」）；`kvWords` 同时出一个脏词 ⇒ 表格也补不出行
   * （「也没增加表格」）。两个症状是同一个根因。
   * 只在**标记之后**放宽：普通词里的逗号照旧是正文字符（`a,b` 仍是一个词），口径没变；
   * 标记后直接跟字（`一对一#表包名`）也不拆 —— 那不是分隔写法，按旧行为整段当正文。 */
  const KV_TAIL_SEP = /(?:#|＃)\s*(?:表|kv|比|cmp)([\s,，、;；]+)/gi;
  /**
   * 按 `|`（含全角）切词，并在「标记 + 分隔符」处补切一刀。标记留在前一段里（`kvWords` 靠它认词）。
   * @returns {string[]} 已 trim、已剔空段
   */
  function kvChips(raw) {
    const out = [];
    for (const seg of String(raw == null ? '' : raw).split(/[|｜]/)) {
      let rest = seg;
      for (;;) {
        KV_TAIL_SEP.lastIndex = 0;
        const m = KV_TAIL_SEP.exec(rest);
        if (!m) break;
        /* 切点在**标记末**，不在分隔符后：标记要留在前一段（`KV_MARK` 只认段尾标记） */
        const at = m.index + m[0].length - m[1].length;
        if (m.index + m[0].length >= rest.length) break;   /* 标记后面没有内容 ⇒ 这一段完整，不用切 */
        out.push(rest.slice(0, at));
        rest = rest.slice(at).replace(/^[\s,，、;；]+/, '');
        if (!rest) break;
      }
      if (rest) out.push(rest);
    }
    return out.map((c) => c.trim()).filter(Boolean);
  }

  /**
   * 一个 chip 尾部的逐词标记：`#表`（进表）与 `#比`（比对）。两者相互独立、可以连写，顺序不限。
   * @returns {{body:string, mark:boolean, markText:string, cmp:boolean}} `body` 已剥掉全部标记
   */
  function chipTags(chip) {
    let s = String(chip == null ? '' : chip).trim();
    let mark = false;
    let markText = '';
    let cmp = false;
    for (;;) {
      const c = KV_CMP.exec(s);
      if (c) { cmp = true; s = s.slice(0, c.index).trim(); continue; }
      const m = KV_MARK.exec(s);
      if (m) { mark = true; markText = m[0]; s = s.slice(0, m.index).trim(); continue; }
      break;
    }
    return { body: s, mark: mark, markText: markText, cmp: cmp };
  }

  /** 去掉标记后的关键词原文（喂 `buildPattern` / 空白容忍重试）：标记本身绝不能被当成匹配字面 */
  function stripKvMarks(raw) {
    return kvChips(raw).map((c) => chipTags(c).body).filter(Boolean).join('|');
  }

  /** 带 `#表` 的那些词 —— **只有它们**允许把图上「词 + 分隔符 + 值」并进抓取表 */
  function kvWords(raw) {
    return kvChips(raw).map((c) => chipTags(c)).filter((t) => t.mark).map((t) => t.body).filter(Boolean);
  }

  /** 带 `#比` 的那些词（标记已剥）——**只有它们**参与「同一张图上必须都在」的比对 */
  function kvCmpWords(raw) {
    return kvChips(raw).map((c) => chipTags(c)).filter((t) => t.cmp).map((t) => t.body).filter(Boolean);
  }

  /* ---------------- 【2.0.7.1 需求②】按抓取字段限定 OCR 关键词 ----------------
   * 用户口径：没单独配就沿用原样（整份词对所有允许 OCR 的抓取字段生效）；某个词写了
   * `@字段名` 之后，**那个字段只用这些限定词**（覆盖式，不是叠加）。静态词与动态词两份
   * 列表各自独立判，互不影响。
   * 字段名必须命中已配置的抓取字段裸名才当作用域 —— 否则 `@` 原样留在词里，
   * 老用户把 `@` 当普通字符的写法一个字都不变。 */
  function sameField(a, b) {
    const norm = (s) => String(s == null ? '' : s).replace(WHITE_ALL, '').trim().toLowerCase();
    return !!norm(a) && norm(a) === norm(b);
  }

  /** 已配置的抓取字段裸名（作用域合法值的唯一来源） */
  function scopeKnown(rule) {
    const out = [];
    const F = KH.Fetch;
    const raw = String((rule && rule.meta && rule.meta.fetchLabels) || '');
    if (!raw || !F || typeof F.parseLabels !== 'function') return out;
    let list = [];
    try { list = F.parseLabels(raw) || []; } catch (e) { return out; }
    for (const it of list) {
      const name = String((it && it.label) || '').trim();
      if (name && out.indexOf(name) < 0) out.push(name);
    }
    return out;
  }

  /** 一个词 → `{text, scopes}`：`@字段名` 只有在 `known` 里才当作用域（`#表` 必须写在最末）。
   *  【2.0.7.2 需求①】**可以连写多个**：`一对一@截图@名称` = 这个词对「截图」或「名称」两个字段的图都生效
   *  （用户原话：关键词并不是指向一个字段，需要支持指向多个字段）。从后往前剥，书写顺序保留；
   *  只要有一个 `@…` 不是真配过的字段名就停手 —— 剩下那段（含那些 `@`）按普通词处理，
   *  老用户把 `@` 当普通字符的写法一个字都不变。 */
  function splitScope(chip, known) {
    const tags = chipTags(chip);
    let s = tags.body;
    const scopes = [];
    for (;;) {
      const m = /@([^@\s]+)$/.exec(s);
      if (!m) break;
      const name = m[1].trim();
      let hit = '';
      for (const k of (known || [])) if (sameField(k, name)) { hit = k; break; }
      if (!hit) break;                        // 不是真字段 ⇒ 整段按普通词（老配置零影响）
      if (scopes.indexOf(hit) < 0) scopes.unshift(hit);
      s = s.slice(0, m.index).trim();
    }
    /* `text` 继续带 `#表`（下游 `parseLabelSpec` 本来就会剥 `#`）；`#比` 只作为标志带出，
     * 绝不留在文本里 —— 它若被当成取值后缀喂给 `extractFor`，字段名就配不上了。 */
    return { text: s + (tags.mark ? tags.markText : ''), scopes: scopes, scope: scopes.join(','), cmp: tags.cmp };
  }

  /**
   * 取「对某个抓取字段生效」的那份词（`|` 拼回，喂 `stripKvMarks` / `needNames`）。
   * 覆盖式：该字段有 `@字段名` 词 ⇒ 只返回它们；没有 ⇒ 返回没写作用域的全部词（旧行为）。
   * `field` 为空（右键条目 / 调不明字段）⇒ 只取无作用域的词，与旧行为一致。
   * 【2.0.7.2 需求①】多作用域：一个词连写 `@截图@名称` 时，**任一**命中本字段即算"属于它"。
   */
  function scopedRaw(raw, field, known) {
    const chips = kvChips(raw);
    if (!chips.length) return '';
    const parts = chips.map((c) => splitScope(c, known));
    const key = String(field == null ? '' : field).trim();
    const mine = key ? parts.filter((p) => p.scopes.some((sc) => sameField(sc, key))) : [];
    if (mine.length) return mine.map((p) => p.text).join('|');
    return parts.filter((p) => !p.scopes.length).map((p) => p.text).join('|');
  }
  /** 【用户口径 m05666】只取「参与命中判定」的词：带 `#比` 的那些**只用来比**，
   *  绝不能让图片变红/变绿。作用域规则与 `scopedRaw` 完全一致，唯一差别是剔掉 cmp 词。 */
  function scopedHitRaw(raw, field, known) {
    const chips = kvChips(raw);
    if (!chips.length) return '';
    const parts = chips.map((c) => splitScope(c, known));
    const key = String(field == null ? '' : field).trim();
    const mine = key ? parts.filter((p) => !p.cmp && p.scopes.some((sc) => sameField(sc, key))) : [];
    if (mine.length) return mine.map((p) => p.text).join('|');
    return parts.filter((p) => !p.cmp && !p.scopes.length).map((p) => p.text).join('|');
  }

  /* ---------------- 【#116 需求】指向诊断：写错的 `@字段名` 不再静默 ----------------
   * 现状：`splitScope` 遇到配不上的 `@…` 就停手、整段按普通词处理（2.0.7.1 是为了让把
   * `@` 当普通字符的老配置一个字都不变）。代价是"字段名打错一个字母"之后，用户只看得到
   * 「这条规则没生效」，没有任何提示 —— 用户口径：这种静默失败必须能在录入界面看见。
   *
   * 实现下沉到 `src/core/scope.js`：设置页（options）与独立编辑窗口**不加载**本文件
   * （`src/features/*` 是内容脚本特性），诊断留在这里的话，设置页里永远是"没有提醒" ——
   * 而那正是最容易写错的地方。这里只做转发，`KH.ImgOcr.scopeIssues` 保留给既有调用方与测试。
   */
  function scopeIssues(raw, known) {
    return (KH.Scope && typeof KH.Scope.scopeIssues === 'function')
      ? KH.Scope.scopeIssues(raw, known)
      : [];
  }
  /** 一条规则里两个填了指向的字段（图片命中关键词 / 图上须有的字段值）一起诊断。
   *  `field` 是**存储字段名**，UI 用它决定把提醒挂在哪一格。 */
  function scopeIssuesOf(rule) {
    const meta = (rule && rule.meta) || {};
    return (KH.Scope && typeof KH.Scope.scopeIssuesOf === 'function')
      ? KH.Scope.scopeIssuesOf(meta, scopeKnown(rule))
      : [];
  }

  /**
   * 「图片命中关键词」的**唯一编译点**（用户确认的匹配口径）：
   *   `useRegex: true` + `wholeWord: false` + `caseSensitive: false`
   * 即"当作正则、不要求整词、不区分大小写"。
   *
   * 【为什么不再回落成规则核心词】用户确认："图片命中关键词"是唯一口径，留空就不该处于
   * 勾选状态（`Config.normalize` 已把这种存量脏配置的开关关掉）。回落会让"填了 A、却按 B 命中"
   * 这种看不懂的行为出现。
   *
   * 【为什么走 `Compiler.buildPattern`】正则构造全工程只有一份（转义 / 全词边界 / `g` 兜底 /
   * 非法正则返回 null 都在那里）；在这里自己 `new RegExp` 就是第二份实现。
   */
  function ocrPatternOf(rule, field) {
    const known = scopeKnown(rule);
    const raw = stripKvMarks(scopedHitRaw(rule && rule.meta && rule.meta.imgOcrKeyword, field, known)).trim();
    if (!raw) return null;
    return patternOf(raw);
  }

  /**
   * 【2.0.7.1 需求①】**字面兜底**：用户词里带正则元字符（`C++`、`A(B)`、`1*2`）时，
   * `buildPattern` 要么返回 `null`（非法正则 ⇒ 永不命中），要么按正则语义解释（`A+B` 只认
   * `AAAB` 之类）—— 两种都是「OCR 正文里明明有，却显示未命中」。
   * 所以正则路径**没命中**时，再按每个词的字面量找一遍；词仍按 `|` 分段（与主路径同口径）。
   * 只在兜底位置用，正则能命中的时候语义一点不动。
   */
  function literalPatternOf(rawKey) {
    const raw = String(rawKey == null ? '' : rawKey).trim();
    if (!raw) return null;
    if (ocrLiteralCache.has(raw)) return ocrLiteralCache.get(raw);
    const segs = raw.split(/[|｜]/).map((s) => s.trim()).filter(Boolean);
    let built = null;
    if (segs.length) {
      try {
        const src = segs.map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
        built = new RegExp(src, 'gi');
      } catch (e) { built = null; }
    }
    ocrLiteralCache.set(raw, built);
    return built;
  }

  /**
   * 关键词原文 → 编译后的模式（带缓存）。**唯一**的正则构造点仍是 `Compiler.buildPattern`：
   * 空白容忍那条路要的是"同一个词、剔空白后的字面"，所以它按**剔空白后的字面**再编译一次 ——
   * 与用户手打「登记号」拿到的模式完全等价，缓存键因此可以直接共用关键词原文。
   * @param {string} rawKey 关键词（或它的剔空白形态）
   */
  function patternOf(rawKey) {
    if (!KH.Compiler || typeof KH.Compiler.buildPattern !== 'function') return null;
    if (ocrPatternCache.has(rawKey)) return ocrPatternCache.get(rawKey);
    const built = KH.Compiler.buildPattern(rawKey, { caseSensitive: false, wholeWord: false, useRegex: true });
    ocrPatternCache.set(rawKey, built || null);
    return built || null;
  }

  /* 【2.0.6.1 需求①⑦ · 口径变更（用户原话）】
   * 「图片关键词（包括动态关键词）命中是需要忽略 ocr 结果里的空格的。现在登记号，识别成
   *   登 记 号，或者登记 号等就不判为命中了。」
   * 旧口径（票 #34）只剔**行内**空白、`\r`/`\n` 留着 ⇒ OCR 把一整串公司名折成两行、把
   * 「登记号」读成一行一个字的时候，静态词与动态判据**都**判不中，用户看到的是
   * 「图上明明有，却说没命中」。现在两侧一律剔掉**全部空白（含换行）**：换行只是检测框
   * 切行留下的版面痕迹，不是语义。
   * 2.0.12 需求③起，这条口径**统一收在 `KH.TextNorm`**（全工程唯一的宽松比较实现）：
   * 比对时吃掉「空白 / OCR 折行（单换行）/ 全半角 / 中英文标点 / 零宽字符 / 大小写」，
   * 但**不跨空行**——空行是真正的另起一段，用户明确要求「原本就是另起一段的不需要忽略」。
   * 静态词（图片命中词）与动态词的判据因此完全同源，不会出现"同一句话两处结论不同"。 */
  const WHITE_ALL = /\s+/g;

  /**
   * 识别文本里是否出现「图片命中关键词」。
   * 匹配实现**必须复用内核唯一入口** `Scanner.util.matchIn`（大小写 / 空匹配保护 / `g` 兜底都在它里面）：
   * 造一个**脱离文档**的文本节点，把整段识别文本当成"一个文本节点"跑同一个入口 ——
   * 于是"图片命中"与"文本命中"的匹配语义不会打架。
   */
  /**
   * 一段文本里找关键词组（已剥标记）：正则优先、字面兜底，再走 `TextNorm` 宽松兜底。
   * 从 `matchedInText` 里拆出来：`#比` 的每个词也要按**同一套口径**判「在不在图上」，
   * 否则「比对一致」与本条规则的命中会用两套比较规则，用户会看到自相矛盾。
   */
  function findInRaw(rawKeyword, text) {
    const U = (KH.Scanner && KH.Scanner.util) || {};
    const pattern = rawKeyword ? patternOf(rawKeyword) : null;
    const literal = literalPatternOf(rawKeyword);
    if ((!pattern && !literal) || typeof U.matchIn !== 'function') return [];
    const raw = String(text || '');
    /* 内核唯一匹配入口：造一个**脱离文档**的文本节点，把整段识别文本当成"一个文本节点" */
    const run = (pat, src) => {
      try {
        return U.matchIn(pat, document.createTextNode(src), { util: U },
          { caseSensitive: false, wholeWord: false, useRegex: true }) || [];
      } catch (e) {
        return [];
      }
    };
    /* 【2.0.7.1 需求①】正则优先、字面兜底：正则跑不出命中时，再按词的字面量找一遍
     * （`C++` 这类非法正则 / `A+B` 这类被正则语义吃掉的词，就靠这一步救回来）。 */
    const runAny = (pats, src) => {
      for (const p of pats) {
        if (!p) continue;
        const got = run(p, src);
        if (got.length) return got;
      }
      return [];
    };
    const direct = runAny([pattern, literal], raw);
    if (direct.length) return direct;
    /* 【宽松兜底 · 2.0.12 需求③】原样匹配不中时，走内核唯一的宽松比较入口
     * `KH.TextNorm.findInText`：它返回的 `start/end` 已经映射回**原文**区间，
     * 所以 `OcrCopy.sentenceOf(text, needle)` 与面板词块照旧可用。
     * 纪律：
     *   ① 只在"直接匹配失败"后才走这条路 —— 不改变既有正则语义，零额外开销；
     *   ② 带正则元字符的段（`A+B`、`C++`）不在这里重试：上面 `literal` 已经按字面量兜过，
     *      再拿正则文本当字面量解释一遍只会产生用户没预期的命中；
     *   ③ 空行是硬边界（`TextNorm` 用 `\u0001` 哨兵），跨段不算命中。 */
    const TN = KH.TextNorm;
    if (!TN || typeof TN.findInText !== 'function') return direct;
    const LITERAL_OK = /^[^\\^$.*+?()[\]{}]+$/;
    const out = [];
    for (const seg of rawKeyword.split(/[|｜]/)) {
      const piece = String(seg || '').trim();
      if (!piece || !LITERAL_OK.test(piece)) continue;
      const hit = TN.findInText(raw, piece, { boundary: false });
      if (!hit) continue;
      if (out.some((o) => o.start === hit.start && o.end === hit.end)) continue;
      out.push({ start: hit.start, end: hit.end, text: hit.text });
    }
    return out.length ? out : direct;
  }

  function matchedInText(rule, text, field) {
    const known = scopeKnown(rule);
    const rawKeyword = stripKvMarks(scopedHitRaw(rule && rule.meta && rule.meta.imgOcrKeyword, field, known)).trim();
    if (!rawKeyword) return [];
    return findInRaw(rawKeyword, text);
  }

  /**
   * 「这个值在识别文本里出现过没有」——**全工程唯一的'值在图上'比较点**。
   * 词边界 / 全半角 / 零宽 / 空白折叠的口径全在 `KH.TextNorm.findInText`；这里只锁参数。
   * 为什么必须单点：`judgeInfo`（图片动态判据）与 `cmpJudge`（`#比` 比对项）问的是同一个问题，
   * 各写一遍就会出现"面板说命中、比对说没命中"的两套口径 —— meta-check 红线钉着"只许一处"。
   * @returns {null|{start:number,end:number,text:string,key?:string}} 没有 TextNorm 时 `null`
   */
  function valueInText(raw, needle) {
    const TN = KH.TextNorm;
    if (!TN || typeof TN.findInText !== 'function') return null;
    return TN.findInText(raw, needle, { boundary: true });
  }

  /**
   * 【2.0.2.19 需求③】动态命中的**唯一判决点**。
   * 用户口径：「图片命中关键词配置支持配置抓取字段内容（动态结果）：例如配置抓取字段 姓名、截图，
   * 若 姓名 抓到的值是 张三 且截图图里也有 张三 则判命中；姓名是张三而图里没有张三则不命中」
   * ⇒ 动态判据 = **`imgOcrNeed` 里点名的那几个抓取字段**抓到的值，必须出现在识别文本里。
   *
   * 三条纪律（为什么不按"全部抓取字段"一刀切）：
   *   ① **留空即旧行为**：没填 `imgOcrNeed` 就一行都不变，存量配置不该因为升级而少命中；
   *   ② 配了就与静态「图片命中关键词」是**且**关系（用户原话的"且"）：静态词命中 + 每个点名值都在图上；
   *   ③ 只填 `imgOcrNeed`、不填静态词也算一条合法配置（用户例子里就只有 姓名、截图 两个字段）——
   *      此时"值出现在图上"就是命中的全部条件。
   * 比较口径与「图片命中关键词」同一条：剔行内空白、不分大小写（OCR 把「张 三」读散是常态）。
   * @param {object} rule 规则快照（提供 `meta.imgOcrKeyword`）
   * @param {string} text 识别文本
   * @param {string[]} need 动态判据值（`needOf` 归一后的；空数组 = 没有动态要求）
   */
  function judgeInfo(rule, text, need, field) {
    const raw = String(text || '');
    /* 【2.0.8.18 需求①】命中块带 `how` 说清它凭什么算命中：`stat` = 静态图片命中词，
     * `found` = 动态判据值。合并与提醒要区分这两种（见 `docs/2.0.8.18-*` §3）。 */
    const stat = matchedInText(rule, raw, field).map((h) => ({
      start: h.start, end: h.end, text: h.text, how: 'stat'
    }));
    const known = scopeKnown(rule);
    const hasStatic = !!stripKvMarks(scopedHitRaw(rule && rule.meta && rule.meta.imgOcrKeyword, field, known)).trim();
    const dyn = (need || []).filter(Boolean);
    if (!dyn.length) return { hits: stat, missingValues: [], weakValues: [], staticMiss: false };
    const TN = KH.TextNorm;
    const found = [];
    /* 【2.0.6.1 需求③】缺失的值**全收集**再返回：面板要把「图上找不到哪几个值」说出来，
     * 否则用户只看到"没命中"却不知道差在哪（这正是本批需求①报的现象）。 */
    const missingValues = [];
    /* 【2.0.8.18】第三类状态：值本身太短，根本不足以当判据（`12` / `abc`）。
     * 它与"图上没有"是两回事 —— 报成"找不到"会让用户去改图，报成"命中"就是假命中。 */
    const weakValues = [];
    for (const v of dyn) {
      const needle = String(v == null ? '' : v);
      if (!needle.trim()) continue;
      /* 比较口径收敛到 `KH.TextNorm.findInText`（全工程唯一实现）：
       * 空白 / 全半角 / 零宽 / 大小写 + 纯 ASCII 判据的**词边界**（`abc1234` 不许命中 `abc12345`）。
       * 旧写法是"剔空白 + 小写 + `indexOf`"——没有边界、没有全半角折叠，
       * 用户的现场（OCR 把 `abc1234` 认成 `ａｂｃ１２３４`）就是它造成的假不一致。 */
      if (!TN) { missingValues.push(needle); continue; }
      const hit = valueInText(raw, needle);
      if (hit) {
        found.push({ start: hit.start, end: hit.end, text: hit.text, how: 'found', key: hit.key });
        continue;
      }
      if (TN.isWeak(needle)) { weakValues.push(needle); continue; }
      missingValues.push(needle);
    }
    /* 【2.0.6.2 需求①】静态词与动态值**各判各的，不再互相清零**。
     * 旧写法两处都是"一票否决"：`if (missingValues.length) return { hits: [] }`（缺一个动态值 ⇒ 连
     * 静态命中一起清）与 `hits: stat.length ? stat.concat(found) : []`（静态词没判中 ⇒ 动态命中一起清）。
     * 用户现场（m08130 第 1 条）正是这个耦合：先只配「图片动态关键词」（`imgOcrKeyword` 为空 ⇒ 走
     * 「值在图上即命中」），之后往「图片命中关键词」加一个词 ⇒ `hasStatic` 变真、判决改走 AND 分支，
     * 新词一旦没判中（正则写法 / 空白 / 大小写细节），**整条命中也跟着归零** ⇒ 用户看到的就是
     * 「OCR 里明明有命中词，加了个词反而不生效」。
     * 现在：命中的定义回到用户直觉——**OCR 文本里出现命中词或动态值就算命中**；
     * 「动态值没凑齐」与「静态词没中」作为**诊断**带出去（`missingValues` / `staticMiss`），
     * 由面板决定怎么解释（KV 行仍按动态值过滤，见 `ocrExtraRows`）。 */
    return {
      hits: stat.concat(found),
      missingValues: missingValues,
      weakValues: weakValues,
      staticMiss: !!(hasStatic && !stat.length)
    };
  }

  /* ---------------- 【2.0.11 需求】「比对」：同一张图上，打了标记的项必须都在 ----------------
   *
   * 用户口径（m00001）：「金融理财类 vivo 承诺函，只要图片；需要比对致方是不是 a 公司、承诺方是不是
   * b 公司。就配置图片命中词 a 公司和 b 公司 …… 如果命中，那就是一致」。
   * ⇒ 不再内置「开发者 vs 企业名称 / 承诺对象 vs 放行名单」这套只看某个字段的比对；改成**用户点名**：
   *   哪几项要核对，就在词/字段尾打 `#比`；同一张图上它们全在＝一致，缺哪个点名说出来。
   *   一项都没打标记＝这张图不比，行为与升级前完全一样。
   *
   * 两类项：
   *   - 静态词（图片命中关键词 + `#比`）：「这个词本身」要出现在图上；
   *   - 动态字段（图上须有的字段值 + `#比`）：它抓到的值（任一）要在图上；
   *     取值与判命中同口径（`Fetch.extractFor` + `TextNorm.findInText`）。
   */

  /** 【2026-11-18 用户口径③】这个词是不是**已配置的抓取字段名**：是则比对的是它的值，而不是字面词。
   * 返回配置里的原写法（`known` 里的那个），空串 = 普通词。 */
  function configuredField(name, known) {
    const n = String(name == null ? '' : name).trim();
    if (!n) return '';
    const TN = KH.TextNorm;
    const key = TN ? TN.keyOf(n) : n.replace(WHITE_ALL, '').toLowerCase();
    for (const k of (known || [])) {
      const kk = TN ? TN.keyOf(k) : String(k).replace(WHITE_ALL, '').toLowerCase();
      if (kk && kk === key) return k;
    }
    return '';
  }

  /** 比对项的字段名（`登记号@字段#比` → `登记号`），与 `needSpecs` 同一套解析 */
  function cmpNameOf(rawSpec) {
    const raw = String(rawSpec || '').trim();
    if (!raw) return '';
    let name = '';
    const parse = (KH.Fetch && typeof KH.Fetch.parseLabelSpec === 'function') ? KH.Fetch.parseLabelSpec : null;
    if (parse) {
      try { const q = parse(chipTags(raw).body); if (q && q.label) name = String(q.label).trim(); } catch (e) { name = ''; }
    }
    if (!name) name = chipTags(raw).body;
    return String(name || '').replace(/[@#＃!^%].*$/, '').trim();
  }

  /** 【2.0.14.4 · m12710】在 OCR 文本里按字段名取值：「著作权人：X」「登记号 X」，值也可落在下一行。
   *  PDF / 证书版式千变万化，`rowsFor` 的结构化抽行认不出文档类型时（没标题、或条目是授权书式文档），
   *  用户仍认为「OCR 明明抓到了」——这条是最小兜底：只认「字段名 + 分隔 + 值」这一种写法。 */
  function labeledValueInText(text, names) {
    const lines = String(text == null ? '' : text).split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = String(lines[i] || '');
      for (let n = 0; n < names.length; n++) {
        const nm = String(names[n] || '');
        if (!nm) continue;
        const at = line.indexOf(nm);
        if (at < 0) continue;
        /* 「著作权人（甲方）：X」这种括号注解要先剪掉，值只从分隔符之后取。 */
        let rest = line.slice(at + nm.length)
          .replace(/^[（(][^）)]*[）)]/, '')
          .replace(/^[\s:：=为是\-—－_]+/, '')
          .trim();
        if (!rest) rest = String(lines[i + 1] || '').trim();
        rest = rest.replace(/[\s\u3000]+$/, '').slice(0, 60);
        if (rest) return rest;
      }
    }
    return '';
  }

  /** 同一规则里**证书图** OCR 出来的行（`OcrAuto.rowsFor`）= 比对基准。
   * 用户口径（m07238）：软著字段抓到的证书图自动进表「著作权人 a公司 / 登记号 X」，
   * 比对就拿这两个值去比授权书图上有没有 —— 不用授权书自己抽出来的值（那是假通过）。
   * 只读 `rowsFor` 的结构化行：授权书按 `docOf` 归 auth，产量里没有这两个字段。 */
  function certBaselineValues(meta, rawSpec) {
    const A = KH.OcrAuto;
    const IO = KH.ImgOcr;
    if (!A || typeof A.rowsFor !== 'function' || !IO || typeof IO.items !== 'function') return [];
    const wantName = cmpNameOf(rawSpec);
    if (!wantName) return [];
    const TN = KH.TextNorm;
    const keyOf = (s) => (TN && typeof TN.keyOf === 'function'
      ? TN.keyOf(s) : String(s == null ? '' : s).replace(WHITE_ALL, '').toLowerCase());
    const want = keyOf(wantName);
    if (!want) return [];
    const pinId = String((meta && meta.pinId) || '');
    let list = [];
    try { list = IO.items() || []; } catch (e) { return []; }
    const out = [];
    const seen = [];
    for (const it of list) {
      if (!it || it.state !== 'done' || !it.text) continue;
      if (pinId && String(it.ruleId || '') !== pinId) continue;
      let rows = [];
      try { rows = A.rowsFor(it) || []; } catch (e) { rows = []; }
      for (const r of rows) {
        const lab = keyOf(r && r.label);
        if (!lab) continue;
        if (lab !== want && !(want.length >= 2 && lab.indexOf(want) === 0)) continue;
        const v = String((r && r.value) || '').trim();
        if (!v || v.length < NEED_MIN_LEN) continue;
        const k = keyOf(v);
        if (seen.indexOf(k) >= 0) continue;
        seen.push(k);
        out.push(v.toLowerCase());
      }
    }
    /* 【2.0.14.4 · m12710】结构化抽行一条都没出时，退一步按字段名在这条规则的 OCR 文本里取值。
     * 用户现场：PDF 里明明抓到了「著作权人 / 登记号」，`#比` 却报「没取到值」——
     * 因为 `rowsFor` 只对认出文档类型的证书抽这两行（授权书式 PDF、没标题的扫描件都抽不出来）。
     * 仍然**不是**「拿被判这张图自己抽出来的行去比」：这里按字段名在文本行里找「字段名：值」，
     * 值本来就印在文档上；主路径（证书结构化行）拿到值时绝不走这条。 */
    if (!out.length) {
      const defs = (A.DEFS || []);
      for (let d = 0; d < defs.length && !out.length; d++) {
        const def = defs[d];
        if (!def) continue;
        const names = [def.label].concat(def.words || []);
        let hitName = false;
        for (let n = 0; n < names.length; n++) { if (keyOf(names[n]) === want) { hitName = true; break; } }
        if (!hitName) continue;
        for (const it of list) {
          if (!it || it.state !== 'done' || !it.text) continue;
          /* 只对 PDF 条目放宽：图片条目仍只认证书结构化行，避免「拿授权书自己的值当基准」的假通过 */
          if (String(it.kind || '') !== 'pdf') continue;
          if (pinId && String(it.ruleId || '') !== pinId) continue;
          const v = labeledValueInText(it.text, names);
          if (!v) continue;
          if (typeof def.ok === 'function') { try { if (!def.ok(v)) continue; } catch (e) { continue; } }
          const k = keyOf(v);
          if (seen.indexOf(k) >= 0) continue;
          seen.push(k);
          out.push(v.toLowerCase());
          break;
        }
      }
    }
    return out;
  }

  /** 一个字段在**当前格**上的取值 ∪ **证书图进表的值**（用户 m07238 口径）。
   * 前一半沿用 `needInfo`（`Fetch.extractFor` + `!`/`^`/`%` 修饰 + 进表行）；
   * 后一半读同一份 `OcrAuto.rowsFor`，不依赖「面板这一轮是否已经算好」（避免时序空值）。 */
  function cmpFieldValues(anchor, rawSpec, field, meta) {
    /* 没有锚点 ≠ 没有值：授权书/PDF 这类没有格子的命中也应拿到基准值。 */
    const sub = { meta: Object.assign({}, meta || {}, { imgOcrNeed: String(rawSpec || '') }) };
    let vals = [];
    try { vals = needInfo(anchor, sub, field, { withCmp: true }).values || []; } catch (e) { vals = []; }
    let base = [];
    try { base = certBaselineValues(meta, rawSpec); } catch (e) { base = []; }
    const TN = KH.TextNorm;
    const keyOf = (s) => (TN && typeof TN.keyOf === 'function'
      ? TN.keyOf(s) : String(s == null ? '' : s).replace(WHITE_ALL, '').toLowerCase());
    const out = [];
    const seen = [];
    for (const v of vals.concat(base)) {
      const s = String(v == null ? '' : v).trim();
      if (!s) continue;
      /* 【2.0.14.4 · m12710】PDF 占位串（`\u0001KHPDF\u0001…`）混进来会把「没取到」说成「有值但不同」 */
      if (s.indexOf('\u0001') >= 0) continue;
      const k = keyOf(s);
      if (seen.indexOf(k) >= 0) continue;
      seen.push(k);
      out.push(s);
    }
    return out;
  }

  /**
   * 这张图上要核对的项（带值，供 `cmpJudge` 用）。没打 `#比` 就返回空数组。
   * @param {object} rule 规则快照
   * @param {string} field 图所属抓取字段（`@字段名` 作用域）
   * @param {Element} anchor 命中所在格（动态字段要在这里取值；缺省＝不取动态项）
   */
  function cmpReqs(rule, field, anchor) {
    const meta = (rule && rule.meta) || {};
    const known = scopeKnown(rule);
    const key = String(field == null ? '' : field).trim();
    const out = [];

    /* ① 静态词：`@字段名` 的作用域规则与 `scopedRaw` 一致（该字段有专属词就只用它们） */
    const kw = [];
    for (const chip of kvChips(meta.imgOcrKeyword)) {
      const sp = splitScope(chip, known);
      if (!sp.cmp) continue;
      const word = chipTags(sp.text).body;
      if (word) kw.push({ word: word, scopes: sp.scopes });
    }
    const kmine = key ? kw.filter((p) => p.scopes.some((sc) => sameField(sc, key))) : [];
    for (const p of (kmine.length ? kmine : kw.filter((p) => !p.scopes.length))) {
      /* 【2026-11-18 用户口径③】`#比` 写的若是**已配置的抓取字段名**（开发者 / 著作权人），
       * 比的是那个字段的**值**：页面上取到的「a公司」出现在图上即算一致，
       * 不再要求图上出现「开发者」这三个字。用户原话：
       * 「开发者是公司，需要比对的里面出现了 a公司，就是一致的。不需要出现"开发者"这样的字眼」。
       * 判定复用 `needInfo` —— 与「图片动态关键词」同一份取值实现，不另写一套。 */
      const fld = configuredField(p.word, known);
      if (fld) {
        if (!out.some((o) => o.kind === 'need' && o.name === fld)) {
          out.push({ name: fld, kind: 'need', values: cmpFieldValues(anchor, fld, field, meta) });
        }
        continue;
      }
      if (out.some((o) => o.kind === 'word' && o.name === p.word)) continue;
      out.push({ name: p.word, kind: 'word', word: p.word });
    }

    /* ② 动态字段：值用**用户自己写的 spec** 取（与 `needInfo` 同一份实现） */
    const parse = (KH.Fetch && typeof KH.Fetch.parseLabelSpec === 'function') ? KH.Fetch.parseLabelSpec : null;
    const parts = String(meta.imgOcrNeed || '').split(/[,，、|;]/)
      .map((w) => w.trim()).filter(Boolean)
      .map((w) => splitScope(w, known)).filter((p) => p.cmp);
    const mine = key ? parts.filter((p) => p.scopes.some((sc) => sameField(sc, key))) : [];
    const pick = mine.length ? mine : parts.filter((p) => !p.scopes.length);
    for (const p of pick) {
      const raw = String(p.text || '').trim();
      if (!raw) continue;
      let name = chipTags(raw).body;
      if (parse) {
        try { const q = parse(raw); if (q && q.label) name = String(q.label).trim(); } catch (e) { /* 用裸名 */ }
      }
      if (!name) continue;
      if (out.some((o) => o.kind === 'need' && o.name === name)) continue;
      out.push({ name: name, kind: 'need', values: cmpFieldValues(anchor, raw, field, meta) });
    }
    return out;
  }

  /**
   * 判决：所有 `#比` 项都在 → `same`（一致）；缺任一项 → `diff`（不一致，点名缺哪些）。
   * 没配比对项 → `null`（不显示任何结论，也不涂色）。
   * @returns {null|{state:'same'|'diff', items:Array<{name:string,kind:string,ok:boolean}>, missing:string[]}}
   */
  function cmpJudge(rule, text, field, reqs) {
    const list = reqs || [];
    if (!list.length) return null;
    const raw = String(text || '');
    const items = [];
    for (const r of list) {
      let ok = false;
      /* 值优先用页面 DOM / 上一轮进表值；一个都没有时退回**这张图自己 OCR 出来的字段值**
       * （证书 / 授权书的 著作权人、登记号 属于后者）。 */
      /* 值只认 `r.values`：页面 DOM ∪ **证书图自动进表的值**（`needInfo` 的 `extraValues`）。
       * 不再退回这张图自己的抽取行 —— 用户口径（m07238）：比对基准必须是「证书图进表的值」，
       * 拿授权书自己抽出来的值去比，永远是「一致」= 假通过。 */
      const vals = (r.kind === 'need') ? (r.values || []) : [];
      if (r.kind === 'word') {
        ok = findInRaw(r.word, raw).length > 0;
      } else {
        for (const v of vals) {
          const needle = String(v == null ? '' : v);
          if (!needle.trim()) continue;
          if (valueInText(raw, needle)) { ok = true; break; }
        }
      }
      /* `values` 带出去：面板要区分「图上有值但文字不同」与「这个字段根本没取到值」 */
      items.push({ name: r.name, kind: r.kind, ok: ok, values: (r.kind === 'need' ? vals.length : 0) });
    }
    const missing = items.filter((i) => !i.ok).map((i) => i.name);
    return { state: missing.length ? 'diff' : 'same', items: items, missing: missing };
  }
  /** 判决 = `judgeInfo().hits`（唯一实现；诊断字段由 `judgeInfo` 带出） */
  function judge(rule, text, need, field) {
    return judgeInfo(rule, text, need, field).hits;
  }

  /**
   * 【2.0.4 需求②】`imgOcrNeed` 点名的抓取字段 → 动态判据值表（`need`）。
   *
   * 用户口径（原话）：「是否可以改成和抓取字段**一模一样**，默认正则、不区分大小写」。
   * 旧实现的病根有两处，都在取值的**来源**上：
   *   ① 字段名匹配直接拿 `cellsForHit` 的 `label`（已被 `parseLabels` 剥成裸名）去和用户原文比
   *      ⇒ 用户在「图片动态关键词」里照抄 `开发者^高价`（跟抓取字段一个写法）时**永远匹配不上**，
   *      整条动态判据被静默丢掉（不是不生效，是根本没算）；
   *   ② 值取的是**值格的 textContent 原文**，没走 `rowsForItem` 的 `!`/`^`/`%` 修饰
   *      ⇒ 笔记表里显示的是修饰后的干净值，判据里却是带尾巴的原始值，图上当然找不到。
   * 现在：值一律走 `Fetch.extractFor` —— **与重要笔记表格同一份取值实现**（同一份分层、同一份修饰），
   * 字段名按 `parseLabelSpec` / `baseLabelOf` 归一后比（后缀写不写都认）。这就是"一模一样"。
   *
   * 三条纪律（不变）：值太短不参与（图上"1"/"是"到处都是，拿它当判据只会假命中）；
   * 占位词（无/暂无/`-`）跳过；留空即旧行为（一行不改）。
   */
  const NEED_MIN_LEN = 2;

  /** 图片动态关键词原文 → 要看的抓取字段（**原文 spec 保留后缀** + 裸名）
   *  【2.0.7.1 需求②】带 `@字段名` 的条目只在那个字段上生效，覆盖式（与该字段的静态词同一条规则）。
   *  【2.0.7.2 需求④】后缀**不再丢弃**：用户写 `开发者^高价`，`^高价` 就是取值的修饰
   *  —— 与「抓取字段」同一套语法、同一份实现（`Fetch.extractFor` 自己会解析）。
   *  旧实现只留裸名（`parseLabelSpec(s).label`），于是 `^高价` 静默失效、拿到的是原始整格
   *  「a公司 高价值」，用户要的「a公司」永远出不来。`raw` 因此必须原样带走。 */
  function needSpecs(rawLabels, field, known, withCmp) {
    const out = [];
    const parse = (KH.Fetch && typeof KH.Fetch.parseLabelSpec === 'function') ? KH.Fetch.parseLabelSpec : null;
    const parts = String(rawLabels || '').split(/[,，、|;]/)
      .map((w) => w.trim()).filter(Boolean)
      .map((w) => splitScope(w, known || []));
    const key = String(field == null ? '' : field).trim();
    const mine = key ? parts.filter((p) => p.scopes.some((sc) => sameField(sc, key))) : [];
    /* 覆盖式：这个字段有 `@字段名` 词 ⇒ 只用它们；否则用全部无作用域的（旧行为） */
    const pickAll = mine.length ? mine : parts.filter((p) => !p.scopes.length);
    /* 【用户口径 m05666】`#比` 项**只用来比**：不进动态判据、不决定图片红/绿框。
     * 只有比对取值自己（`cmpFieldValues`）才带着它们进来。 */
    const pick = withCmp ? pickAll : pickAll.filter((p) => !p.cmp);
    for (const p of pick) {
      const raw = String(p.text || '').trim();
      if (!raw) continue;
      let label = raw;
      if (parse) {
        try { const q = parse(raw); if (q && q.label) label = String(q.label).trim(); } catch (e) { label = raw; }
      }
      if (!label) continue;
      if (out.some((o) => o.label === label && o.raw === raw)) continue;
      out.push({ raw: raw, label: label });
    }
    return out;
  }

  /** 只要字段裸名（诊断/单测入口；取值请用 `needSpecs`，它带着用户写的后缀） */
  function needNames(rawLabels, field, known) {
    return needSpecs(rawLabels, field, known).map((s) => s.label);
  }

  /**
   * 【2.0.6.1 需求①③】`needOf` 的**带诊断版**：除了判据值，还要说清「点名的字段里有哪个
   * 根本没取到值」。
   *
   * 为什么必须带出来：旧实现三处都 `return []` —— 字段名写错、字段不在抓取字段里、
   * 锚点取不到，全都会静默变成"没有动态要求"，于是**永远不命中且毫无提示**。
   * 用户报的正是这个观感（「难道加的字段名也参与命中，那不就是永远也不会命中么」）。
   * 现在解析不出来 → `missing` 里点名，面板照实说「抓取字段 X 没取到值」，不再静默。
   *
   * @returns {{values: string[], want: string[], missing: string[]}}
   *   `values` 已归一（剔全部空白 + 小写），喂 `judge`；
   *   `want` 是用户点名的字段名（已剥后缀）；
   *   `missing` 是**点名了但没在抓取结果里出现**的字段名。
   */
  function needInfo(hitOrCell, rule, field, opts) {
    const meta = (rule && rule.meta) || {};
    const known = scopeKnown(rule);
    const specs = needSpecs(meta.imgOcrNeed, field, known, !!(opts && opts.withCmp));
    const want = specs.map((s) => s.label);
    const info = { values: [], want: want, missing: [], weak: [], fromExtra: [] };
    if (!want.length) return info;                    // 留空即旧行为：没有动态判据
    const Fetch = KH.Fetch || {};
    const TN = KH.TextNorm;
    /* 【2026-11-18 用户口径③】点名与页面标签常常只差个后缀（用户写「开发者」，页面上是「开发者名称」）：
     * 只要页面标签**以点名开头**就认同一个字段，值照取 —— 否则比对项永远报「没取到值」，
     * 用户看到的就是「明明页面上有 a公司，却说缺开发者」。 */
    const wantKeyOf = (s) => (TN ? TN.keyOf(String(s).replace(WHITE_ALL, '')) : String(s).replace(WHITE_ALL, '').toLowerCase());
    const wantKeys = want.map(wantKeyOf).filter(Boolean);
    const wantHit = (s) => {
      const k = wantKeyOf(String(s == null ? '' : s).trim());
      if (!k) return false;
      for (let i = 0; i < wantKeys.length; i++) {
        const w = wantKeys[i];
        if (!w) continue;
        if (k === w) return true;
        if (w.length >= 2 && k.indexOf(w) === 0) return true;
      }
      return false;
    };
    /* 页面上真实写着、且「以点名开头」的字段名（用于差个后缀时取值；找不到就空数组） */
    const tolerantLabels = (hit) => {
      const found = [];
      try {
        let el = (hit && hit.cell) ? hit.cell : hit;
        while (el && el.nodeType === 3) el = el.parentNode;
        while (el && el.nodeType === 1 && el.tagName !== 'TABLE') el = el.parentNode;
        if (!el || el.tagName !== 'TABLE' || typeof el.querySelectorAll !== 'function') return found;
        const cells = el.querySelectorAll('td, th');
        for (let i = 0; i < cells.length; i++) {
          const t = String(cells[i].textContent || '').trim();
          if (!t || t.length > 24 || found.indexOf(t) >= 0) continue;
          if (!wantHit(t)) continue;
          found.push(t);
        }
      } catch (e) {}
      return found;
    };
    if (typeof Fetch.extractFor !== 'function' && !TN) { info.missing = want.slice(); return info; }
    const anchor = (hitOrCell && hitOrCell.cell) ? hitOrCell.cell : hitOrCell;
    /* 【2.0.8.18 P0.5】DOM 取不到值时**不直接放弃**：同一张卡里别的图已经「进表」出来的值
     * （用户在图片1 上命中「登记号」→ 进表 `登记号 | abfx`）也是这个字段的真实取值。
     * 用户场景（m00152 ①）：图片2 的动态词指向「登记号」，图片2 上出现 `abfx` 也应算命中。
     *
     * 防环（为什么不会无限套）：`ocrExtraRows()` 只读 `KH.ImgOcr.items()` 里**上一轮**已算好的
     * `matched`，它不回头调 `needInfo`；`build()` 也是先建 `next` 再整体替换。所以这里是一次性
     * 读旧结果，不会形成 A→B→A。
     * 取不到锚点不算错：静态进表这条路本来就不需要锚点。 */
    const extraValues = () => {
      const Note = KH.ImportantNote;
      if (!Note || typeof Note.ocrExtraRows !== 'function') return [];
      try { return Note.ocrExtraRows(meta) || []; } catch (e) { return []; }
    };
    let entries = [];
    /* 【2.0.7.2 需求④】取值用**用户自己写的那份 spec**（`开发者^高价`），不再用 `meta.fetchLabels`
     * 的全局配置 —— 否则「图片动态关键词」里的后缀永远是死字，用户没法给判据单独裁值。
     * 一个字段写进 `extractFor` 的 labels 串，修饰由 `parseLabelSpec` 在那条链上统一施加
     * （`!`/`^`/`%` 与「抓取字段」是同一份实现）。 */
    if (anchor && typeof Fetch.extractFor === 'function') {
      const labelsArg = specs.map((s) => s.raw).join('|');
      try {
        entries = Fetch.extractFor(anchor, labelsArg, meta.fetchScope, null) || [];
      } catch (e) { entries = []; }
      /* 【2026-11-18 用户口径③】点名与页面标签只差后缀时（写「开发者」、页面是「开发者名称」），
       * `extractFor` 按点名一个格子都找不到 ⇒ 先在这张表里找到**页面上真实的那个标签**，
       * 再用它取一次值。只在空手时走这一步，精确命中时行为完全不变。 */
      if (!entries.length) {
        const real = tolerantLabels(anchor);
        if (real.length) {
          try { entries = Fetch.extractFor(anchor, real.join('|'), meta.fetchScope, null) || []; } catch (e) { entries = []; }
        }
      }
    }
    const out = [];
    const outKeys = [];
    const seen = [];
    const base = (typeof Fetch.baseLabelOf === 'function') ? Fetch.baseLabelOf : ((s) => s);
    /* 【2.0.7.1 需求①⑤】字段名格不是判据值：两列表/整块取值时，标签列可能被并进值格，
     * 于是「开发者」这个字段名本身变成 needle ⇒ 图上找不到它 ⇒ `missingValues` 误报
     * （面板看着像「连字段名都要图里有」，`#表` 又被这条误报整条拦掉）。这里把
     * 「整格就是一个已配置字段裸名」的格剔掉 —— 只比裸名，不比值。 */
    const labelSet = known.map((n) => (TN ? TN.keyOf(n) : String(n).replace(WHITE_ALL, '').toLowerCase())).filter(Boolean);
    const pushValue = (rawVal) => {
      const src = String(rawVal == null ? '' : rawVal);
      /* 【2.0.8.18】这里存的是**展示形**（去空白 + 小写，与笔记表显示的值同口径），不是折叠形：
       * 面板要拿它显示「图上应有：北京星河科技（」，若把全角括号折成半角，用户就与图对不上。
       * 判等与查找各自在 `judgeInfo` 里再折一次（`findInText` 自带区间映射）。 */
      const shown = (TN ? TN.stripZero(TN.stripWs(src)) : src.replace(WHITE_ALL, '')).toLowerCase();
      if (!shown || shown.length < NEED_MIN_LEN) return false;
      const k = TN ? TN.keyOf(shown) : shown;
      if (labelSet.indexOf(k) >= 0) return false;        // 字段名本身：不是值
      if (outKeys.indexOf(k) >= 0) return false;         // 只按"是否同一个值"去重（全半角不算两个）
      outKeys.push(k);
      out.push(shown);
      return true;
    };
    for (const en of entries) {
      const label = String((en && en.label) || '').trim();
      if (!label) continue;
      let bare = label;
      try { bare = String(base(label) || label); } catch (e) { bare = label; }
      if (!wantHit(label) && !wantHit(bare)) continue;
      if (seen.indexOf(label) < 0) seen.push(label);
      if (seen.indexOf(bare) < 0) seen.push(bare);
      for (const row of (en.rows || [])) {
        for (const c of (row || [])) {
          const raw = String((c && c.t) || '');
          if (!raw) continue;
          if (typeof Fetch.isPlaceholderText === 'function' && Fetch.isPlaceholderText(raw)) continue;
          /* 先剔图片占位符（`\u0001KHIMG\u0001alt|url\u0001ENDIMG\u0001`）再剔空白：
           * 只删开头那个标记会把 url 留在值里，值与 OCR 文本就永远对不上（真机抓到的红）。
           * 剥离实现只有一份，与 `#0`（不要图）共用。 */
          const plain = (typeof Fetch.stripAllPlaceholders === 'function')
            ? Fetch.stripAllPlaceholders(raw)
            : ((typeof Fetch.stripImgPlaceholders === 'function') ? Fetch.stripImgPlaceholders(raw) : raw);
          pushValue(plain);
        }
      }
    }
    /* 【2026-11-11 用户口径·案例②】DOM 与「进表值」是**并集**，不是「DOM 缺了才拿进表值补」。
     * 用户原话：著作权人指向抓取字段 b 的图片，命中后进表 `著作权人 | b公司`；再把著作权人的
     * 动态关键词指向抓取字段 c 的图 —— 图 c 里有 `b公司` 就算命中。
     * 旧实现只在 DOM 取不到该字段时才回落读进表行，而字段 c 一般**有** DOM 值 ⇒ gotNames 已含
     * 该字段 ⇒ b公司 永远不参与判定，用户看到的正是「你理解错了我的意思」。
     * 现在：DOM 值先入（页面上的权威来源），随后把同名字段的进表值**全部**并入（多张图各算一条），
     * 由 `pushValue` 的 keyOf 去重兜住重复；`missing` 只按「最终有没有值」算。 */
    const extra = extraValues();
    const gotNames = seen.map((n) => (TN ? TN.keyOf(n) : n.toLowerCase()));
    const pushName = (k) => { if (gotNames.indexOf(k) < 0) gotNames.push(k); };
    for (const n of want) {
      const k = TN ? TN.keyOf(n) : String(n).toLowerCase();
      let added = 0;
      for (const row of extra) {
        const rl = String((row && row.label) || '');
        if (!rl) continue;
        const rk = TN ? TN.keyOf(rl) : rl.toLowerCase();
        if (rk !== k) continue;
        if (!pushValue(row.value)) continue;
        added++;
      }
      if (!added) continue;
      pushName(k);
      if (info.fromExtra.indexOf(n) < 0) info.fromExtra.push(n);
    }
    /* 判据太弱（`12`/`abc`）的值单列：它们不是"没取到"，也不是"图上没有" */
    info.values = [];
    for (const t of out) {
      if (TN && TN.isWeak(t)) { info.weak.push(t); continue; }
      info.values.push(t);
    }
    info.missing = want.filter((n) => {
      const k = TN ? TN.keyOf(n) : String(n).toLowerCase();
      return gotNames.indexOf(k) < 0;
    });
    return info;
  }

  /** 只要值（判决点与单测的既有入口）：`needInfo().values` */
  function needOf(hitOrCell, rule, field) {
    return needInfo(hitOrCell, rule, field).values;
  }

  /* ---------------- 【2.0.2.19 需求②⑤】按列带排版（纯函数：吃 `linesOf`，不吃 DOM） ---------------- */

  /* 列间空白 ≥ 图宽 4% 才算"分列"（再窄就是同一列里的字距）；单格 ≥ 图宽 55% 算通栏（标题/正文段），
   * 不参与分列判断 —— 否则一条居中标题就能把两栏桥接成一栏。 */
  const COL_GAP_RATIO = 0.04;
  const COL_WIDE_RATIO = 0.55;
  const COL_MAX = 4;

  /**
   * `lineList` → 列带模型（需求②「图里是表格就排成表格」与需求⑤「横排两张图 ⇒ 左右两格」共用）。
   *
   * 判据只有一条：**行的单元格坐标**。同一物理行里若有多个框（`cells` 多于一格）⇒ 那就是表格的一行；
   * 全图被一条宽空白带分成 N 段 ⇒ 就是 N 列。两者都靠坐标，不靠猜文字内容。
   * @param {Array} lines `linesOf()` 的形状（`[{cells:[{t,x,x2}], t}]`）
   * @returns {{width:number, cols:number, bands:Array<{x:number,x2:number}>,
   *            rows:Array<{cols:string[], wide?:string}>}}
   *   `cols < 2` ⇒ 调用方按纯文本渲染（旧行为，零风险）。
   */
  /* 【2.0.6 需求③】同一格里两段文字要不要空格，看框与框之间的**实际间距**：
   * 词被检测框切成两段时间隙只有几个像素，硬加空格就会写出「华为技术有限 公司」「供应商： 华为」；
   * 真正的两列之间总有大段空白。与 `offscreen/ocr.js` 的 `joinParts` 同一条口径（隔着一道 offscreen
   * 边界拿不到那支函数，所以这里是同一规则的第二个落点，改一处必须同改两处）。 */
  const TIGHT_GAP_RATIO = 0.6;

  /**
   * 把识别结果的行 → 列带模型（表格）。
   * @param {Array} lines `[{t,cells:[{t,x,x2}],y,y2}]`（引擎回执里的 `lineList`）
   * @returns {{width:number,cols:number,bands:Array,rows:Array}}
   */
  function layout(lines) {
    const list = lines || [];
    const cells = [];
    let width = 0;
    for (let i = 0; i < list.length; i++) {
      /* 【2.0.6.5 需求③】并排多张纸的那一行在引擎侧被拆成了若干段（`run`）：**表格排版仍按整行**，
       * 所以首段的 `cellsAll` 优先；被拆出来的后续段不再贡献单元格（否则同一行会被数两遍 ⇒ 列带错位）。 */
      const cs = Array.isArray(list[i] && list[i].cellsAll)
        ? list[i].cellsAll
        : (Number(list[i] && list[i].run) > 0 ? [] : ((list[i] && list[i].cells) || []));
      for (const c of cs) {
        const t = String((c && c.t) || '').replace(WHITE_ALL, ' ').trim();
        const x = Number(c && c.x);
        const x2 = Number(c && c.x2);
        if (!t || !isFinite(x) || !isFinite(x2) || x2 <= x) continue;
        cells.push({ t: t, x: x, x2: x2, line: i, w: x2 - x });
        if (x2 > width) width = x2;
      }
    }
    if (!width || cells.length < 2) return { width: width, cols: 1, bands: [], rows: [] };
    const gap = width * COL_GAP_RATIO;
    const wideW = width * COL_WIDE_RATIO;
    /* 列带证据：**先只认多格行**（同一行里有两个以上框 = 表格的一行）。
     * 单格行（标题、整段条文）本来就是通栏行，让它参与建带就会被桥成 1 列 —— 这一条同时顶替了
     * 旧的"单格宽 ≥ wideW 就剔掉"。旧口径按**绝对宽度**剔格，会把长标签的键值表（「软件名称」
     * 这类标签格宽到内容的 59%）整列当成通栏踢出去，只剩右列 ⇒ 整张表退回纯文本。
     * 两遍：先按老口径（多格行里再剔通栏格）试，不够 2 列再退一步只要求"多格行" ——
     * 「一条居中标题把两栏桥接成一栏」仍被挡住（那种行只有一格），宽标签列不再被杀。 */
    const perLine = new Array(list.length).fill(0);
    for (const c of cells) perLine[c.line]++;
    const multis = cells.filter((c) => perLine[c.line] >= 2);
    const bandsOf = (arr) => {
      const out = [];
      for (const c of arr.slice().sort((a, b) => (a.x - b.x) || (a.x2 - b.x2))) {
        const cur = out[out.length - 1];
        if (!cur || c.x - cur.x2 >= gap) out.push({ x: c.x, x2: c.x2 });
        else if (c.x2 > cur.x2) cur.x2 = c.x2;
      }
      return out;
    };
    let bands = bandsOf(multis.filter((c) => c.w < wideW));
    if (bands.length < 2) bands = bandsOf(multis);
    if (!bands.length) return { width: width, cols: 1, bands: [], rows: [] };
    /* 列太多 ⇒ 不是"表格/分栏"，是被切碎的文字：退回纯文本（宁可不好看，不可看不出话） */
    if (bands.length < 2 || bands.length > COL_MAX) return { width: width, cols: 1, bands: [], rows: [] };
    const bandOf = (c) => {
      const cx = (c.x + c.x2) / 2;
      for (let j = 0; j < bands.length; j++) if (cx >= bands[j].x && cx <= bands[j].x2) return j;
      let best = 0;
      let bestD = Infinity;
      for (let j = 0; j < bands.length; j++) {
        const d = cx < bands[j].x ? bands[j].x - cx : cx - bands[j].x2;
        if (d < bestD) { bestD = d; best = j; }
      }
      return best;
    };
    const byLine = [];
    for (let i = 0; i < list.length; i++) byLine.push([]);
    for (const c of cells) byLine[c.line].push(c);
    const rows = [];
    for (let i = 0; i < list.length; i++) {
      const row = byLine[i];
      row.sort((a, b) => a.x - b.x);
      if (!row.length) continue;
      /* 整行只有一个通栏格 ⇒ 通栏行（标题/正文段），铺满整张表 */
      if (row.length === 1 && row[0].w >= wideW) {
        rows.push({ wide: row[0].t, cols: [] });
        continue;
      }
      const slots = new Array(bands.length).fill('');
      const prevIn = new Array(bands.length).fill(null);
      const lineH = Math.max(1, (Number(list[i] && list[i].y2) - Number(list[i] && list[i].y)) || 0);
      const limit = Math.max(2, lineH * TIGHT_GAP_RATIO);
      for (const c of row) {
        const j = bandOf(c);
        const prev = prevIn[j];
        /* 同一格里前一段以分隔符收尾、或两段之间只有几个像素 ⇒ 直接贴；真有列间距才留空格 */
        const glue = !prev || (c.x - prev.x2) <= limit || /[：:｜|＝=]\s*$/.test(slots[j]);
        slots[j] = prev ? slots[j] + (glue ? '' : ' ') + c.t : c.t;
        prevIn[j] = c;
      }
      rows.push({ cols: slots });
    }
    return { width: width, cols: bands.length, bands: bands, rows: rows };
  }

  const XLAT = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const xesc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (ch) => XLAT[ch]);

  /**
   * 列带模型 → 表格 HTML（`cols < 2` 或没有任何一行时返回 ''，调用方走纯文本）。
   * 空槽输出空 `<td>`：横向两栏要靠它保持列对齐（左右两格各自成列）。
   */
  function layoutHtml(lay) {
    const l = lay || {};
    if (!l.cols || l.cols < 2 || !l.rows || !l.rows.length) return '';
    let body = '';
    for (const r of l.rows) {
      if (r.wide != null) {
        body += '<tr><td class="kh-ocr-wide" colspan="' + l.cols + '">' + xesc(r.wide) + '</td></tr>';
        continue;
      }
      let tds = '';
      for (let j = 0; j < l.cols; j++) tds += '<td>' + xesc((r.cols || [])[j] || '') + '</td>';
      body += '<tr>' + tds + '</tr>';
    }
    return '<table class="kh-ocr-table">' + body + '</table>';
  }

  /* ---------------- 提交与回收 ---------------- */

  /**
   * 自己收口：`background` 被 MV3 杀掉、或消息彻底丢了时，内容脚本不能永远等下去。
   * 归还额度 + 把条目落到终态（`errorCode='timeout'`，面板据此说人话）。
   * @param {number} [now] 判决时刻（缺省＝现在；测试喂时刻用）
   * @returns {number} 本次收口的条数
   */
  function sweepStale(now) {
    const t = typeof now === 'number' ? now : Date.now();
    let n = 0;
    for (const [token, rec] of Array.from(held.entries())) {
      if (t - rec.at < JOB_STALE_MS) continue;
      if (rec.reqId) pending.delete(rec.reqId);
      if (rec.src) inflight.delete(rec.src);
      held.delete(token);
      n += 1;
      const it = items.get(rec.key);
      if (it && it.state === 'pending') {
        it.state = 'fail';
        it.error = '识别引擎长时间没有回应（已超时）';
        it.errorCode = 'timeout';
      }
      failTwin(rec.src, rec.key, '识别引擎长时间没有回应（已超时）', 'timeout');   // T55
      if (rec.src) noteFail(rec.src, t);               // 需求⑨：超时也别下一轮又排一遍（2.0.10 起走带上限的 noteFail）
    }
    if (n) notify();
    if (n) pump();                                   // 超时收口也归还了额度 ⇒ 补发队里的图
    if (!held.size && sweepTimer) { clearInterval(sweepTimer); sweepTimer = null; }
    return n;
  }

  /** 有在途请求时才武装收口定时器（自终止：`sweepStale` 里空了就关） */
  function armSweep() {
    if (sweepTimer || !held.size) return;
    sweepTimer = setInterval(() => { sweepStale(); }, 5000);
    if (sweepTimer && typeof sweepTimer.unref === 'function') sweepTimer.unref();
  }

  /**
   * 【T55】**同一张图的条目要整组走**：两条规则抓同一字段时，同一个 `src` 会各建一条条目
   * （键 = `ruleId|src`）。识别是按**图片**算的 —— 提交按 `src` 去重，结果 / 超时 / 同步失败
   * 也都必须扇给同 `src` 的另一条，否则孪生条目会永远停在「识别中」。
   * @param {string} src 图片地址（空串＝没地址、按序号建的条目，不参与分组）
   * @param {string} [exceptKey] 已经单独处理过的那条，避免重复写
   */
  function sameSrcItems(src, exceptKey) {
    const out = [];
    if (!src) return out;
    for (const it of items.values()) if (it.src === src && it.key !== exceptKey) out.push(it);
    return out;
  }

  /** 同 `src` 的孪生条目一起落失败态（只动还在等结果的那条） */
  function failTwin(src, exceptKey, error, code) {
    for (const it of sameSrcItems(src, exceptKey)) {
      if (it.state !== 'pending') continue;
      it.state = 'fail';
      it.error = error;
      if (code) it.errorCode = code;
    }
  }

  function submit(entry, cfg) {
    if (quotaUsed() >= MAX_INFLIGHT) return false;
    const cls = entry.cls;
    /* 【T55】这张图**已经在飞**就不重复发：旧实现顶部只看额度，排队循环按条目逐条提交
     * ⇒ 两条规则抓同一张图时各发一次（4 张图 = 8 次识别）。这里只把它置「识别中」，
     * 结果回来由 `onResult` 扇给同 `src` 的每条（缓存与额度都只按图片算一次）。 */
    if (cls.src && inflight.has(cls.src)) { entry.state = 'pending'; return false; }
    /* PDF 条目走同一条额度/在途账，只是发出去的消息类型不同（offscreen 那边不跑引擎、只抽文字） */
    const isPdf = entry.kind === 'pdf';
    let payload = null;
    if (isPdf) {
      payload = { src: cls.src };
    } else if (cls.viaCanvas) {
      let dataUrl = null;
      try { dataUrl = canvasDataUrl(entry.img); } catch (e) { dataUrl = null; }
      if (!dataUrl) { entry.state = 'blocked'; entry.why = 'tainted'; return false; }
      /* 【必须同时带 src】回执里的 src 是"这笔结果属于哪张图"的唯一线索（写缓存与兜底认领都要它）。
       * 旧实现只发 dataUrl ⇒ 回执没 src ⇒ 按 src 归还额度的老逻辑永远还不掉（#16 ③）。 */
      payload = { dataUrl: dataUrl, src: cls.src };
    } else {
      payload = { src: cls.src };
    }
    tokenSeq += 1;
    const token = 't' + tokenSeq;
    held.set(token, { key: entry.key, src: cls.src, reqId: null, at: Date.now() });
    awaitingId += 1;
    if (cls.src) inflight.add(cls.src);
    entry.state = 'pending';
    try {
      chrome.runtime.sendMessage(Object.assign({
        type: isPdf ? MSG.OCR_PDF : MSG.OCR_IMAGE,
        pageId: PAGE_ID,
        keyword: (entry.rule && entry.rule.meta && entry.rule.meta.display) || entry.keyword || ''
        /* 【S2 引擎选择不从这里发】`imgOcr.engine` 由 **background 单点读取并注入**（#16 D-16.1）：
         * offscreen 读不到 `chrome.storage`，而内容脚本读又会让"用户改了设置"与"这条 job 排队"
         * 两个时刻打架。所以发起方只管发图与关键词，回执里带**实际**用了哪个引擎。 */
      }, payload), (res) => {
        void chrome.runtime.lastError;
        awaitingId = Math.max(0, awaitingId - 1);
        if (res && res.requestId) {
          const rec = held.get(token);
          if (rec) rec.reqId = res.requestId;
          pending.set(res.requestId, token);
        } else {
          releaseHold(token);
          entry.state = 'fail';
          entry.error = (res && res.error) || 'OCR 引擎未响应';
          failTwin(cls.src, entry.key, entry.error, '');   // T55：这张图的孪生条目一起落失败
          notify();
          pump();                                    // 额度已归还 ⇒ 把队里的接着发
        }
      });
    } catch (e) {
      awaitingId = Math.max(0, awaitingId - 1);
      releaseHold(token);
      entry.state = 'fail';
      entry.error = String((e && e.message) || e);
      failTwin(cls.src, entry.key, entry.error, '');     // T55：同上
      notify();
      pump();                                        // 同上：同步失败也占过一次额度
    }
    armSweep();
    return true;
  }

  /**
   * 【补发：额度一归还就把队里的接着发】（用户报「一页多图卡在排队中」）
   *
   * 没有它的话：`submit()` 满额时**直接返回 false**（见上），而所有"归还额度"的出口
   * （同步失败 / 回执没带 requestId / 结果回来 / 超时收口）以前都只管归还、**不再看队列**
   * ⇒ 一页里超过 `MAX_INFLIGHT`（4）的图在**静态页面**上会一直停在「排队中…」，
   * 要等下一次重建/扫描才可能被顺带提交。
   * 实测（9 张图一页）：3 张完成后，其余 6 张在 +30s 与 +90s 两次取样都还没被提交。
   *
   * 重入用 `pumping` 挡住：`submit()` 里同步失败会立刻走到归还路径、再回调 `pump()`，
   * 不挡的话递归深度＝剩余图片数（长页面会爆栈）。挡住之后由**最外层那一趟**继续往下发。
   */
  let pumping = false;
  function pump() {
    if (pumping) return 0;
    pumping = true;
    let n = 0;
    try {
      for (const it of items.values()) {
        if (quotaUsed() >= MAX_INFLIGHT) break;
        if (it.state !== 'idle') continue;
        if (submit(it)) n += 1;             // 失败的会在 submit 内部落到 fail/blocked，不会在这里打转
      }
    } finally { pumping = false; }
    if (n) notify();
    return n;
  }

  /**
   * 采纳一条「右键识别」的回执（2.0.1.17 · SPEC 需求 6）。
   * 为什么单开一条路：这条结果**不是扫描链发起的** —— 没有规则、没有命中、`held`/`pending`
   * 里也没有它的账（`via` 只在 `background` 的回执上加，见 `background/ocr.js` 的 `deliver`），
   * 所以不能走 token 认领。键按 `src` 去重：同一张图重复右键只留一行，且**取最新一次**
   * （用户刚点的就是它）。失败也要建行 —— SPEC `L274`：识别服务不可用时必须如实告知，不得静默。
   */
  function adoptContextMenu(msg) {
    const src = String(msg.src || '');
    const key = 'ctxmenu|' + (src || ('#' + String(msg.requestId || '')));
    let it = manual.get(key);
    if (!it) {
      it = {
        key: key, ruleId: '@ctxmenu', rule: null,
        keyword: '', label: '',
        src: src, cls: { ok: true, src: src, host: hostOfSrc(src) }, host: hostOfSrc(src),
        state: 'pending', matched: [], text: '', conf: 0, via: 'contextMenu'
      };
      manual.set(key, it);
    }
    /* 【2.0.2.15 需求②】**受理即回执**（background 的 OCR_QUEUED）：用户点完右键那一刻就把行建出来，
     * 面板因此立刻画出「截图」卡（带"识别中…"）。旧行为只在结果/失败回来时才建行 ——
     * 用户点完右键，屏幕上什么都不会发生，像功能坏了。这里不改状态（仍是 pending），
     * 结果/失败交给下面的分支在原地改。 */
    if (msg.accepted) { notify(); return; }
    it.engine = msg.engine || '';
    it.engineReason = msg.engineReason || '';
    if (msg.ok) {
      it.state = 'done';
      it.text = String(msg.text || '');
      it.conf = msg.confidence || 0;
      it.ocrMs = msg.ocrMs;
      it.why = msg.notice || '';
      it.coverPx = (msg.coverage && msg.coverage.coveredTo) || 0;
      it.coverage = msg.coverage || null;
      /* 顺手进缓存（2.0.2.15）：大图里点「OCR 识别」、以及灯箱拿全文都走 `textOf(src)`，
       * 右键识别的那张图必须和扫描链一样能被 `textOf` 读到 —— 否则同一张图会再识别一次，
       * 且灯箱开着时结果回来也刷不出全文。 */
      const ck = absOf(it.src);
      if (ck) cachePut(ck, { text: it.text, conf: it.conf, at: Date.now(), ocrMs: it.ocrMs });
    } else {
      it.state = 'fail';
      it.error = msg.error || '识别失败';
      it.errorCode = msg.code || '';
      /* 失败时**不许**留着成功态的 why：`ocr-copy.js` 的 `keyOf()` 会先认表内 why，
       * 留着就会把一次失败说成「已识别」。只有引擎明确的 lang-missing 才写进 why。 */
      it.why = (msg.code === 'lang-missing') ? 'lang-missing' : '';
    }
    notify();
  }

  /* ---------------- 大图里点「OCR 识别」（2.0.2.15 需求①） ---------------- */

  /** 灯箱那边等着的识别：requestId → 结算器 */
  const oneWaits = new Map();

  /** 灯箱文案（真源 `KH.OcrCopy.VIEW`；这里只在没加载到真源时给 ASCII 兜底） */
  function lightboxText(key, fallback) {
    const V = (KH.OcrCopy && KH.OcrCopy.VIEW) || {};
    return V[key] || fallback;
  }

  /** 这张图已经认出来的文字（空串 = 还没有）。缓存优先，其次看现有条目（扫描链/右键都可能已经认过）。 */
  function textOf(raw) {
    const s = absOf(raw);
    if (!s) return '';
    const c = textCache.get(s) || textCache.get(String(raw || ''));
    if (c && c.text) return String(c.text);
    for (const it of allItems()) {
      if (it && it.text && it.src && absOf(it.src) === s) return String(it.text);
    }
    return '';
  }

  /**
   * 这张图的**结构化行**（`{t,y,x,cells:[{t,x,x2}]}`，2.0.2.19 需求②⑤）。
   * 面板排版表格/左右双栏要用单元格坐标；缓存优先，条目兜底（与 `textOf` 同一条取数路）。
   * @returns {object[]} 空数组 = 不知道版式（照旧按纯文本展示）
   */
  function linesOf(raw) {
    const s = absOf(raw);
    if (!s) return [];
    const c = textCache.get(s) || textCache.get(String(raw || ''));
    if (c && c.lineList && c.lineList.length) return c.lineList;
    for (const it of allItems()) {
      if (it && it.lineList && it.lineList.length && it.src && absOf(it.src) === s) return it.lineList;
    }
    return [];
  }

  /** 大图 OCR 的回执：回填缓存 + 叫醒等它的那一个（不进 items/manual —— 它不挂在任何规则上） */
  function adoptLightbox(msg) {
    const text = String(msg.text || '');
    if (msg.ok && msg.src) {
      cachePut(absOf(msg.src), {
        text: text, conf: msg.confidence || 0, at: Date.now(), ocrMs: msg.ocrMs,
        lineList: msg.lineList || []
      });
    }
    const w = oneWaits.get(msg.requestId);
    if (w) {
      oneWaits.delete(msg.requestId);
      if (w.timer) clearTimeout(w.timer);
      if (msg.ok) w.resolve(text);
      else w.reject(Object.assign(new Error(msg.error || lightboxText('paneOcrFail', 'OCR failed')), { code: msg.code || '' }));
    }
    notify();
  }

  /**
   * 认一张图，返回识别文本（大图灯箱那枚「OCR 识别」按钮就等这个）。
   * 已有文本直接回（不重复跑引擎）；结果只进缓存、不进面板 —— 灯箱是临时视图，
   * 在「重要笔记」里多出一行反而是噪声。
   */
  function ocrOne(raw) {
    const src = absOf(raw) || String(raw || '');
    if (!src) return Promise.reject(new Error(lightboxText('paneOcrFail', 'OCR failed')));
    const hit = textOf(src);
    if (hit) return Promise.resolve(hit);
    return new Promise((resolve, reject) => {
      let settled = false;
      const done = (err, text) => {
        if (settled) return;
        settled = true;
        if (err) reject(err); else resolve(text);
      };
      if (typeof chrome === 'undefined' || !chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') {
        done(new Error(lightboxText('paneOcrFail', 'OCR failed')));
        return;
      }
      try {
        chrome.runtime.sendMessage({ type: MSG.OCR_IMAGE, src: src, via: 'lightbox' }, (res) => {
          if (settled) return;
          if (!res || !res.ok) {
            const code = String((res && res.code) || '');
            done(Object.assign(new Error(code === 'src-rejected'
              ? lightboxText('paneOcrDenied', 'This image address is not allowed')
              : lightboxText('paneOcrFail', 'OCR failed')), { code: code }));
            return;
          }
          /* 兜底超时：background 的看门狗会先到；这一层只防"回执永远不来"（SW 被杀） */
          const timer = setTimeout(() => {
            oneWaits.delete(res.requestId);
            done(Object.assign(new Error(lightboxText('paneOcrFail', 'OCR failed')), { code: 'timeout' }));
          }, JOB_STALE_MS);
          if (timer && typeof timer.unref === 'function') timer.unref();
          oneWaits.set(res.requestId, {
            src: src, timer: timer,
            resolve: (t) => done(null, t), reject: (e) => done(e)
          });
        });
      } catch (e) { done(e); }
    });
  }

  /** 结果回来（background 中转） */
  function onResult(msg) {
    /* 【右键任意图 OCR】先认领这一类：它没有 token 账可对，硬走下面的额度逻辑只会空转 */
    if (msg.via === 'contextMenu') { adoptContextMenu(msg); return; }
    /* 大图里点的「OCR 识别」：不属扫描链、也不进面板，只回填缓存 + 叫醒灯箱那一边 */
    if (msg.via === 'lightbox') { adoptLightbox(msg); return; }
    /* ① 先把这笔账认出来**按 token** 归还 —— 与 src 无关，这是 #16 ③ 的根治点 */
    let token = pending.get(msg.requestId) || null;
    const src = msg.src || '';
    if (!token && src) {
      /* 兜底：结果带 src 但 requestId 对不上（页面重建 / 消息重投）→ 按 src 找回那一笔 */
      for (const [t, rec] of held) { if (rec.src && rec.src === src) { token = t; break; } }
    }
    const rec = token ? held.get(token) : null;
    const key = rec ? rec.key : null;
    if (token) releaseHold(token);      /* 幂等：认领不到就没有副作用 */

    const text = String(msg.text || '');
    /* PDF 回执没有 `lineList`（没有单元格坐标），只有**行文本** —— 在这里统一成同一种形状，
     * 重要笔记的 `#表` 取值（按「行号 ↔ lineList 下标」取值）因此对 PDF 也能用。 */
    const pdfLineList = (Array.isArray(msg.lines) ? msg.lines : text.split('\n'))
      .map((t) => ({ t: String(t == null ? '' : t) }))
      .filter((l) => l.t);
    if (msg.ok && src) {
      cachePut(src, {
        text: text, conf: msg.confidence || 0, at: Date.now(), ocrMs: msg.ocrMs || msg.ms,
        lineList: msg.via === 'pdf' ? pdfLineList : (msg.lineList || [])
      });
    }

    /* 结果对应的那条（可能因为页面重建而不在了：那就只更新缓存，不动 UI） */
    const entry = key ? items.get(key) : null;
    /* 【T55】结果属于**一张图**：同 `src` 的条目要一起更新（两条规则各一条）。
     * 旧实现写成 `entry ? [entry] : 同 src 全部` ⇒ 命中 token 那张时孪生条目拿不到结果。 */
    const targets = [];
    if (entry) targets.push(entry);
    for (const it of sameSrcItems(src, entry ? entry.key : null)) targets.push(it);
    for (const it of targets) {
      if (msg.ok) {
        it.state = 'done';
        it.text = text;
        it.conf = msg.confidence || 0;
        /* 【2.0.6.1 需求①③⑦】命中判定与"差在哪"一次算完：`missingValues` = 点名的动态值里
         * 图上没找到的那几个 —— 面板照实说出来，不再只给一个"没命中"。 */
        const ji = judgeInfo(it.rule, text, it.need, it.label);
        it.matched = ji.hits;
        it.needMissingValues = ji.missingValues;
        it.needWeakValues = ji.weakValues || [];
        /* 【2.0.11】比对结论与命中一次算完：同一张图上 `#比` 的项全在＝一致 */
        /* 【用户 m07238】比对值可能是**同一规则里另一张图**（证书）刚进表的：这轮结果到达后
         * 重算整条规则的 `cmpReqs`+`cmp`，别沿用建条目时那份（那时证书还没识别完 ⇒ 「没取到值」）。 */
        recordCmpForRule(it.rule);
        it.lineList = (it.kind === 'pdf') ? pdfLineList : (msg.lineList || []);
        it.ocrMs = msg.ocrMs || msg.ms;
        if (it.kind === 'pdf') {
          it.pages = msg.pages | 0;
          it.warnings = Array.isArray(msg.warnings) ? msg.warnings : [];
        }
        /* 引擎**如实告知**的"结果不完整/不可靠"（不变量 1/2，D-14.5）：
         * `no-text`（一个字没认出）/`tilted`（方向可疑）/`truncated`（只读了前 8 块）。
         * `why` 直接沿用引擎给的 notice 键 —— `ocr-copy.js` 认得这几个键，
         * 且 `keyOf` 里 hit 优先：真命中就照常说命中，不拿"截断"掩盖已找到的词。 */
        it.why = msg.notice || '';
        it.coverPx = (msg.coverage && msg.coverage.coveredTo) || 0;
        it.coverage = msg.coverage || null;
        /* 实际用了哪个引擎（#12/#16）：`engineReason` 非空 = 这次是**回落**跑的。
         * 面板据此在展开说明里写清"已从 PP-OCR 回落到兼容引擎：<原因>" —— 宁可让用户知道慢，
         * 也不许让他以为"主引擎一直在正常工作"。 */
        it.engine = msg.engine || '';
        it.engineReason = msg.engineReason || '';
      } else {
        it.state = 'fail';
        it.error = msg.error || '识别失败';
        it.errorCode = msg.code || '';
        it.engine = msg.engine || '';
        it.engineReason = msg.engineReason || '';
        if (msg.code === 'lang-missing') it.why = 'lang-missing';
        /* 需求⑨：失败的图记一笔，别让下一轮扫描再排一次（右键手动那种条目不记）。
         * 【2.0.12.10】被取消不算失败：页面走了才取消，冻 10 分钟会让"后退回来"的同一张图不再识别。 */
        if (it.src && msg.code !== 'cancelled' && !/^ctxmenu\|/.test(it.key)) noteFail(it.src);
      }
    }
    if (targets.length) notify();
    pump();                                          // 结果回来＝额度归还 ⇒ 补发队里的图
  }

  /* ---------------- Feature：⑦Consume 采集 ---------------- */

  /**
   * 一个锚点里要抽文字的 PDF（2.0.6.5 需求②），按文档序、与图片同口径限流。
   * 认的是页面自己声明的引用（`KH.Fetch.pdfRefOf`：`<a href>`/`<iframe src>`/`<embed src>`/`<object data>`），
   * 与负责渲染占位标记的 `pdfPlaceholder` **是同一个判据** —— 否则条目和面板里那个占位框会对不上号。
   * 【不套跨域白名单】PDF 由 offscreen（扩展页 + `host_permissions: <all_urls>`）直接 fetch，
   * 不受页面 CORS 约束；图片要读像素、跨源拿不到，所以才需要那道授权闸门。别照抄。
   */
  /* 值格常常跨行：`collectRightBlock` 认不出下一行标签（写法差一个字/多一列）时会顺势把
   * 下面几行一起收进同一个字段。于是**别的字段那行的 PDF** 被记到上面这个字段名下 ——
   * 用户看到的就是「这个字段根本没有 PDF，笔记里却多出一张、地址还是别人的」。
   * 判据（保守，只认确定的情况）：这一格所在行的首格文字**正好等于**另一个已配置字段名 ⇒ 不归当前字段。
   * 首格读不到、或行标签是别的写法（含并排标题格）一律放行，避免把正常跨行取值误伤。 */
  function rowLabelOfCell(cell) {
    const tr = cell && cell.parentElement;
    const first = tr && tr.cells && tr.cells[0];
    if (!first || first === cell) return '';
    return String(first.textContent == null ? '' : first.textContent).replace(/\s+/g, '');
  }
  function ownsCellFor(label, cell, allLabels) {
    const rl = rowLabelOfCell(cell);
    if (!rl) return true;
    const own = String(label || '').replace(/\s+/g, '');
    if (own && rl.indexOf(own) >= 0) return true;
    for (const l of (allLabels || [])) if (l !== own && rl === l) return false;
    return true;
  }
  function collectPdfs(rule, fields) {
    const F = KH.Fetch;
    if (!F || typeof F.pdfRefOf !== 'function') return [];
    /* 【2.0.15 · PDF 与字段一一对应（用户 m12161）】旧实现把锚点下**所有**抓取字段的值格并成
     * 一个集合扫一遍，再按 `imgOcrMax`（默认 1）**全局**截断，标签只记「第一个遇到该格的字段名」。
     * 后果是写死的两条：①配了两个 PDF 字段也只出一张牌；②牌上的名字与地址可以互相张冠李戴。
     * 现在逐字段取：每个字段只看自己的值格、各自限流、各带自己的字段名 ——
     * 没配到 PDF 的字段再也不会凭空多出一张牌。 */
    const perMax = Math.max(1, (rule && rule.meta && rule.meta.imgOcrMax) || 1);
    const out = [];
    const seen = new Set();
    const allLabels = [];
    for (const f of (fields || [])) {
      if (!f || f.noImg) continue;
      const l = String(f.label || '').replace(/\s+/g, '');
      if (l) allLabels.push(l);
    }
    for (const f of (fields || [])) {
      if (!f || f.noImg) continue;
      const label = String(f.label || '');
      const cells = f.cells || [];
      let got = 0;
      for (let ci = 0; ci < cells.length && got < perMax; ci++) {
        const cell = cells[ci];
        if (!cell || !cell.querySelectorAll) continue;
        if (!ownsCellFor(label, cell, allLabels)) continue;
      /* 先按标签捞、再由 `pdfRefOf` 判是不是 PDF：一个属性选择器就能少一次遍历，
       * 但那要求垫片也支持 `[href]`（`tests/harness.js` 只认 tag/.class/后代），
       * 判据本来就在 `pdfRefOf` 里，没必要在两处各写一遍。 */
        for (const el of cell.querySelectorAll('a, iframe, embed, object')) {
          if (got >= perMax) break;
          if (isExtUi(el)) continue;
          const src = F.pdfRefOf(el);
          if (!src || seen.has(src)) continue;
          seen.add(src);
          /* 【2.0.7.1 需求②】带上它所在的抓取字段：作用域关键词与面板行都要知道"这张 PDF 属于哪个字段" */
          out.push({ src: src, label: label });
          got++;
      }
      /* 【2026-11-18 用户实测 m04718】`<span class="content-pdf">PDF</span>` 这类没有 href 的控件：
       * 地址由 `KH.Fetch.kickAutoPdf` 点开一次抓回来（`F.autoPdfOf`），这里必须同样认，
       * 否则面板重画也不会为它建条目（条目只在 build 里建，`consumeOnly` 会跳过整个 build）。 */
      if (F.AUTO_PDF_SEL) {
        let nodes = [];
        try { nodes = cell.querySelectorAll(F.AUTO_PDF_SEL); } catch (e) { nodes = []; }
          for (const el of nodes) {
            if (got >= perMax) break;
            if (isExtUi(el)) continue;
            const src = (typeof F.autoPdfOf === 'function') ? F.autoPdfOf(el) : '';
            if (!src || seen.has(src)) continue;
            seen.add(src);
            out.push({ src: src, label: label });
            got++;
          }
        }
      }
    }
    return out;
  }

  /**
   * 本轮要处理的「锚点」= `{ rule, cell }`，来源**只有一个**：
   *   · `hits`：**真命中所在格**（普通词与组合词走同一套 `cellOfHit`）。
   * 锚点**只用来定位"在哪张表/哪一行"**：取图范围一律以「抓取后续字段」为准（见 build）。
   *
   * 【K75】原来还有第二条来源 `ctx.imgAnchors`（组合词 Probe 在"标题词定位到那一格"时就登记，
   * **不看核心词有没有命中**）。用户口径：「判断命中了普通词/组合词没有…如果没有命中，
   * 那就不需要考虑图片 ocr 和图片关键词」⇒ 那条来源已删（生产方也删了，见 combo.js）。
   *
   * 准入条件（第 1/2 条，保持不变）：
   *   · `meta.imgOcr` 未勾选 → 跳过；
   *   · `meta.fetchLabels` 为空 → 跳过（没配抓取字段就无从取图）；
   *   · `meta.imgOcrKeyword` 为空 → 跳过（没有匹配口径，条目只会是噪声）。
   */
  function anchorsFor(ctx, hits) {
    const out = [];
    const seen = new Set();
    const push = (rule, cell) => {
      if (!rule || !rule.meta || !cell) return;
      if (!rule.meta.imgOcr) return;
      if (!String(rule.meta.fetchLabels || '').trim()) return;
      if (!String(rule.meta.imgOcrKeyword || '').trim()
        && !String(rule.meta.imgOcrNeed || '').trim()) return;
      const key = String(rule.ruleId) + '|' + idxOf(cell);
      if (seen.has(key)) return;
      seen.add(key);
      out.push({ rule: rule, cell: cell });
    };
    for (const h of (hits || [])) {
      if (!h || !h.meta || !h.meta.imgOcr || !h.textNode) continue;
      /* 命中记录带的是 rule.meta 的快照（没有 pattern/labelPattern，本 Feature 也不需要） */
      push({ ruleId: h.ruleId, meta: h.meta }, cellOfHit(h, ctx));
    }
    return out;
  }

  /** 元素身份键（只为"同一格不重复处理"去重；用自增序号，避免给页面元素挂属性） */
  const cellIds = new WeakMap();
  let cellSeq = 0;
  function idxOf(el) {
    if (!el || typeof el !== 'object') return '?';
    let id = cellIds.get(el);
    if (!id) { id = ++cellSeq; cellIds.set(el, id); }
    return String(id);
  }

  function cellOfHit(h, ctx) {
    const Cells = KH.Cells;
    if (Cells && typeof Cells.cellOf === 'function') {
      try { const c = Cells.cellOf(h.textNode, ctx || {}); if (c) return c; } catch (e) { /* 落回兜底 */ }
    }
    const el = h.textNode.parentElement;
    if (!el) return null;
    if (el.closest) { const td = el.closest('td,th'); if (td) return td; }
    return el;
  }

  function build(cfg, ctx, hits) {
    const next = new Map();
    for (const anchor of anchorsFor(ctx, hits)) {
      const rule = anchor.rule;
      /* 取图范围 = 按**同一个 `fetchScope`** 选定的层级里，所有已配置抓取字段的值格
       * （不管字段有没有 `#图` 修饰）—— K74 §四.5：你选哪一层抓字段，就从哪一层的值格取图。
       * `Fetch.cellsForHit` 是只读访问口，抓取内容的既有语义（#图/#N/跨格累计/去重）一点不动。 */
      const fields = (KH.Fetch && typeof KH.Fetch.cellsForHit === 'function')
        ? KH.Fetch.cellsForHit(anchor.cell, rule.meta || '')
        : [];
      if (!fields.length) continue;
      /* 【2.0.2.19 需求③】这些抓取字段的值同时是**动态关键词**（见 `judge`）。
       * 【2.0.4 需求②】取值改走 `Fetch.extractFor`（与重要笔记表格同一份实现），
       * 所以锚点/字段名都从 `anchor.cell` 重算 —— 不再复用 `cellsForHit` 的裸名字典。
       * 【2.0.6.1 需求①③】改用 `needInfo`：`needMissing` 是「点名了却没取到值」的字段名，
       * 面板据此把「为什么不命中」说出来（旧实现这条路全是静默 `[]`）。 */
      const valueCells = [];
      const labelOfImg = new Map();
      /* 【2.0.7.1 需求②】动态判据按**图片所属抓取字段**分开算（`@字段名` 作用域）；
       * 同一锚点内同字段只算一次（`extractFor` 不便宜），缺省字段用全局那份。 */
      const needCache = new Map();
      const needFor = (label) => {
        const k = String(label || '');
        if (needCache.has(k)) return needCache.get(k);
        const one = needInfo(anchor.cell, rule, k);
        const got = { values: one.values, want: one.want, missing: one.missing };
        needCache.set(k, got);
        return got;
      };
      for (const f of fields) {
        /* 【字段级抠图开关 `#0`（2.0.2.5 需求①后段）】多个抓取字段里不止一个带图时（截图 + icon + logo），
         * 用 `icon#0` 点名"这个字段的图不参与图片识别"；它的图同时也被 applyImgPolicy 从抓取内容里剔掉。
         * 判定在 Fetch 侧（`cellsForHit` 返回的 `noImg`），这里只照办 —— 不在本模块养第二套后缀语法。 */
        if (f.noImg) continue;
        for (const c of (f.cells || [])) valueCells.push(c);
        for (const im of (f.imgs || [])) if (!labelOfImg.has(im)) labelOfImg.set(im, f.label);
      }
      if (!valueCells.length) continue;
      /* 【不能因为"读不出地址"就丢掉条目（K62）】跨域/懒加载/协议不认识的图都要**留在表里**并带上原因，
       * 否则面板什么都不显示、诊断是「条目=0」，用户完全不知道发生了什么。没有 src 的用序号兜底做键。 */
      for (const got of collectImages({ rule: rule, valueCells: valueCells, anchorCell: anchor.cell }, cfg)) {
        const cls = got.cls;
        const src = cls.src || '';
        const key = rule.ruleId + '|' + (src || ('#' + got.idx));
        if (next.has(key)) continue;
        /* 【2.0.6.2 需求①】缓存读和写要同键：右键/灯箱写的是 `absOf(src)`，扫描链写的是原始
         * `src`，这里只按原始 src 查 ⇒ 经过绝对化的同一张图会被当成没识别过、掉回 idle 重排队
         * （失败一次还会落进 `failSrc` 冻 10 分钟）。两边都试一遍，顺序与 `textOf` 一致。 */
        const cached = src ? (textCache.get(src) || textCache.get(absOf(src))) : null;
        const label = String(labelOfImg.get(got.img) || '');
        /* 【2.0.7.1 需求②】这张图属于哪个字段，就只用那个字段的（+ 全局）词/判据 */
        const nf = needFor(label);
        /* 【2.0.11】这张图要核对哪几项（只有打了 `#比` 才有；没有就是空数组） */
        const creq = cmpReqs(rule, label, anchor.cell);
        const item = {
          key: key, ruleId: rule.ruleId, rule: rule,
          /* 面板行的关键词标签显示**图片命中关键词**（用户确认第 6 条）——它才是"在图里找什么" */
          keyword: String((rule.meta && rule.meta.imgOcrKeyword) || ''),
          label: label,
          src: src, cls: cls, host: cls.host || '',
          state: 'idle', matched: [], text: '', conf: 0,
          need: nf.values, needWant: nf.want, needMissing: nf.missing,
          needWeak: nf.weak || [], needFrom: nf.fromExtra || [],
          needMissingValues: [], lineList: [],
          cmpReqs: creq, cmp: null,
          /* 比对值要等 OCR 回来才齐（证书图的基准值），所以锚点留在条目上：
           * 结果到达时用它重算 `cmpReqs`（`recordCmp`），不能沿用建条目时那份空值。 */
          anchorCell: anchor.cell || null,
          cellText: String((anchor.cell && anchor.cell.textContent) || '').trim().slice(0, 120)
        };
        if (cached) {
          item.state = 'done';
          item.text = cached.text;
          item.conf = cached.conf;
          const ji = judgeInfo(rule, cached.text, item.need, label);
          item.matched = ji.hits;
          item.needMissingValues = ji.missingValues;
          item.needWeakValues = ji.weakValues || [];
          item.cmp = cmpJudge(rule, cached.text, label, creq);
          item.lineList = cached.lineList || [];
          /* 【耗时徽标必须跟着缓存走】(K80 · 真机踩到) 条目表每次重建都从缓存重建，
           * 而 `ocrMs` 此前只活在**当时那个条目对象**上 ⇒ 页面一有变动（重建）耗时徽标就空了。
           * 真机表现：E2E「每个图片条目都该显示本次识别耗时」变红（`cost:""`）。
           * 缓存里带上它之后，重建出来的条目照旧显示**这张图那次识别**的耗时。 */
          item.ocrMs = cached.ocrMs;
        } else if (!cls.ok) {
          item.state = 'blocked';
          item.why = cls.why;
        } else if (failSrc.has(src) && Date.now() - failSrc.get(src) < FAIL_MEMO_MS) {
          /* 【2.0.6.1 需求⑨】这张图刚识别失败过（引擎报错 / 超时 / 无文字且 rescue 全跑空），
           * 同一次会话里**不再重新排队**。旧行为：页面每一次重扫都把它当新条目、再提交一遍，
           * 于是"没文字的图也要跑好几秒"在面板反复重建时成倍放大（用户说的"没文字也耗时很长、
           * 页面卡顿"多半就是这条）。失败信息仍照实显示，10 分钟后自动允许重试一次。 */
          item.state = 'fail';
          item.why = 'retry-later';
        } else if (inflight.has(src)) {
          item.state = 'pending';
        }
        next.set(key, item);
      }
      /* ---- PDF（2.0.6.5 需求②）：只是"另一类待抽文字的引用"，与图片共用条目表 / 缓存 /
       * 额度 / 面板通知。键里带 `|pdf|`，避免与同地址的图片条目撞号（现实里也不会同址）。 ---- */
      for (const got of collectPdfs(rule, fields)) {
        const src = got.src;
        const key = rule.ruleId + '|pdf|' + src;
        if (next.has(key)) continue;
        const cached = textCache.get(src) || textCache.get(absOf(src));
        const label = String(got.label || '');
        const nf = needFor(label);
        /* 【2.0.11】这张图要核对哪几项（只有打了 `#比` 才有；没有就是空数组） */
        const creq = cmpReqs(rule, label, anchor.cell);
        const item = {
          key: key, ruleId: rule.ruleId, rule: rule, kind: 'pdf',
          keyword: String((rule.meta && rule.meta.imgOcrKeyword) || ''),
          label: label, src: src, cls: { ok: true, src: src }, host: hostOfSrc(src) || '',
          state: 'idle', matched: [], text: '', conf: 0,
          need: nf.values, needWant: nf.want, needMissing: nf.missing,
          needWeak: nf.weak || [], needFrom: nf.fromExtra || [],
          needMissingValues: [], lineList: [],
          cmpReqs: creq, cmp: null,
          /* 比对值要等 OCR 回来才齐（证书图的基准值），所以锚点留在条目上：
           * 结果到达时用它重算 `cmpReqs`（`recordCmp`），不能沿用建条目时那份空值。 */
          anchorCell: anchor.cell || null,
          cellText: String((anchor.cell && anchor.cell.textContent) || '').trim().slice(0, 120)
        };
        if (cached) {
          item.state = 'done';
          item.text = cached.text;
          item.conf = cached.conf;
          const ji = judgeInfo(rule, cached.text, item.need, label);
          item.matched = ji.hits;
          item.needMissingValues = ji.missingValues;
          item.needWeakValues = ji.weakValues || [];
          item.cmp = cmpJudge(rule, cached.text, label, creq);
          item.lineList = cached.lineList || [];
          item.ocrMs = cached.ocrMs;
        } else if (failSrc.has(src) && Date.now() - failSrc.get(src) < FAIL_MEMO_MS) {
          item.state = 'fail';
          item.why = 'retry-later';
        } else if (inflight.has(src)) {
          item.state = 'pending';
        }
        next.set(key, item);
      }
    }
    /* 右键识别的条目不属于任何规则：扫描链重建时**并回去**，别把它冲掉（用户手动要的那一行
     * 不该因为页面变动就消失；它自己有过结果、也留在 `manual` 里）。
     * 【2.0.6.2 需求①】并回去时补一次判决：这类条目 `rule` 是 null、`matched` 是空，于是
     * "事后给它加图片命中关键词"永远算不出命中（不是没重算，是根本没有算的地方）。用**当前配置**
     * 的规则补判，命中就挂上那条规则 —— 之后面板能解释、KV 行也能出。 */
    let manualRules = null;
    for (const pair of manual) {
      if (next.has(pair[0])) continue;
      const it = pair[1];
      if (it && it.text && (!it.matched || !it.matched.length)) {
        if (!manualRules) manualRules = KH.Compiler.compileAll(cfg) || [];
        for (const r of manualRules) {
          const meta2 = r.meta || {};
          if (!meta2.imgOcr) continue;
          const ji = judgeInfo(r, it.text, []);
          if (!ji.hits.length) continue;
          it.matched = ji.hits;
          it.rule = r;
          it.ruleId = r.ruleId;
          it.keyword = String(meta2.imgOcrKeyword || '');
          break;
        }
      }
      next.set(pair[0], it);
    }
    items = next;
    /* 采集完再统一排队（先建表再提交，避免结果回来时条目还没建） */
    for (const it of items.values()) {
      if (it.state === 'idle') submit(it, cfg);
    }
  }

  if (KH.features) {
    KH.features.register('img-ocr', {
      /**
       * @param {object[]} hits 注册表命中 —— 普通词与组合词**都走这条路**：
       *   用"命中所在格"当锚点（K75 起**唯一**来源；`ctx.imgAnchors` 那条旧路已删）。
       * @param {object} cfg 当前配置
       * @param {object} ctx 扫描上下文（管线注入）
       */
      consume(hits, cfg, ctx) {
        /* 【仅消费通道要跳过这里】P2 的快通道只重跑 ⑦Consume 来刷"抓取字段"，
         * 它给的 hits 里没有本轮的全部命中 —— 照常 build 会把已有图片命中**清空**。
         * 图片相关的变更本来就会判成 'full'（见 relevance.js ④），所以这里直接不动是最安全的。
         *
         * 【本早退的**前提**，T52 写显】上面那句"图片相关的变更必然判 'full'"不是自动成立的，
         * 它靠的是「`imgOcr` 在核心签名里」这一件事：改它 ⇒ 核心签名变 ⇒ 整页重建 ⇒ 走的是
         * 非 consumeOnly 路径 ⇒ `classify()` 用新配置重算。**别把 `imgOcr` 移进 `index.js` 的
         * `UI_ONLY_KEYS`**（T36b 正是这么干的，结果跨域白名单 `crossOriginSites` 的页面侧唯一读点
         * —— 本文件的 `crossOriginAllowed`，只在 `build()` 里跑 —— 在已打开的页面上不生效，
         * 要等一次真正的整页重建；回归编号 F1）。除非哪天把 `build()` 改成能安全合并"部分命中"，
         * 否则这个早退与那条分类是绑在一起的。 */
        if (ctx && ctx.consumeOnly) return;
        build(cfg, ctx, hits);
        notify();
      },
      /**
       * 重建清底：条目清掉但**缓存留着**（同一张图不必反复识别）。
       * 【签名必须与调用方一致】`src/core/rebuilder.js` 调的是 `feat.clear(root, o)`，
       * 旧实现写成 `clear(reason)` ⇒ 形参收到的是 `root`（恒为 null/元素），
       * `reason === 'destroy'` **永远不成立** —— 销毁时在途额度与去重集根本不清，
       * 下一次挂载就白少 4 个可用额度（S1-b 顺手修掉的附带缺陷）。
       * 【`pending` 不再在重建时清】它记的是"在途请求该还哪一笔账"，不是本轮扫描状态：
       * 清了会让晚到的结果认领不到（额度要等 150s 收口才回）。
       */
      clear(root, opts) {
        const destroy = !!(opts && opts.reason === 'destroy');
        /* 销毁（换页/停用）连 `manual` 一起清；普通重建只把扫描链条目清底，
         * 右键识别的行**留着**（它不属于本轮命中，清掉就等于用户白右键一次） */
        if (destroy) manual.clear();
        /* 失败备忘跟着会话走：换页/停用才清（普通重扫保留，否则页面一动就又开始重排） */
        if (destroy) failSrc.clear();
        items = new Map(Array.from(manual));
        if (destroy) {
          held.clear();
          pending.clear();
          awaitingId = 0;
          inflight.clear();
          if (sweepTimer) { clearInterval(sweepTimer); sweepTimer = null; }
        }
        notify();
      }
    });
  }

  /* 结果经 background 回到内容脚本（`to:'content'` 才是给我们的，别的上下文的消息不认） */
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg) return false;
      if (msg.to && msg.to !== 'content') return false;
      /* 受理即回执（右键那一刻）：先把行建出来，面板立刻有东西可画 */
      if (msg.type === MSG.OCR_QUEUED) {
        adoptContextMenu({ src: msg.src, requestId: msg.requestId, accepted: true });
        return false;
      }
      if (msg.type !== MSG.OCR_RESULT) return false;
      onResult(msg);
      return false;
    });
  }

  /* 【2.0.12.10 性能·旧页拖累 OCR】页面真要离开（导航走 / 关标签页 / 进前进后退缓存）时，
   * 主动告诉后台「这一页的识别都别做了」。只在后台做取消是不够的：后台看不到"这一帧的
   * 内容脚本已经不在了"，而这里恰好知道。离页后内容脚本里的 token 账已无人归还，
   * 那些排队中的任务只会白烧 CPU、并让**下一个页面**的图排在它们后面。
   * 用 pagehide 而不是 unload：unload 在新版浏览器里常被忽略，pagehide 一定发。 */
  if (typeof window !== 'undefined' && window.addEventListener) {
    window.addEventListener('pagehide', () => {
      try { chrome.runtime.sendMessage({ type: MSG.OCR_CANCEL, pageId: PAGE_ID }); } catch (e) { /* 后台不在：忽略 */ }
    });
  }

  /**
   * 面板读的就是这个：扫描链条目 + 右键识别的条目（**并集**，键不重复）。
   * 两张表分开存是因为生命周期不同（见 `manual` 的注释：一条随扫描重建生灭、一条由用户手动产生），
   * 但对读者必须是一个列表 —— 否则右键识别的结果在面板上根本不存在。
   */
  function allItems() {
    const out = Array.from(items.values());
    for (const pair of manual) if (!items.has(pair[0])) out.push(pair[1]);
    return out;
  }

  /** 【用户 m07238】同一规则下每张图的结果都会影响别的图的比对结论（证书进表 → 授权书比对），
   * 所以一笔结果到达就重算整条规则的：取值（`cmpReqs`）与判决（`cmp`）。**只算已经 done 的**。 */
  function recordCmpForRule(rule) {
    if (!rule) return;
    const ruleId = String(rule.ruleId || '');
    for (const it of allItems()) {
      if (!it || it.state !== 'done' || !it.text) continue;
      if (ruleId && String(it.ruleId || '') !== ruleId) continue;
      try {
        it.cmpReqs = cmpReqs(rule, it.label, it.anchorCell || null);
        it.cmp = cmpJudge(rule, it.text, it.label, it.cmpReqs);
      } catch (e) { /* 一条算不出来不影响别的图 */ }
    }
  }

  KH.ImgOcr = {
    items: allItems,
    /**
     * 关掉右键那张「截图」卡（2.0.2.16 需求⑦）：把这些手动条目整批丢掉。
     * 只清 `manual`，**不动 `textCache`** —— 用户说的是"这张卡不再显示"，不是"忘掉识别结果"；
     * 同一张图之后再右键仍然命中缓存，不必重跑引擎。`notify()` 会让面板重画那张卡（没有条目就不画）。
     */
    clearManual() {
      if (!manual.size) return;
      manual.clear();
      notify();
    },
    /** 当前在途额度（≥1 = 有识别在飞）。调度侧用它给重建让路（见 `scheduler.js:_deferToOcr`）
     *  —— 重建是同步全页扫描，一跑起来就把识别结果挤在门外。 */
    inflightCount: () => quotaUsed(),
    onChange: onChange,
    notify: notify,
    /** 诊断/回归用 */
    _debug: () => {
      /* 「没识别成功」的**原因分布**（K62）：用户现场是「条目=0」，但"条目=0"与
       * "条目都在但全是跨域未授权/懒加载"是两种完全不同的情形，必须能分开看。 */
      const blocked = {};
      for (const it of items.values()) {
        if (it.state === 'blocked' || it.state === 'fail') {
          let why = it.why || it.errorCode || it.error || 'unknown';
          /* 跨域必须带上**图片所在域名**：用户的下一步动作就是把它加进白名单 */
          if (it.why === 'cross-origin' && it.host) why = 'cross-origin:' + it.host;
          blocked[why] = (blocked[why] || 0) + 1;
        }
      }
      return {
        items: items.size, cache: textCache.size, pending: pending.size,
        /* `popup/popup.js` 读的就是这个键 ⇒ 键名不许改，含义＝当前占用的额度 */
        inflight: quotaUsed(),
        blocked: blocked,
        states: Array.from(items.values()).map((i) => i.key + ':' + i.state)
      };
    },
    classify: classify,
    /** 大图灯箱用：认一张图 / 取这张图已认出的文字（2.0.2.15 需求①）
     *  `linesOf` = 同一份结果的**结构化行**（含单元格坐标，2.0.2.19 需求②⑤ 排版用） */
    ocrOne: ocrOne,
    textOf: textOf,
    linesOf: linesOf,
    matchedInText: matchedInText,
    /** 动态命中判决 + 抓取值表（2.0.2.19 需求③；单测用）
     *  【2.0.4 需求②】`needOf(hitOrCell, rule)` 改成吃锚点格 + 规则（值走 `Fetch.extractFor`）。 */
    judge: judge, needOf: needOf, needNames: needNames,
    /** 【2.0.6.1 需求①③】带诊断的两个入口：
     *  `judgeInfo(rule,text,need[,field])` → `{hits, missingValues}`（图上找不到的那些动态值）
     *  `needInfo(hitOrCell,rule[,field])`  → `{values,want,missing}`（点名了却没取到值的字段名）
     *  【2.0.7.1 需求②】`field` = 这张图所属的抓取字段（`@字段名` 作用域靠它选词；省略=全局）。 */
    judgeInfo: judgeInfo, needInfo: needInfo,
    /** 【2.0.7.1 需求②】作用域诊断用：`scopeKnown(rule)` = 合法字段名；`scopedRaw(raw,field,known)` = 该字段实际生效的词 */
    scopeKnown: scopeKnown, scopedRaw: scopedRaw, literalPatternOf: literalPatternOf,
    /** 【2.0.7.2 需求①】`splitScope(chip, known)` → `{text, scopes[, scope]}`：词尾可连写多个 `@字段名` */
    splitScope: splitScope,
    /** 【#116】`scopeIssues(raw,known)` → 写错的 `@指向` 清单（只看不改判定）；
     *  `scopeIssuesOf(rule)` 把两个带指向的字段一起诊断。 */
    scopeIssues: scopeIssues, scopeIssuesOf: scopeIssuesOf,
    /** 【2.0.7.2 需求④】`needSpecs(raw,field,known)` = 要看的字段（**带用户写的后缀**，取值喂 `Fetch.extractFor`） */
    needSpecs: needSpecs,
    /** 【2.0.4 需求①】「键值行进表」标记：`kvWords(raw)` = 带 `#表`/`#kv` 标记的词（已剥标记）；
     *  `stripKvMarks(raw)` = 去掉标记的关键词原文（喂匹配用）。重要笔记那边读同一份实现。 */
    kvWords: kvWords, stripKvMarks: stripKvMarks, kvCmpWords: kvCmpWords, chipTags: chipTags,
    /** 【2.0.11 需求】「比对」：`cmpReqs(rule,field,anchor)` = 这张图要核对哪几项（只有 `#比` 的条目），
     *  `cmpJudge(rule,text,field,reqs)` 判决 → `{state:'same'|'diff', items, missing}`（空＝不比）。 */
    cmpReqs: cmpReqs, cmpJudge: cmpJudge, findInRaw: findInRaw,
    /** 列带排版（2.0.2.19 需求②⑤）：`layout(lineList)` → 模型；`layoutHtml(模型)` → 表格 HTML */
    layout: layout, layoutHtml: layoutHtml,
    /** 匹配口径的唯一编译点（诊断/单测用；见 `ocrPatternOf`） */
    ocrPatternOf: ocrPatternOf,
    build: build,
    /** 【2.0.15 · PDF 与字段一一对应】`collectPdfs(rule, fields)` → `[{src, label}]`：
     *  逐字段取、每字段各自限流、各带自己的字段名（诊断/单测用；见 build 里的调用）。 */
    collectPdfs: collectPdfs,
    /** 结果/收口的手动驱动（诊断与单测用：不依赖真实消息往返） */
    _onResult: onResult,
    _sweep: sweepStale
  };
})();
