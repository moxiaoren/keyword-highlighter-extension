/* ============================================================================
 * src/core/config.js · 默认值唯一真源 + 兼容读取 + 校验 + 迁移
 * ----------------------------------------------------------------------------
 * 铁律（方案 §2 第 5 条）：默认值只在本文件出现一次。
 *   · 其它任何文件不得再写第二份 defaults（旧版 lib/storage.js 即第二份，已废弃）。
 *   · 版本号**不在这里**定义 —— 版本唯一真源是 manifest.json（meta-check #1 校验）。
 *
 * 兼容策略（方案 §7.2「存量数据零改写」）：
 *   · 未知键：宽容保留（不删用户数据）。
 *   · 已废弃键：读取时忽略，写入时不再落盘（delete on write），避免每次 set 写回脏字段。
 *   · 绝不执行「组合词左右翻转」迁移（v1.8.4 已闭环），只做宽容读取。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** 已废弃的存储键（读到即忽略、写回即清除）。来源：方案 §7.1 + R7。 */
  const DEPRECATED_KEYS = [
    'noteFormat',            // 全文无使用场景
    'comboFlipped',          // 翻转迁移已闭环，仅存量兼容读取
    'pageCleanMinGap',       // 由 pageRebuildGapMs 统一取代
    /* 【S2】识别档位整个删掉（#12 裁决）：换成 `imgOcr.engine`。存量值由 `normalize`
     * 回落成 `auto` 并置 `migrated.ocrEngine` 标记（设置页据此给**一次性**提示）。
     * 放进 `DEPRECATED_KEYS` 的作用是**写回时物理删掉**它 —— 否则那个键会一直躺在存储里，
     * 每次读都重新触发一次"迁移"（提示没完没了）。 */
    'imgOcr.quality',
    'highlightStyle.defaultBorderColor',  // CSS.highlights 不支持边框
    'highlightStyle.defaultBorderWidth',
    'highlightStyle.defaultBorderRadius'  // 旧默认值含 typo 'iat::3px'
  ];

  /** 合法枚举（校验用）。非法值回退到默认，但不静默丢数据。 */
  const ENUMS = {
    'siteRules[].type': ['blacklist', 'whitelist'],
    'siteRules[].matchType': ['exact', 'subdomain', 'prefix', 'regex'],
    'siteRules[].scope': ['domain', 'url'],
    /* 变更处理方式（K58）：smart = 相关性预筛（省资源，默认）；always = 任何变动都整页重建（旧行为，最保守） */
    'changeHandling': ['smart', 'always'],
    /* 界面主题（2.0.8.13 需求④）：auto 跟随系统，light/dark 显式选；坏值回 auto */
    'uiTheme': ['auto', 'light', 'dark'],
    /* 图片识别引擎（S2 / #12 裁决）：`auto` = 主引擎 PP-OCR 失败时按会话回落兼容引擎（默认）；
     *  `ppocr` = 只用主引擎（失败如实报错，不偷偷退回）；`tesseract` = 只用兼容引擎。 */
    'imgOcr.engine': ['auto', 'ppocr', 'tesseract']
  };

  /**
   * 「抓取后续字段」模块开关（`fetchEnabled`）的**唯一归一函数**（K71 裁定 4）。
   *
   * 真值表（`v = value`）：
   *   · `true` / `false`            → 原样；
   *   · `undefined`（**缺键**）      → 按非空 `fetchLabels` 反推（有字段 ⇒ 启用，与新建默认一致）；
   *   · 其余"键存在"的脏值（`null` / `0` / `''` / `'false'` …）→ `!!v`
   *     （键存在就尊重：falsy 一律当**关**，绝不因脏值翻回 `true`）。
   *
   * 【为什么必须只有一个函数】读路径（本文件的 `normalize`）与写路径
   * （`src/platform/storage.js` 的 `newKeyword` / `sanitizeKeyword`）**调用的是同一个它** ——
   * 两份拷贝正是 R1-3③「两处逐字同一条」要防的东西（R4 实测过 `null` 在两路判据不一致）。
   *
   * 【为什么不依赖脚本加载顺序】storage.js 是在 `newKeyword()` 的**函数体内**做运行期查表
   * （`KH.Config.normalizeFetchEnabled(...)`），**不是**在模块求值时取引用；而且四个加载上下文
   * （manifest 的 `content_scripts`、`options/options.html`、`popup/popup.html`、`popup/editor.html`）
   * 里 `src/core/config.js` 都排在 `src/platform/storage.js` **之前**。依赖方向也对：platform → core。
   * 编译层的 `kw.fetchEnabled !== false` **不参与**本归一（缺键的手写对象仍须照旧抓取）。
   */
  function normalizeFetchEnabled(value, fetchLabels) {
    if (value === undefined) return !!(fetchLabels && String(fetchLabels).trim());
    return !!value;
  }

  /**
   * 「抓取范围」（`fetchScope`）的**方向枚举**与**唯一归一函数**（K79 重梳；旧口径见 K74 §四）。
   * 口径 = 用户 2026-09-23 的三句话：
   *   · **当前层**（`self`）  —— 命中格（「仅抓取」时为标题格）**直接所在**的那张表
   *   · **内层**（`inner`）   —— 当前层里**嵌着的表**（比它小；任意单元格里的都算）
   *   · **外层**（`outer`）   —— 当前层的**祖先表**（命中格是更大表格的内层）
   * 三个方向**可多选**；**默认「当前层」**；旧值平移见 `LEGACY_FETCH_SCOPES` 的注释。
   * 与 `normalizeFetchEnabled` 同一套写法：读路径（本文件 `normalize`）与写路径
   * （`storage.newKeyword`）调用的是**同一个它**；消费侧（`fetch.js` / `img-ocr.js` / `compiler.js`）也调它，
   * 于是"值表"只有这一份。大小写不敏感（`TB` 这类历史脏值不该炸）。
   */
  /** 抓取层级**方向**（K79 重梳后的口径，用户 2026-09-23 定义）：
   *   `self`  = **当前层**：命中格（「仅抓取」时为标题格）**直接所在**的那张表；
   *   `inner` = **内层**：当前层里嵌着的表（比它**小**的表，任意单元格里的都算）；
   *   `outer` = **外层**：当前层的**祖先表**（命中格是更大表格的内层）。
   * 三个方向**可多选**，存成**规范化字符串**（方向按 `self+inner+outer` 的固定顺序用 `+` 连接，
   * 于是"同一份选择"只有一种写法 ⇒ 导出 / CSV 往返稳定）。**默认「当前层」**。
   *
   * 旧值平移（K74 的 5 个枚举值 → 新口径）：
   *   `self → self`；`auto → self+outer`（保持"本层没有就往外找"的旧行为）；`outer1 / outermost → outer`；
   *   `all → self+inner+outer`。⚠️ `outer1`/`outermost` 原本是"只取**一层**"，新口径里 `outer` 是一个**方向**
   *   （可含多层、合并展示）—— 这是有意的语义合并，changelog 里要对用户说明。
   *
   * 归一规则：**缺键 / 空 / 全非法 → `auto`（旧口径：就近优先、只取一层）**；合法方向一律尊重、
   * 去重、按固定顺序输出。
   *   ⚠️ 为什么缺键不是新默认 `self`：这个键是 2.0.0.1 才加的，**缺键只可能来自"那个版本之前
   *   存的配置"**，当时的实际口径就是 `auto`。若在归一处改成 `self`，这些配置会**悄悄少抓外层
   *   字段**（用户看得见的行为变化）。「默认＝当前层」由**编辑器字段默认值**承担
   *   （`FieldMap` 的 `def: () => 'self'`）：新建关键词写进存储的就是 `self`，读出来也是 `self`。
   * 读路径（本文件 `normalize`）、写路径（`storage.newKeyword`）、消费侧（`fetch.js` / `img-ocr.js` /
   * `compiler.js`）**全部调这一个函数** ⇒ 值表只有这一份。
   */
  const FETCH_DIRECTIONS = ['self', 'inner', 'outer'];
  const FETCH_SCOPE_DEFAULT = 'self';
  const LEGACY_FETCH_SCOPES = { self: 'self', outer1: 'outer', outermost: 'outer', all: 'self+inner+outer' };
  /** 全部**合法规范值**（`auto` 是旧口径的兼容值，见下；其余是三个方向的非空子集，顺序固定） */
  const FETCH_SCOPES = ['auto', 'self', 'inner', 'outer', 'self+inner', 'self+outer', 'inner+outer', 'self+inner+outer'];

  function normalizeFetchScope(value) {
    const parts = Array.isArray(value) ? value : String(value == null ? '' : value).split('+');
    const picked = [];
    for (const piece of parts) {
      const s = String(piece == null ? '' : piece).trim().toLowerCase();
      if (!s) continue;
      /* ⚠️ 旧口径的 `auto`（**就近优先、只取一层**）**原样保留**：不能映射成 `self+outer`
       * —— 那会让存量用户突然多出"外层字段"（可见的行为变化）。它的"只取一层"由
       * `fetchScopeSpec().nearestOnly` 表达，消费侧照旧处理。 */
      if (s === 'auto') return 'auto';
      const mapped = LEGACY_FETCH_SCOPES[s] !== undefined ? LEGACY_FETCH_SCOPES[s] : s;
      for (const d of String(mapped).split('+')) if (FETCH_DIRECTIONS.indexOf(d) >= 0 && picked.indexOf(d) < 0) picked.push(d);
    }
    if (!picked.length) return 'auto';      // 缺键 / 空 / 全非法 ⇒ **旧口径 auto**（见下）
    return FETCH_DIRECTIONS.filter((d) => picked.indexOf(d) >= 0).join('+');
  }

  /**
   * 归一后的**范围描述**（消费侧唯一入口）：`{ scope, dirs, nearestOnly }`。
   *   · `nearestOnly === true` ⇒ 旧 `auto`：按 `dirs` 的顺序**就近优先、只取第一层命中的**；
   *   · 否则 ⇒ 把 `dirs` 里**每一层**都取出来再合并。
   */
  function fetchScopeSpec(value) {
    const sc = normalizeFetchScope(value);
    if (sc === 'auto') return { scope: sc, dirs: ['self', 'outer'], nearestOnly: true };
    return { scope: sc, dirs: sc.split('+'), nearestOnly: false };
  }

  /** 规范值 → 方向数组（顺序固定为 self / inner / outer） */
  function fetchDirections(value) { return normalizeFetchScope(value).split('+'); }

  /* ---- 重要笔记面板的默认宽度（T26，用户 2026-10-12：200 → 250，且设置页要能调）----
   * 三个常量是**唯一真源**：设置页数字输入的 min/max、面板侧的夹紧、读路径的归一全从这取。
   * 散成三份就是 R1-3③「两处逐字同一条」要防的东西（改一处忘一处 → 设置页能填、面板不认）。 */
  const PANEL_WIDTH_MIN = 200;
  const PANEL_WIDTH_MAX = 1200;   /* 【2.0.2.7】600 → 1200：用户 2026-10-15「范围给的宽一点」 */
  const PANEL_WIDTH_DEFAULT = 250;

  /**
   * 面板默认宽度的**唯一归一函数**（读路径 `normalize` 与消费侧 `important-note.js` 共用）。
   * 口径（用户 2026-10-12）：
   *   · 整数、范围 200–1200：**越界夹到边界**（用户真填了 100 或 9999，意图明确，收进合法区即可）；
   *   · 非数字 / 空 / `null` / `NaN` / `0` / 负值 → **回默认 250**：这些不是"填小了"而是坏值，
   *     面板宽度是布局承重值，坏值不许把它变成 0 宽或负宽；
   *   · `'320'` 这类**字符串数字**照收（storage 里躺过字符串，来源是手改 / 导入的旧备份）。
   */
  /**
   * 存储里的值 → 整数（取不到就是 `NaN`）。
   * 三个归一函数（面板宽 / 图片尺寸 / 正文字号）的**共用取数**：数字照收（`NaN` 交给调用者判），
   * 字符串按 `parseInt` 解（storage 里躺过 `'320'` 这种字符串数字，来源是手改 / 导入的旧备份），
   * 其余（`null` / `undefined` / 对象 / 空串）一律 `NaN` ⇒ 各函数按自己的口径回默认。
   * 抽成一处只因为同一段取数逻辑原本在三个函数里逐字抄了三遍（R1-3③：抄一份就是漂移的种子）。
   */
  function intOrNaN(value) {
    return (typeof value === 'number') ? value : parseInt(String(value == null ? '' : value).trim(), 10);
  }

  function normalizePanelWidth(value) {
    const n = intOrNaN(value);
    if (!isFinite(n) || n <= 0) return PANEL_WIDTH_DEFAULT;
    return Math.min(PANEL_WIDTH_MAX, Math.max(PANEL_WIDTH_MIN, Math.round(n)));
  }

  /* ---- 重要笔记卡片的置顶排序（2.0.2.5 需求④，用户 2026-10-15）----
   * 用户原话：「配置里面增加一个置顶排序。可以填入关键词，卡片固定置顶（最多支持3个，按顺序排列）」
   * 上限是**代码判的**（不靠用户自觉）：拆项 → trim → 丢空 → 去重 → 截断到 NOTE_PIN_MAX。
   * 解析与设置页归一**共用同一处**（`pinOrderKeys`）：设置页保存前归一、面板消费时再归一一次，
   * 手改 storage / 导入旧备份塞进 5 个词时两条路径口径一致（R1-3③：别把同一口径抄两份）。 */
  const NOTE_PIN_MAX = 3;

  /** 置顶排序文本 → 关键词数组。分隔符：`,` `，` `、` 与换行；大小写不敏感去重（保留首次写法）。 */
  function pinOrderKeys(value) {
    let parts;
    if (typeof value === 'string') parts = value.split(/[,，、\r\n]+/);
    else if (Array.isArray(value)) parts = value;
    else return [];                      // 非字符串/非数组（含 null / 数字 / 对象）→ 不置顶，不抛
    const out = [];
    const seen = new Set();
    for (let i = 0; i < parts.length; i++) {
      const s = String(parts[i] == null ? '' : parts[i]).trim();
      if (!s) continue;
      const low = s.toLowerCase();
      if (seen.has(low)) continue;
      seen.add(low);
      out.push(s);
      if (out.length >= NOTE_PIN_MAX) break;
    }
    return out;
  }

  /** 置顶排序的**唯一归一函数**（设置页回显/落盘 + 面板消费共用）：归一成 `'甲, 乙'` 这种落盘串。 */
  function normalizePinOrder(value) { return pinOrderKeys(value).join(', '); }

  /* ---- 法人查询的联网通道开关（2.0.16.7 · 用户 m20763：「这种链路可以选择打开和关闭」）----
   * 四条通道各自能关：搜狗移动版企业卡 / 爱企查 / 360 搜索 / 太极AI 兜底。
   * 口径：**只有明确的 false 算关**，缺键与坏值一律按开 —— 关通道是用户主动的动作，
   * 不该被一个脏值静默打开或静默关掉；全关也是合法配置（面板会如实写「所有通道都已关闭」）。 */
  const ENTITY_CHANNEL_KEYS = ['sogou', 'aiqicha', 'so360', 'ai'];
  const ENTITY_CHANNEL_DEFAULT = { sogou: true, aiqicha: true, so360: true, ai: true };
  function normalizeEntityChannels(raw) {
    const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    const out = {};
    for (let i = 0; i < ENTITY_CHANNEL_KEYS.length; i++) {
      const k = ENTITY_CHANNEL_KEYS[i];
      out[k] = src[k] !== false;
    }
    return out;
  }

  /* ---- 重要笔记的两个外观数字的边界（2.0.2.6 需求③）----
   * 与 PANEL_WIDTH_* 同一口径：设置页数字输入的 min/max、保存时的校验、面板侧的夹紧**都从这里取**，
   * HTML 里一律不写死。整理前的实况是三份各自为政：`imgSize` 的 40/600 只写在 options.html 的属性里
   * （而属性只是提示，浏览器不禁手填），`fontSize` 的 10/20 在 options.html、options.js、面板里各抄一份。
   * 抄一份就是"能填进非法值 / 填了不生效"的种子 —— 见 PANEL_WIDTH_MIN 上面那段同样的理由。 */
  /* 【2.0.2.7】三对边界一律放宽（用户 2026-10-15：「上下限太窄了，我有的字号设置为 8、最小却是 10，
   * 不符合预期。范围给宽一点，只要不是不合理（比如字号 999）就按手动填的设置」）。放宽后历史值
   * 自然落进区间、不再被归一函数改写。放宽≠不设界：明显不合理的值（字号 999）仍按各自口径处理。 */
  const IMG_SIZE_DEFAULT = 70;
  const IMG_SIZE_MIN = 10;        /* 40 → 10 */
  const IMG_SIZE_MAX = 1000;      /* 600 → 1000 */
  const NOTE_FONT_DEFAULT = 11;
  const NOTE_FONT_MIN = 6;        /* 10 → 6：8 号字是用户真在用的设置 */
  const NOTE_FONT_MAX = 72;       /* 20 → 72 */

  /* 【票 #48】编辑器几何的**唯一声明处**。以前 1040 写在 `.kh-modal-lg` 的 CSS 里、1100 手抄在
   * `popup.js` 的开窗参数里，文档与单测里又各抄一遍 —— 改一个数字要记得六处。
   * 现在真值只有 `EDITOR_W`，其余全是派生：
   *   · CSS `.kh-modal-lg` 的 `min(<EDITOR_W>px, 100%)` 是**静态 CSS，到不了这里** ⇒ 由
   *     `tests/specs/modal-width-resize.test.js` 读本文件核对：改这里不改 CSS，单测当场红；
   *   · 独立编辑窗口 = `EDITOR_WIN_W`（编辑器宽 + 遮罩左右各 `EDITOR_WIN_PAD`）。
   * 为什么不做成运行时 CSS 变量：页面内委托的编辑器跑在 Shadow DOM 里，变量在那儿不继承，
   * 三条打开路径的几何就会各走一路 —— 比重复一处数字更糟（changelog 承诺"三条路径几何一致"）。 */
  const EDITOR_W = 1040;          // `.kh-modal-lg` 的默认宽（1040 时三列各约 326px，4 列表格刚好放下）
  const EDITOR_WIN_PAD = 30;      // 独立窗口里编辑器两侧的遮罩留白
  const EDITOR_WIN_W = EDITOR_W + EDITOR_WIN_PAD * 2;   // = 1100
  const EDITOR_WIN_H = 500;

  /* ---- 【2.0.8.6 需求①】图文合并：图片抓取字段 + OCR 命中 ⇒ 一条「自定义标题 | 值」行 ----
   * 用户口径（原话）：「抓取字段图片-ocr动态词（指向一个文本抓取自动内容），如果命中，则出现一个
   * 自定义标题，内容就是那个抓取字段抓取到的内容」+「增加默认不展示的配置」。
   * 每条规则一张表：`field` = 抓取字段裸名（与 `imgOcrNeed` 同一套名字）、`title` = 卡片里
   * 显示的标题（留空就用字段名）、`hidden` = 默认收着（面板里点一下才展开）。
   * 归一的口径与其它配置一致：坏值回默认、去空、字段名大小写不敏感去重、标题截到 24 字。
   * 真源是本函数（设置页回显 / 读路径消费共用一份）。 */
  const MERGE_TITLE_MAX = 24;
  /* 【2.0.8.18 需求②·P1】两路值不一致时这一行怎么处理。四档与调研里的四种策略一一对应
   * （文档 §4.6）：mark＝标注但照常显示（默认，最保守）、both＝两个值并排、
   * ocr/fetch＝偏向取图上值/页面值、skip＝这一行先不出现（当没命中）。
   * 只影响**冲突**行；两侧一致的行无论选哪档都照常显示。 */
  const MERGE_CONFLICT_KINDS = ['mark', 'both', 'ocr', 'fetch', 'skip'];
  function normalizeMergeConflict(v) {
    const s = String(v == null ? '' : v).trim().toLowerCase();
    return MERGE_CONFLICT_KINDS.indexOf(s) >= 0 ? s : 'mark';
  }
  function normalizeImgMerge(raw) {
    const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    const list = Array.isArray(src.rows) ? src.rows : [];
    const out = { on: src.on !== false, rows: [] };
    const seen = new Set();
    for (let i = 0; i < list.length; i++) {
      const r = list[i] || {};
      const field = String(r.field == null ? '' : r.field).trim();
      if (!field) continue;
      const low = field.toLowerCase();
      if (seen.has(low)) continue;
      seen.add(low);
      out.rows.push({
        field: field,
        title: String(r.title == null ? '' : r.title).trim().slice(0, MERGE_TITLE_MAX),
        hidden: r.hidden === true,
        onConflict: normalizeMergeConflict(r.onConflict)
      });
    }
    return out;
  }
  /* 【2.0.17.5 · 用户 m26374】风险词库的类别码（与设置页下拉、`Risk.CATS` 同源）。
   * brand = 知名品牌（判「同名 / 蹭品牌」），其余六类 = 敏感词类别。 */
  const RISK_CATS = ['brand', 'gamble', 'porn', 'fund', 'fraud', 'loan', 'other'];
  const RISK_WORD_MAX = 40;
  const RISK_CUSTOM_MAX = 600;
  function normalizeRiskWord(w) {
    return String(w == null ? '' : w).trim().slice(0, RISK_WORD_MAX);
  }
  /**
   * 风险词库的**唯一归一**（读路径 `Risk.lexicon` 与设置页回显共用）。
   * 只做形状清洗：自定义词去空/去重（按归一后比对，避免「微 信」「微信」两条）、类别非法回 other、
   * 停用清单同样按归一写法去重，`remoteUrl` 只认 http(s)。
   * @param {*} raw 存储里的 riskLexicon
   */
  function normalizeRiskLexicon(raw) {
    const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    const out = { custom: [], disabled: [], remoteUrl: '' };
    const seen = new Set();
    const list = Array.isArray(src.custom) ? src.custom : [];
    for (let i = 0; i < list.length && out.custom.length < RISK_CUSTOM_MAX; i++) {
      const it = list[i] || {};
      const w = normalizeRiskWord(it.w);
      const key = normalizeRiskWord(it.w).toLowerCase();
      if (!w || !key || seen.has(key)) continue;
      seen.add(key);
      const cat = RISK_CATS.indexOf(String(it.cat || '')) >= 0 ? String(it.cat) : 'other';
      out.custom.push({ w: w, cat: cat });
    }
    const ds = Array.isArray(src.disabled) ? src.disabled : [];
    const dseen = new Set();
    for (let i = 0; i < ds.length; i++) {
      const w = riskKey(ds[i]);
      if (!w || dseen.has(w)) continue;
      dseen.add(w);
      out.disabled.push(w);
    }
    const u = String(src.remoteUrl == null ? '' : src.remoteUrl).trim();
    if (/^https?:\/\//i.test(u)) out.remoteUrl = u.slice(0, 300);
    return out;
  }
  function riskKey(v) {
    return normalizeRiskWord(v).toLowerCase();
  }

  /**
   * 面板图片尺寸 / 正文字号的**唯一归一函数**（读路径 `important-note.js` 与设置页共用）。
   * 取数口径两条一致：
   *   · 非数字 / 空 / `null` / `NaN` / `0` / 负值 → 回各自默认值（这些不是"填小了"而是坏值，
   *     面板尺寸是布局承重值，坏值不许把它变成 0 宽）；
   *   · `'320'` 这类字符串数字照收（storage 里躺过字符串，来源是手改 / 导入的旧备份）。
   * **越界（填了超出区间的数）两者刻意不同**，各自锁住本版之前就存在的对外行为：
   *   · `imgSize` 越界 → 夹到边界。此前它**根本没有**越界口径（HTML 的 40/600 只是提示、浏览器
   *     不禁手填、面板侧也不夹 ⇒ 填 9999 就真存 9999），夹紧是把那个洞补上；
   *   · `fontSize` 越界 → 回默认值。这是 2.0.2.2 起就钉在真机 e2e 里的行为
   *     （`_e2e/ui.test.js`「越界值（999 > max 72）要回落到默认 11」），归纳整理不翻这个案。
   * @param {*} value 存储里的原始值
   */
  function normalizeImgSize(value) {
    const n = intOrNaN(value);
    if (!isFinite(n) || n <= 0) return IMG_SIZE_DEFAULT;
    return Math.min(IMG_SIZE_MAX, Math.max(IMG_SIZE_MIN, Math.round(n)));
  }

  /** 见 `normalizeImgSize`（取数口径相同；越界口径不同，理由写在上面那段注释里） */
  function normalizeNoteFontSize(value) {
    const n = intOrNaN(value);
    if (!isFinite(n) || n < NOTE_FONT_MIN || n > NOTE_FONT_MAX) return NOTE_FONT_DEFAULT;
    return Math.round(n);
  }

  /* ============================================================================
   * 【2.0.8.4 需求④】重要笔记面板里的「AI 助手」——接口配置的**唯一归一**
   * ----------------------------------------------------------------------------
   * 用户原话：「重要笔记悬浮窗，新增一个 ai 对话助手模块（兼容悬浮模式和贴边模式，
   *   api 在设置界面配置）」；口径补充：「支持各类 api，默认接入 deepseek 的官网 ai 对话」。
   *
   * 因此这里只认 **OpenAI 兼容的 /chat/completions 协议**（DeepSeek / OpenAI / 硅基流动 /
   * 各类中转都是这一套），并把 DeepSeek 官方作为默认值。`provider` 只当"预设名"用：
   * 换预设会把 baseUrl/model 填成该家的推荐值，用户仍可逐项改（`custom` = 全手填）。
   *
   * **上下文口径（用户 2026-11-03 拍板）**：纯自由对话，不带页面标题/URL/笔记内容 ——
   * 面板发出去的只有用户自己打的那几句话。
   *
   * 归一规则（读路径 = 设置页回显 = 后台请求前校验，三处共用这一个函数）：
   *   · 未知 provider → deepseek；
   *   · baseUrl 去掉尾部斜杠；空 → 该预设的默认地址；
   *   · model 空 → 该预设的默认模型；
   *   · apiKey 去首尾空白（**不验证格式**：各家 key 形状不同，填错由请求错误如实回传）；
   *   · maxTokens 越界夹到 128–4000、坏值回 800。
   * ========================================================================= */
  const AI_PRESET_LIST = [
    { id: 'deepseek', label: 'DeepSeek 官方（默认）', baseUrl: 'https://api.deepseek.com/v1', model: 'deepseek-chat' },
    { id: 'openai', label: 'OpenAI', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
    { id: 'custom', label: '自定义（OpenAI 兼容）', baseUrl: '', model: '' }
  ];
  /* 【2.0.16.4 · 用户 m19483】只保留太极AI 一条通路：
   * 用户原话「只保留太极 AI，其余 AI 接口和调用路径全部移除」。
   *   taiji —— 太极AI 站点接口（后台 fetch，会话回写浏览器 cookie；见 background/taiji.js）
   * 老的两条（web = DeepSeek 网页对话、api = OpenAI 兼容接口）连同 UI、消息、后台函数已整条删除。 */
  const AI_MODES = [
    { id: 'taiji', label: '太极AI 网页通路（免 Key）' }
  ];
  const AI_MODE_DEFAULT = 'taiji';
  const AI_PROVIDERS = AI_PRESET_LIST.map((p) => p.id);
  const AI_MAX_MIN = 128;
  const AI_MAX_MAX = 4000;
  const AI_MAX_DEFAULT = 800;

  function aiPreset(id) {
    const key = AI_PROVIDERS.indexOf(String(id || '')) >= 0 ? String(id) : 'deepseek';
    for (let i = 0; i < AI_PRESET_LIST.length; i++) if (AI_PRESET_LIST[i].id === key) return AI_PRESET_LIST[i];
    return AI_PRESET_LIST[0];
  }

  /* 太极AI 那一段：账号存本机（可留空）、站点地址可手动覆盖、模型是站点自己的 id。
   * **密码不在这里** —— 它只在设置页登录那一次请求里出现，不落 storage、不进导出。 */
  function normalizeAiTaiji(raw) {
    const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    const account = (typeof src.account === 'string') ? src.account.trim().slice(0, 80) : '';
    const base = (typeof src.base === 'string') ? src.base.trim().replace(/\/+$/, '').slice(0, 200) : '';
    const model = (typeof src.model === 'string') ? src.model.trim().slice(0, 120) : '';
    return { account: account, base: base, model: model };
  }

  function normalizeAi(raw) {
    const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    const preset = aiPreset(src.provider);
    const url = (typeof src.baseUrl === 'string') ? src.baseUrl.trim().replace(/\/+$/, '') : '';
    const model = (typeof src.model === 'string') ? src.model.trim() : '';
    const key = (typeof src.apiKey === 'string') ? src.apiKey.trim() : '';
    const n = intOrNaN(src.maxTokens);
    return {
      enabled: src.enabled !== false,
      /* 【2.0.16.4】只剩一条通路：老配置里的 api / web 一律归到 taiji，别让历史值把请求发到已删除的路由。 */
      mode: AI_MODE_DEFAULT,
      provider: preset.id,
      baseUrl: url || preset.baseUrl,
      model: model || preset.model,
      apiKey: key,
      system: (typeof src.system === 'string') ? src.system.trim() : '',
      maxTokens: (isFinite(n) && n > 0) ? Math.min(AI_MAX_MAX, Math.max(AI_MAX_MIN, Math.round(n))) : AI_MAX_DEFAULT,
      taiji: normalizeAiTaiji(src.taiji)
    };
  }


  const Config = {
    /** 默认值 —— 唯一真源（方案 §7.1 定稿形态） */
    defaults: {
      globalEnabled: true,

      keywords: [],
      groups: [],

      /** { type, pattern, matchType:'exact'|'subdomain'|'prefix'|'regex', scope:'domain'|'url' } */
      siteRules: [],
      /** {'example.com': true} 本地即时状态，默认不随导出分享 */
      siteDisabledMap: {},

      /** 仅背景色/文字色 —— 边框圆角已移除（CSS.highlights 不支持） */
      highlightStyle: {
        defaultBgColor: '#ff9500',
        defaultTextColor: '#000000'
      },

      noteCardStyle: {
        bgColor: '#ffffff',
        textColor: '#333333',
        borderColor: '#cccccc',
        borderWidth: '1px',
        borderRadius: '8px',
        shadow: '0 4px 12px rgba(0,0,0,0.15)',
        maxWidth: '320px',
        opacity: '0.96',
        fontSize: '14px'
      },

      importantNote: {
        imgSize: IMG_SIZE_DEFAULT,
        /* 面板正文字号（px）。2026-10-09 用户裁决：默认比上一版再小一号（12 → 11），
         * 并在设置页开放给用户。面板把它写成 CSS 变量 `--kh-note-fs`，
         * `.khin-item-note` 与面板内表格一起跟随。 */
        fontSize: NOTE_FONT_DEFAULT,
        /* 置顶排序（2.0.2.5 需求④，2.0.2.6 需求② 换了取值口径）：命中的卡片按填写顺序固定排在最前，
         * 最多 NOTE_PIN_MAX 个。空串 = 不置顶（行为与旧版逐字节一致）。
         * 值现在是**关键词 id**（设置页下拉框给的），面板按 `meta.pinId`（= 规则 ruleId）匹配；
         * 2.0.2.5 的手写卡片文本照旧生效（`head.sortByPins` 两路都认）。
         * 口径与归一见 `pinOrderKeys`；匹配与排序在 `important-note.js` 的 `head.sortByPins`。 */
        pinOrder: '',
        /* 【2.0.14 需求二】重要笔记按页收纳（置顶页 → 分组页 → 未分组页）。
         * 默认关：关着时渲染路径与旧版一致；开着才建 .khin-ptabs。 */
        pagedTabs: false,
        /* 【2.0.15 · 问题②】同法人校验（开发者 / 核准主体两边查法定代表人）。
         * 默认关：爱企查这条链路经常查不到（未登录 / 验证 / 改版），用户要求改成可选打开；
         * 关着时面板不发起任何查询，也不写「未查明」标记。 */
        entityCheck: false,
        /* 【2.0.16.7 · 用户 m20763】四条联网通道各自能关（默认全开＝与旧版行为一致）：
         * 关掉的通道一个请求都不发；全关时面板写「法人通道都已关闭」。 */
        entityChannels: { sogou: true, aiqicha: true, so360: true, ai: true },
        /* 【2.0.17.3 · 用户 m25410】主标题 / 图标的 AI 深查**固定自动做**，不用手动点。
         * 默认开；每条卡只查一次、结果按「名称 + 图标指纹」缓存 30 天（`Risk.cacheKey`）。
         * 关掉后不自动发请求，卡上只保留本地词库的结论。 */
        riskAuto: true
      },

      /* 【2.0.17.5 · 用户 m26374】风险词库（C 档：内置基线 + 自定义 + 逐词停用）。
       * 内置词表是源码常量（`src/features/risk-audit.js`），这里只存**用户改动**：
       *   custom: [{ w, cat }] 自定义词（cat 见 RISK_CATS）；
       *   disabled: 被停用的内置词（存归一后的写法，判定时同样归一后比对）；
       *   remoteUrl: D 档口子（远端订阅清单地址），本版只存不拉。 */
      riskLexicon: { custom: [], disabled: [], remoteUrl: '' },

      /** 重要笔记面板的**默认宽度**（px；T26 / 用户 2026-10-12：200 → 250）。
       *  单一真源：面板侧把它写成 CSS 变量 `--khin-panel-w`（`panel.render`），面板右下角仍可临时
       *  拖动调整（拖动改的是内联宽度，不改这里）。范围 200–1200、坏值回默认的口径见
       *  `normalizePanelWidth`；设置页数字输入的 min/max 也从这个常量取。 */
      notePanelWidth: PANEL_WIDTH_DEFAULT,

      /** 【2.0.8.13 需求④】界面主题：`auto`（跟随系统，默认）/ `light` / `dark`。
       *  真值只在这里；页面侧由 `src/ui/theme.js` 读它并写 `<html data-kh-theme>`，
       *  样式侧只在 tokens.css 里做令牌覆盖（组件 CSS 不许出现主题分支）。 */
      uiTheme: 'auto',

      /* ---- 【2.0.8.4 需求④】重要笔记面板的「AI 助手」接口配置 ----
       * 默认 DeepSeek 官方（用户口径："默认接入 deepseek 的官网 ai 对话"），但协议是通用的
       * OpenAI 兼容格式，设置页可换成任意兼容服务（含中转）。归一只有 `normalizeAi` 一份。
       * ⚠️ `apiKey` 只存本机 storage，不随导出分享（见 storage 的导出白名单）。 */
      ai: normalizeAi({ provider: 'deepseek' }),

      /* ---- 图片文字识别（OCR）----
       * `defaultMax`：每个锚点最多识别几张图（关键词上可单独覆盖，留空即用这个默认）
       * `crossOriginSites`：{'example.com': true} 允许扩展代为读取该站点的跨域图片。
       *   默认**不开**：跨域读图等于替页面再发一次请求，必须按站点显式授权（决策留档见 changelog）。 */
      /* 【2.0.16.4 · m19385】隐私政策链接正文：读不到时允许开一张**后台标签页**
       * （active:false、读完立刻关、同一时刻最多一张、每轮最多一张）。
       * 默认开：用户 2026-11-23 明确选择「P4-A 自动开后台标签页」；
       * 关掉后退回 2.0.14.6 的 C 档口径（只读你已经打开的那张页，没有就提示手动打开）。 */
      policy: {
        renderTab: true
      },

      imgOcr: {
        defaultMax: 4,
        crossOriginSites: {},
        /** 识别引擎（S2 取代旧的 `quality` 档位）：
         *  `auto`（默认）= 主引擎 PP-OCR，失败按**会话**回落兼容引擎 Tesseract（首次主动告知）；
         *  `ppocr` = 只用主引擎（失败如实报错，不回落 —— 给排障用）；
         *  `tesseract` = 只用兼容引擎。
         * 三档都不含"参数可调"：块高/PSM/边数上限等 10 个引擎参数一律不给用户改（票 #17 D-17.7）。 */
        engine: 'auto'
      },

      /* 【2.0.8.6 需求①】图文合并：一行「抓取字段 → 自定义标题」，可默认收起。
       * 默认开、空表 ⇒ 与没有这个功能时逐字节一致（不产生任何额外行）。 */
      imgMerge: normalizeImgMerge({}),

      /** 一次性迁移标记（S2）：`ocrEngine` = "存量档位已回落成 `engine`，还没告知过用户"。
       *  由 `normalize` 在**发现存量 `imgOcr.quality` 时**置真；设置页提示过一次后写回假。
       *  置真的条件只看"存储里还有没有那个废弃键"，所以**写回时必须把它一起删掉**
       *  （`DEPRECATED_KEYS` 已包含 `imgOcr.quality`，任何 patch 都会顺手清掉它）。 */
      migrated: {
        ocrEngine: false
      },

      matchSettings: {
        defaultCaseSensitive: false,
        defaultWholeWord: false,
        defaultUseRegex: false
      },

      shadowDOMEnabled: true,
      suspendInactiveTab: true,
      /** K78·①「**扫描被折叠起来的长内容**（网站自己做的『展开 / 收起』）」：
       *  作者用 `display:none` 收起、旁边有「展开 / 更多」控件的内容，按用户口径**算页面内容**（与闭合 `<details>` 同类）。
       *  默认**开**；关掉即完全回到旧行为（这类隐藏内容一律不扫）。
       *  放行是**六条同时成立**的启发式（宁可漏判，不许把隐藏菜单又放回来）——见 `scanner.js:customCollapseExpandable`。 */
      scanCollapsedCustom: true,

      /* ---- 翻页清扫（方案 §4.3 / §14 决策留档 D4）---- */
      pageResidualClean: true,
      /** 分页点击捕获：默认关（启发式猜分页误触发率高，病根已由 CSS.highlights 根治） */
      pageCleanClick: false,

      /* ---- 整页重建兜底（方案 §4.2）---- */
      pageRebuildOnChange: true,
      /** 变更处理方式（K58）：
       *  `smart`  —— 先判相关性：与命中/抓取/图片都无关的变动不重建（省资源，默认）；
       *  `always` —— 任何页面变动都整页重建（P1/P2 之前的旧行为，最保守；静默窗口与最小间隔照旧）。
       *  留这个开关的理由：预筛的取舍是"判多只是多算一次、判漏才是事故"，
       *  但用户遇到"页面明明变了却不亮"时，需要一条能**立刻排除预筛嫌疑**的路。 */
      changeHandling: 'smart',
      /** 静默窗口：距最后一次页面变动 ≥ 此值才重建，避开高频动态页竞态 */
      pageRebuildSilentMs: 1000,
      /** 全局重建最小间隔：**四条**信号通道（MutationObserver / URL 变化 / 指纹轮询 / 分页点击捕获）
       *  共用此唯一口径（R14）。这里原写"三条"并漏了 MutationObserver —— 通道清单一处定在
       *  `scheduler.js` 文件头（④ 默认关，但通道存在时同样吃这个限频）。 */
      pageRebuildGapMs: 2000,

      /** 内容指纹采样间隔（R13）—— 仅在无 CSS.highlights 环境或极端翻页兜底时消耗 */
      pageFingerprintIntervalMs: 1000
    },

    /** 「抓取后续字段」开关的唯一归一（读路径与写路径共用；见文件顶部该函数的注释） */
    normalizeFetchEnabled,
    /** 「抓取范围」的枚举与唯一归一（读 / 写 / 消费三处共用；见文件顶部该函数的注释） */
    normalizeFetchScope,
    fetchScopeSpec,
    fetchDirections,
    FETCH_DIRECTIONS,
    FETCH_SCOPE_DEFAULT,
    FETCH_SCOPES,

    /** 面板默认宽度的唯一归一 + 它的边界常量（设置页 / 面板 / 读路径共用一份；见文件顶部） */
    normalizePanelWidth,
    /** 【2.0.17.5 · m26374】风险词库：类别码 + 唯一归一（设置页回显 / 判定侧 `Risk.lexicon` 共用） */
    RISK_CATS,
    RISK_WORD_MAX,
    normalizeRiskLexicon,

    /** 【2.0.8.6 需求①】图文合并的唯一归一（设置页回显 / 读路径消费共用一份） */
    normalizeImgMerge,
    MERGE_TITLE_MAX,
    PANEL_WIDTH_MIN,
    PANEL_WIDTH_MAX,
    PANEL_WIDTH_DEFAULT,

    /** 置顶排序的唯一归一 + 上限常量（设置页 / 面板消费共用一份；见 `importantNote.pinOrder`） */
    normalizePinOrder,
    pinOrderKeys,
    NOTE_PIN_MAX,

    /** 【2.0.16.7 · m20763】法人查询四条通道的开关归一与常量（设置页 / 后台竞速 / 面板共用一份） */
    normalizeEntityChannels,
    ENTITY_CHANNEL_KEYS,
    ENTITY_CHANNEL_DEFAULT,

    /** 重要笔记两个外观数字的唯一归一 + 边界常量（设置页 / 面板 / 读路径共用一份；见文件上部） */
    normalizeImgSize,
    IMG_SIZE_MIN,
    IMG_SIZE_MAX,
    IMG_SIZE_DEFAULT,
    normalizeNoteFontSize,
    NOTE_FONT_MIN,
    NOTE_FONT_MAX,
    NOTE_FONT_DEFAULT,

    /** 【2.0.8.4 需求④ / 2.0.8.5 网页对话】AI 助手的接口配置归一    /** 【2.0.8.4 需求④ / 2.0.8.5 网页对话】AI 助手的接口配置归一 + 预设清单（设置页 / 后台请求共用一份） */
    normalizeAi,
    normalizeAiTaiji,
    aiPreset,
    AI_PRESET_LIST,
    AI_MODES,
    AI_MODE_DEFAULT,
    /* 【2.0.16.4】AI_WEB_ORIGIN 已随网页对话通路一起删除（导出列表也必须一起删，否则加载即 ReferenceError）。 */
    AI_MAX_MIN,
    AI_MAX_MAX,
    AI_MAX_DEFAULT,

    /* 【票 #48】编辑器几何（真值 + 派生），与 `.kh-modal-lg` 的 CSS 由单测对齐。 */
    EDITOR_W,
    EDITOR_WIN_PAD,
    EDITOR_WIN_W,
    EDITOR_WIN_H,

    /**
     * 深度合并：以 defaults 为骨架，用存储值覆盖。
     * 注意区别于"深拷贝 defaults"——数组/对象型存储值**整体替换**而非合并，
     * 否则用户清空 keywords 后会被默认空数组"看似正常"但 groups 残留等隐性错误掩盖。
     */
    merge(stored) {
      const out = {};
      const src = stored || {};
      for (const k of Object.keys(this.defaults)) {
        const dv = this.defaults[k];
        const sv = src[k];
        if (dv !== null && typeof dv === 'object' && !Array.isArray(dv)) {
          out[k] = Object.assign({}, dv, (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) ? sv : {});
        } else {
          out[k] = (sv === undefined) ? dv : sv;
        }
      }
      // 未知键：宽容保留，不丢用户数据
      for (const k of Object.keys(src)) {
        if (!(k in out)) out[k] = src[k];
      }
      return out;
    },

    /** 一次性清洗：丢弃废弃键、修正非法枚举、补齐关键词字段。返回 {config, changed} */
    normalize(raw) {
      const cfg = this.merge(raw);
      const changed = { deprecated: [], invalid: [] };

      // ① 废弃键
      for (const key of DEPRECATED_KEYS) {
        if (key.indexOf('.') >= 0) {
          const [head, tail] = key.split('.');
          if (cfg[head] && typeof cfg[head] === 'object' && tail in cfg[head]) {
            delete cfg[head][tail];
            changed.deprecated.push(key);
          }
        } else if (key in cfg) {
          delete cfg[key];
          changed.deprecated.push(key);
        }
      }

      // ② 站点规则枚举
      if (Array.isArray(cfg.siteRules)) {
        cfg.siteRules = cfg.siteRules.filter(r => r && typeof r.pattern === 'string' && r.pattern.length > 0);
        for (const r of cfg.siteRules) {
          if (!ENUMS['siteRules[].type'].includes(r.type)) { r.type = 'blacklist'; changed.invalid.push('type'); }
          if (!ENUMS['siteRules[].matchType'].includes(r.matchType)) { r.matchType = 'exact'; changed.invalid.push('matchType'); }
          if (r.scope !== undefined && !ENUMS['siteRules[].scope'].includes(r.scope)) { r.scope = 'domain'; changed.invalid.push('scope'); }
        }
      }

      // ②b 变更处理方式（K58）：非法值回退 smart（绝不因为一个坏值让"省资源"或"保守"两头都失效）
      if (!ENUMS['changeHandling'].includes(cfg.changeHandling)) {
        cfg.changeHandling = this.defaults.changeHandling;
        changed.invalid.push('changeHandling');
      }
      // ②c 图片识别引擎（S2）：非法值回退 auto（＝主引擎 + 会话内回落，行为最接近"档位取消前"）
      if (cfg.imgOcr && !ENUMS['imgOcr.engine'].includes(cfg.imgOcr.engine)) {
        cfg.imgOcr.engine = this.defaults.imgOcr.engine;
        changed.invalid.push('imgOcr.engine');
      }
      /* ②d 档位 → 引擎的一次性迁移（S2 / #12 裁决）。**判据是"存储里还有没有 `imgOcr.quality`"**，
       * 不是它的值：`best` 与 `fast` 都落 `auto` —— 换引擎后"更准"由主引擎承担，
       * 不再需要用户去下一个 19MB 的大模型包。
       * 标记**只置真、不自动清**（清是设置页告知过用户之后的写回动作）；否则用户刚点掉提示，
       * 下一次读又把它置真 —— 因为那个废弃键还在存储里躺着（`DEPRECATED_KEYS` 负责在写回时删掉它）。 */
      if (raw && raw.imgOcr && typeof raw.imgOcr === 'object' && 'quality' in raw.imgOcr) {
        if (cfg.migrated.ocrEngine !== true) changed.invalid.push('migrated.ocrEngine');
        cfg.migrated.ocrEngine = true;
      }

      /* ②e 重要笔记面板宽度（T26）：越界夹到边界、坏值回默认 —— 口径只在 `normalizePanelWidth`
       * 一处（消费侧调的是同一个函数）。面板宽度是布局承重值：存储里躺过 `0` / `''` / `'abc'`
       * 这类脏值时，绝不许把面板变成 0 宽。 */
      {
        const pw = normalizePanelWidth(cfg.notePanelWidth);
        if (pw !== cfg.notePanelWidth) { cfg.notePanelWidth = pw; changed.invalid.push('notePanelWidth'); }
      }

      /* ②e1 【2.0.8.13 需求④】界面主题：非法值回 auto（不静默丢用户选择 —— light/dark 都保留） */
      if (!ENUMS['uiTheme'].includes(cfg.uiTheme)) {
        cfg.uiTheme = this.defaults.uiTheme;
        changed.invalid.push('uiTheme');
      }

      /* ②e2a 【2.0.16.4 · m19385】隐私正文是否允许开后台标签页：只认严格的 false/true，
       * 其它值（''、0、'false' 字符串）一律回默认开 —— 这个开关只影响「读不到时多一种兜底」，
       * 坏值把它静默关掉才是更坏的结果。 */
      {
        const p = (cfg.policy && typeof cfg.policy === 'object' && !Array.isArray(cfg.policy)) ? cfg.policy : {};
        const want = (p.renderTab === false) ? false : (p.renderTab === true ? true : this.defaults.policy.renderTab);
        if (!cfg.policy || cfg.policy.renderTab !== want) {
          cfg.policy = Object.assign({}, p, { renderTab: want });
          if (raw && raw.policy && raw.policy.renderTab !== undefined) changed.invalid.push('policy.renderTab');
        }
      }

      /* ②e2b 【2.0.16.7 · m20763】法人通道开关：缺键按开、只有明确的 false 才关；
       * 全关合法（用户主动选「不联网」）。脏值只登记，语义一律以 normalizeEntityChannels 为准。 */
      if (cfg.importantNote) {
        const wantCh = normalizeEntityChannels(cfg.importantNote.entityChannels);
        const nowCh = cfg.importantNote.entityChannels;
        if (!nowCh || typeof nowCh !== 'object' || ENTITY_CHANNEL_KEYS.some((k) => nowCh[k] !== wantCh[k])) {
          cfg.importantNote.entityChannels = wantCh;
          if (nowCh !== undefined) changed.invalid.push('importantNote.entityChannels');
        }
      }

      /* ②e2c 【2.0.17.5 · 用户 m26374】风险词库：只清洗形状，不改语义（自定义词去重、类别非法回 other、
       * 停用词按归一写法收）。判定侧 `Risk.screen` 拿到的就是这份清洗过的数据。 */
      {
        const lx = normalizeRiskLexicon(cfg.riskLexicon);
        if (JSON.stringify(lx) !== JSON.stringify(cfg.riskLexicon || null)) {
          cfg.riskLexicon = lx;
          changed.invalid.push('riskLexicon');
        }
      }

      /* ②e2 【2.0.8.6 需求①】图文合并的读路径归一：坏值回默认、字段去重、标题截断。 */
      {
        const mg = normalizeImgMerge(cfg.imgMerge);
        if (JSON.stringify(mg) !== JSON.stringify(cfg.imgMerge || null)) {
          cfg.imgMerge = mg;
          changed.invalid.push('imgMerge');
        }
      }

      // ③ 关键词字段补齐（不改语义、不翻转）
      if (Array.isArray(cfg.keywords)) {
        cfg.keywords = cfg.keywords.map(k => {
          if (!k || typeof k !== 'object') return null;
          const o = Object.assign({}, k);
          if (o.enabled === undefined) o.enabled = true;
          if (o.caseSensitive === undefined) o.caseSensitive = cfg.matchSettings.defaultCaseSensitive;
          if (o.wholeWord === undefined) o.wholeWord = cfg.matchSettings.defaultWholeWord;
          if (o.useRegex === undefined) o.useRegex = cfg.matchSettings.defaultUseRegex;
          if (o.groupId === undefined) o.groupId = null;
          /* ③b 「抓取后续字段」模块总开关（K71）——**读路径**的脏值归一。
           * 规则与写路径 `storage.newKeyword` **共用同一个函数**（`normalizeFetchEnabled`，
           * 见本文件顶部；两处各写一份就是 R4 实测到的"null 两路判据不一致"）。
           * 这里只管"读"（直接躺在 chrome.storage 里的存量关键词），不改写也不清空 `fetchLabels`
           * —— "内容保留"是用户口径。`changed.invalid` 是既有的变更登记通道（无消费方，零风险）。 */
          {
            const fe = normalizeFetchEnabled(o.fetchEnabled, o.fetchLabels);
            if (fe !== o.fetchEnabled) changed.invalid.push('fetchEnabled');
            o.fetchEnabled = fe;
          }
          /* ③c 「抓取范围」（K74）——**读路径**：缺键/非法值 → `auto`；合法值一律尊重。
           * 与写路径 `storage.newKeyword`、消费侧 `fetch.js` 共用同一个 `normalizeFetchScope`。 */
          {
            const sc = normalizeFetchScope(o.fetchScope);
            if (sc !== o.fetchScope) changed.invalid.push('fetchScope');
            o.fetchScope = sc;
          }

          /* ③a 图片识别（OCR）**前置条件**兜底（用户确认口径）：
           *   图片命中是「抓取后续字段」的一个分支 —— 图片正是从**这些字段的值格**里取的，
           *   所以没配抓取字段就无从取图；而「图片命中关键词」是唯一的匹配口径
           *   （不再回落成规则核心词），留空则没有任何东西可匹配。
           * 两种存量脏配置都**只关开关、不动文本**（`imgOcrKeyword` 原样保留，
           * 用户重新勾选时不必重填）。 */
          if (o.imgOcr) {
            const hasFetch = !!(o.fetchLabels && String(o.fetchLabels).trim());
            /* 【2.0.2.19 需求③】判据有**两条**（静态词 / 动态字段名），填了任意一条就成立。
             * 只认 `imgOcrKeyword` 会把"只用动态判据"的合法配置（用户例子：姓名、截图）静默关掉。 */
            const hasWord = !!((o.imgOcrKeyword && String(o.imgOcrKeyword).trim())
              || (o.imgOcrNeed && String(o.imgOcrNeed).trim()));
            if (!hasFetch || !hasWord) {
              o.imgOcr = false;
              changed.invalid.push('imgOcr');
            }
          }
          return o;
        }).filter(Boolean);
      }

      return { config: cfg, changed };
    },

    /** 从 chrome.storage 读取（宽容）。返回 {config, changed} */
    async load(area) {
      const store = (area || (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local));
      if (!store) return this.normalize({});
      /* 【2.0.15 · P2】只读「已知配置键」，不再 get(null)。
       * 病理：storage.local 里还躺着政策正文缓存（khPolicyCacheV3）、企业信息缓存、
       * OCR 模型/语言包标记等大对象；get(null) 会把它们整包反序列化进**每个标签页**
       * 的 state.config（每个内容脚本启动都调一次 load）。
       * 语义不变：返回的仍是「已知键 + 默认值」，normalize 本来也只认这些键；
       * 用户存量配置全在 defaults 的键里，不会丢。 */
      const raw = await store.get(this.storageKeys());
      return this.normalize(raw || {});
    },

    /** 读配置时要取的顶层键（唯一来源：defaults 的键；热更新过滤器也用这一份）。 */
    storageKeys() {
      if (!this._storageKeys) this._storageKeys = Object.keys(this.defaults || {});
      return this._storageKeys;
    },

    /**
     * 写回时剔除废弃键，避免脏字段循环落盘。
     * B6：`head.tail` 形式**也要真的删掉** —— 原来这里 `continue`（注释写"嵌套键由 normalize 处理"），
     * 可 `normalize` 只作用于**读**：导入一份带 `highlightStyle.defaultBorderColor` 的旧备份时，
     * `patch()` 会把它原样写回存储，"写入时不再落盘"那句只活在注释里（文件顶部第 10 行）。
     * 实现保持两条：**只删存在的键**、**不新建对象**（`out[head]` 不是普通对象就什么都不做）；
     * 命中的嵌套块做一次浅拷贝再删，避免改到调用方传进来的那个对象。
     */
    stripDeprecated(patch) {
      const out = Object.assign({}, patch);
      for (const key of DEPRECATED_KEYS) {
        const dot = key.indexOf('.');
        if (dot < 0) {
          if (key in out) delete out[key];
          continue;
        }
        const head = key.slice(0, dot);
        const tail = key.slice(dot + 1);
        const box = out[head];
        if (!box || typeof box !== 'object' || Array.isArray(box) || !(tail in box)) continue;
        const copy = Object.assign({}, box);
        delete copy[tail];
        out[head] = copy;
      }
      return out;
    },

    /** 供 meta-check #3「死配置扫描」使用：defaults 的扁平键路径清单 */
    keyPaths() {
      const paths = [];
      const walk = (obj, prefix) => {
        for (const k of Object.keys(obj)) {
          const v = obj[k];
          const p = prefix ? prefix + '.' + k : k;
          if (v !== null && typeof v === 'object' && !Array.isArray(v)) walk(v, p);
          else paths.push(p);
        }
      };
      walk(this.defaults, '');
      return paths;
    },

    DEPRECATED_KEYS,
    ENUMS
  };

  KH.Config = Config;
})();