/* ============================================================================
 * src/ui/components/color-field.js · 颜色选择控件（三端共用）
 * ----------------------------------------------------------------------------
 * 语义要点（旧版即有，不得回退）：
 *   · **空值 = 继承**，不是黑色。关键词底色留空时会回退到"分组色 > 全局默认色"
 *     （解析在 core/compiler.js 的 resolveVisual，是唯一一处）。所以这里必须提供
 *     「清除」而不是"必须选一个颜色"，否则用户永远无法表达"继承"。
 *   · 色板只是快捷入口，真正的取色器用原生 `<input type="color">`（无需第三方库）。
 *
 * 色板数据放在 JS 里是刻意的：meta-check #7 管的是"样式文件不得写裸色值"，
 * 而色板是**数据**不是样式。真正的样式一律写 var(--token)。
 *
 * 【三块拼装】弹窗要"色块 + 点开选色"，表格要"胶囊 + 点开选色"：
 *   `panel()`  —— 浮层内容（色板 + 原生取色器 + 清除），唯一一份；
 *   `chip()`   —— 只有色点与文案的胶囊按钮（表格用，**不自带浮层**）；
 *   `create()` —— 弹窗里的完整控件（色块/胶囊 + 浮层）。
 *
 * 【为什么浮层走 `KH.ui.Popover`】它是**单例**：打开新的会自动关掉旧的，
 * 关闭时把 mousedown / keydown / scroll / resize 四个监听一起摘掉。
 * 旧实现每个 ColorField 实例自己 `document.addEventListener('mousedown', …)` 且从不解绑 ——
 * 弹窗每开一次就多两个永久监听；表格一页 50 行 × 2 个颜色 = 100 个，且每次重绘还在累加。
 * 浮层挂在 body 上（不是控件内部），也顺带解决了"弹窗内容区 overflow:auto 会把浮层裁掉"。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));
  const ui = (KH.ui = KH.ui || {});
  const D = () => ui.dom;
  const Pop = () => ui.Popover;

  /** 常用色板（沿用旧版配色习惯：先中性，再语义色） */
  const PALETTE = [
    '#ff9500', '#ffcc00', '#34c759', '#00c7be', '#4a90d9',
    '#5856d6', '#af52de', '#ff2d55', '#e53935', '#8e8e93',
    '#ffd8a8', '#fff3bf', '#d3f9d8', '#c5f6fa', '#d0ebff'
  ];

  const HEX = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

  const norm = (v) => (HEX.test(v || '') ? String(v) : '');

  /**
   * 浮层内容（唯一一份）。`onChange(value)` 在用户选色/清除时回调：
   * 传入合法 hex，或 `''` 表示清除（＝继承）。**是否关闭浮层由调用方决定**。
   */
  function panel(opts) {
    const o = opts || {};
    const h = D().h;
    const allowEmpty = o.allowEmpty !== false;
    const fire = (v) => { if (typeof o.onChange === 'function') o.onChange(norm(v)); };

    const grid = h('div', { class: 'kh-color-grid' }, PALETTE.map((c) =>
      h('button', {
        class: 'kh-color-cell', type: 'button', title: c, 'data-color': c,
        style: 'background:' + c, on: { click: () => fire(c) }
      })
    ));
    const picker = h('input', {
      class: 'kh-color-input', type: 'color',
      value: HEX.test(o.value || '') ? o.value : '#ff9500'
    });
    picker.addEventListener('input', () => fire(picker.value));
    const clearBtn = allowEmpty
      ? h('button', { class: 'kh-color-clear', type: 'button', title: '清除（＝继承分组/全局默认色）', text: '清除' })
      : null;
    if (clearBtn) clearBtn.addEventListener('click', () => fire(''));

    return h('div', { class: 'kh-color-panel' }, [
      grid,
      h('div', { class: 'kh-color-ops' }, [picker, clearBtn])
    ]);
  }

  /**
   * 颜色**胶囊**（`● 底`）—— 只有视觉，不含浮层（表格里点开浮层由调用方接）。
   * @param {object} o { label, dot, on, title, id }
   *   label 胶囊文案；dot 色点显示的颜色（可以是"继承来的有效色"）；
   *   on 是否高亮（＝这个词自己设了颜色，而不是继承来的）
   * @returns {{el: HTMLElement, setValue: (v:string)=>void, setDot: (v:string)=>void}}
   */
  function chip(o) {
    const opt = o || {};
    const h = D().h;
    const el = h('button', {
      class: 'kh-color-swatch kh-fld-chip kh-color-chip',
      type: 'button', id: opt.id || null,
      title: opt.title || opt.label || '选择颜色'
    });
    const dot = h('span', { class: 'kh-color-dot' });
    el.appendChild(dot);
    el.appendChild(h('span', { class: 'kh-fld-chip-t', text: opt.label || '颜色' }));

    function paint(color, on) {
      const c = norm(color);
      dot.style.background = c || '';
      dot.classList.toggle('is-empty', !c);
      el.classList.toggle('is-on', !!on);
    }
    paint(opt.dot, opt.on);

    return {
      el,
      /** 设"自己设的颜色"（同时决定色点与 is-on） */
      setValue: (v) => { const c = norm(v); paint(c, !!c); },
      /** 只改色点（"继承来的有效色"），不动 is-on */
      setDot: (v) => { const c = norm(v); dot.style.background = c || ''; dot.classList.toggle('is-empty', !c); }
    };
  }

  /**
   * 弹窗里的完整控件：色块（或胶囊）+ 点开选色。
   * `id` 挂在**色块按钮**上（labelable）→ 弹窗里的 `<label for="fld-bgColor">` 点一下就能开浮层；
   * 也让"每个可读控件都有 `id=fld-<key>`"这条契约成立（外部按 id 逐字段定位/断言）。
   */
  function create(opts) {
    const o = opts || {};
    const h = D().h;
    const asChip = !!o.chip;
    let value = norm(o.value);

    let swatch;
    let setVisual;
    if (asChip) {
      const c = chip({ label: o.label || o.title || '颜色', id: o.id, dot: value, on: !!value, title: o.title });
      swatch = c.el;
      setVisual = c.setValue;
    } else {
      swatch = h('button', { class: 'kh-color-swatch', type: 'button', id: o.id || null, title: o.title || '选择颜色' });
      setVisual = (v) => {
        swatch.textContent = v || '继承';
        swatch.classList.toggle('is-empty', !v);
        swatch.style.background = v || '';
      };
    }
    const wrap = h('div', { class: 'kh-color-field' + (asChip ? ' kh-color-field-chip' : '') }, [swatch]);

    function set(v) {
      value = norm(v);
      setVisual(value);
      if (typeof o.onChange === 'function') o.onChange(value, wrap);
    }

    let popOpen = false;
    swatch.addEventListener('click', (e) => {
      e.stopPropagation();
      if (popOpen) { Pop().close(); return; }               // 再点一次收起
      popOpen = true;
      Pop().open(swatch, panel({
        value,
        allowEmpty: o.allowEmpty !== false,
        onChange: (v) => set(v)        // 选色后**不自动关**：用户可以连点几个色比较（旧版行为）
      }), () => { popOpen = false; });
    });

    setVisual(value);
    wrap.getValue = () => value;
    wrap.setValue = (v) => { value = norm(v); setVisual(value); };   // silent：不触发 onChange
    return wrap;
  }

  ui.ColorField = { create, chip, panel, PALETTE, HEX };
})();
