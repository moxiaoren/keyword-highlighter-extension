/* ============================================================================
 * src/features/stats.js · 命中统计（⑦Consume 消费者）
 * ----------------------------------------------------------------------------
 * 修的是旧版一个"功能是死的"缺陷：
 *   `lib/storage.js:262 incrementHit()` 定义完整、**全库零调用点** →
 *   弹窗里的「今日命中 ⚡」永远是 0（数据从来没被写过）。见方案 §1.1。
 *
 * 口径（v2 定稿，写清楚以免以后又变成"看着像坏了"）：
 *   · 以**命中**为单位：同一命中（`contentKey` = 规则+节点文本+区间）在同一页面会话内**只计一次**，
 *     所以"内容未变的重复重建"不会把数字刷上去（UN-09 的另一面）。
 *   · 计数键：`stats.keywordHits[ruleId]` 与 `stats.siteHits[hostname]`（沿用旧版字段名，兼容既有数据）。
 *   · 落盘：**防抖 300ms** 合并写入 `chrome.storage.local`，避免高频重建把 storage 写成热点。
 *
 * ✚「今日命中」必须真的是"今天"（策划案 §3.11 / §5.1）：
 *   旧版 `getTodayHits()`（lib/storage.js:270-275）返回的是**历史总量**，弹窗却写着「今日命中」——
 *   名实不符。这里补 `stats.daily[YYYY-MM-DD]` 分日桶：
 *     · 计数时同步累加当日桶；
 *     · 读取「今日命中」= 当日桶合计（没有当日桶时回退 0，**不回退总量**，否则又变成假数字）；
 *     · 只保留最近 `KEEP_DAYS` 天，避免 storage 无限膨胀。
 *
 * 为什么去重表不放在 `Rebuilder.caches`：
 *   那个缓存的语义是"**每次重建前清底**"（rebuild 前的 Clear 会清掉它），
 *   而统计去重恰恰要**跨重建存活**。放进去会让统计每重建一次就重刷一遍数字。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  const FLUSH_DELAY = 300;
  /** 分日桶保留天数（滚动窗口；SW 的 alarms 也会触发一次清理） */
  const KEEP_DAYS = 30;

  function dayKey(d) {
    const t = d || new Date();
    const m = String(t.getMonth() + 1).padStart(2, '0');
    const day = String(t.getDate()).padStart(2, '0');
    return t.getFullYear() + '-' + m + '-' + day;
  }

  const stats = {
    seen: new Set(),          // contentKey → 已计过（跨重建存活）
    keywordHits: {},          // ruleId -> 次数（累计）
    siteHits: {},             // hostname -> 次数（累计）
    daily: {},                // 'YYYY-MM-DD' -> { keywordHits:{}, siteHits:{}, total }
    loaded: false,
    _timer: null,
    _loadedPromise: null,

    dayKey,

    /** 首次使用时把已有统计读进来（合并而非覆盖，避免清掉历史） */
    load() {
      if (this._loadedPromise) return this._loadedPromise;
      this._loadedPromise = new Promise((resolve) => {
        try {
          if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return resolve(false);
          chrome.storage.local.get(['stats'], (r) => {
            const s = (r && r.stats) || {};
            this.keywordHits = Object.assign({}, s.keywordHits || {});
            this.siteHits = Object.assign({}, s.siteHits || {});
            this.daily = Object.assign({}, s.daily || {});
            this.loaded = true;
            resolve(true);
          });
        } catch (err) {
          resolve(false);
        }
      });
      return this._loadedPromise;
    },

    /** 只保留最近 KEEP_DAYS 天（按 key 字典序 = 日期序） */
    pruneDaily() {
      const keys = Object.keys(this.daily).sort();
      if (keys.length <= KEEP_DAYS) return;
      for (const k of keys.slice(0, keys.length - KEEP_DAYS)) delete this.daily[k];
    },

    flush() {
      this._timer = null;
      if (!this.loaded) return;
      this.pruneDaily();
      try {
        chrome.storage.local.set({
          stats: {
            keywordHits: this.keywordHits,
            siteHits: this.siteHits,
            daily: this.daily
          }
        });
      } catch (err) {
        console.warn('[KH] 统计写入失败', err);
      }
    },

    schedule() {
      if (this._timer) return;
      this._timer = setTimeout(() => this.flush(), FLUSH_DELAY);
    },

    /** 记账（同步累加、异步入库） */
    count(hits) {
      const host = location.hostname || '';
      const dk = dayKey();
      let added = 0;
      for (const h of hits || []) {
        if (!h) continue;
        const key = h.contentKey || h.id;
        if (!key || this.seen.has(key)) continue;
        this.seen.add(key);
        const rid = h.ruleId || 'unknown';
        this.keywordHits[rid] = (this.keywordHits[rid] || 0) + 1;
        if (host) this.siteHits[host] = (this.siteHits[host] || 0) + 1;

        // 分日桶（今日命中口径）
        let bucket = this.daily[dk];
        if (!bucket) { bucket = { keywordHits: {}, siteHits: {}, total: 0 }; this.daily[dk] = bucket; }
        bucket.keywordHits[rid] = (bucket.keywordHits[rid] || 0) + 1;
        if (host) bucket.siteHits[host] = (bucket.siteHits[host] || 0) + 1;
        bucket.total = (bucket.total || 0) + 1;

        added++;
      }
      if (added) this.schedule();
      return added;
    },

    /** 「今日命中」= 当日桶合计（**不回退总量**，避免又变成名实不符的假数字） */
    todayTotal() {
      const b = this.daily[dayKey()];
      return b ? (b.total || 0) : 0;
    },

    /** 「关键词数」= 已配置关键词条数（弹窗第二个统计卡） */
    keywordCount(cfg) {
      return ((cfg && cfg.keywords) || []).length;
    },

    reset() {
      this.seen.clear();
      this.keywordHits = {};
      this.siteHits = {};
      this.daily = {};
      this.flush();
    }
  };

  if (KH.features) {
    KH.features.register('stats', {
      async consume(hits) {
        await stats.load();
        stats.count(hits);
      },
      /**
       * 重建前清底**不动**统计（去重表必须跨重建存活）；
       * 只有彻底下线时才取消待写入的定时器，并把剩余增量立刻落盘。
       */
      clear(root, opts) {
        const reason = (opts && opts.reason) || 'rebuild';
        if (reason === 'destroy') {
          if (stats._timer) { clearTimeout(stats._timer); stats._timer = null; }
          stats.flush();
        }
      }
    });
  }

  KH.Stats = stats;
})();
