/* ============================================================================
 * src/core/arbiter.js · ④Resolve —— 重叠命中裁决
 * ----------------------------------------------------------------------------
 * 职责：把 RawHit[] 收敛为**互不重叠**的 ResolvedHit[]，并给出确定性优先级。
 *   · 纯函数式、无 DOM 依赖 → 可在 Node 里单测（tools/tests/specs/unit-arbiter）。
 *   · 裁决规则必须确定：同一输入永远同一输出（否则重建会闪烁）。
 *
 * 优先级（从高到低，**定稿口径见附录A §1.5**）：
 *   1. 长匹配优先（length 大者胜）
 *   2. 显式权重 rule.priority 大者胜（留给未来"命中图片"等能力做显式压级）
 *   3. 更小的关键词标识（kwId / ruleId）胜 —— 即"配置顺序靠前"的词优先
 *   4. 稳定兜底：start 升序 → 先登记者胜（保证同一输入永远同一输出，重建不闪烁）
 *
 * 【与 v2 早前实现的差异（有意修正）】早前把「组合词 kind 权重」放在第一位，
 * 于是"短组合词"会压掉"覆盖它的长普通词"，与附录A §1.5 的定稿口径不符。
 * 组合词的格子级 Range 本来就通常更长，靠"长度优先"已能自然胜出，
 * 不需要额外的 kind 加权 —— 加权反而让点击/聚合取到的命中与规格不一致。
 *
 * 绝不 discard：被覆盖的命中仍保留在 `shadowed` 里，供"仅抓取/统计/聚合"继续使用
 * —— 这是旧版「同一词既高亮又要抓取值」场景不丢数据的保障。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** kind 权重仅作**显式 priority 缺省时的参考**，不参与主排序（保留导出供诊断/测试） */
  const KIND_WEIGHT = {
    'combo-tb': 40,
    'combo-lr': 35,
    'rare': 20,
    'normal': 10
  };

  /** ruleId 通常是 `kw_<base36时间>_<随机>`，同批次生成时前缀相同 —— 直接字典序即可稳定 */
  function rank(a, b) {
    const la = a.end - a.start;
    const lb = b.end - b.start;
    if (la !== lb) return lb - la;                       // ① 长匹配优先

    const pa = a.rule.priority || 0;
    const pb = b.rule.priority || 0;
    if (pa !== pb) return pb - pa;                       // ② 显式权重

    const ra = String(a.rule.ruleId);
    const rb = String(b.rule.ruleId);
    if (ra !== rb) return ra < rb ? -1 : 1;              // ③ 更小的 kwId 胜（配置靠前者优先）

    if (a.start !== b.start) return a.start - b.start;   // ④ 先登记者胜
    return (a.seq || 0) - (b.seq || 0);
  }

  function overlaps(a, b) {
    if (a.node !== b.node) return false;
    return a.start < b.end && b.start < a.end;
  }

  const Arbiter = {
    KIND_WEIGHT,
    rank,
    overlaps,

    /**
     * @param {RawHit[]} raw
     * @returns {{resolved: RawHit[], shadowed: RawHit[]}}
     */
    resolve(raw) {
      // 先登记"输入序"（先登记者胜的兜底依据）—— 同一输入永远同一输出
      const list = (raw || []).slice();
      for (let i = 0; i < list.length; i++) if (list[i] && list[i].seq == null) list[i].seq = i;
      const sorted = list.sort(rank);
      const resolved = [];
      const shadowed = [];
      for (const h of sorted) {
        let conflict = false;
        for (const r of resolved) {
          if (overlaps(h, r)) { conflict = true; break; }
        }
        if (conflict) shadowed.push(h);
        else resolved.push(h);
      }
      return { resolved, shadowed };
    }
  };

  KH.Arbiter = Arbiter;
})();
