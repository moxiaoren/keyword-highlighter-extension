/**
 * background/service-worker.js · 后台（MV3 Service Worker）
 * ----------------------------------------------------------------------------
 * 职责（严格限定，不含任何高亮业务逻辑）：
 *   1. 安装/更新：写默认值、打开欢迎页、启动更新轮询
 *   2. 快捷键：转发成统一消息给当前标签页 / 打开设置页
 *   3. 消息路由：统一走 `KH.MSG` 协议常量，禁止硬编码字符串
 *   4. 图标状态：随 globalEnabled 切换亮/灰图标
 *   5. 定时任务：更新检查（6h）、统计清理（24h）
 *
 * 版本号唯一真源：manifest.json（本文件只读，不定义版本字面量）。
 */
'use strict';

importScripts('../src/core/protocol.js', 'update-checker.js');

const MSG = self.KH.MSG;
const UPDATE_CHECK_INTERVAL_MIN = 360;   // 6 小时
const CLEANUP_STATS_INTERVAL_MIN = 1440; // 24 小时

/** 版本唯一来源：manifest */
function currentVersion() {
  try { return chrome.runtime.getManifest().version || '0.0.0'; } catch (e) { return '0.0.0'; }
}

/* ---------------- 更新通道 ---------------- */

async function checkForUpdates() {
  const info = await self.UpdateChecker.check(currentVersion());
  await chrome.storage.local.set({ khUpdateInfo: info });
  try {
    if (info && info.hasUpdate) {
      await chrome.action.setBadgeBackgroundColor({ color: '#e53935' });
      await chrome.action.setBadgeText({ text: '↑' });
    } else {
      await chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) { /* 图标 API 偶发失败不影响主流程 */ }
  return info;
}

/* ---------------- 图标 ---------------- */

async function updateIcon(globalEnabled) {
  const suffix = globalEnabled ? '' : '-paused';
  const path = {
    16: chrome.runtime.getURL(`icons/icon16${suffix}.png`),
    32: chrome.runtime.getURL(`icons/icon32${suffix}.png`),
    48: chrome.runtime.getURL(`icons/icon48${suffix}.png`),
    128: chrome.runtime.getURL(`icons/icon128${suffix}.png`)
  };
  try { await chrome.action.setIcon({ path }); } catch (e) { console.warn('[KH] 更新图标失败', e); }
}

/* ---------------- 统计分日桶的滚动清理 ---------------- */

/** 与内容脚本 `KH.Stats` 的分日桶口径保持一致（唯一真源在 src/features/stats.js，这里是同一契约的第二执行点） */
const STATS_KEEP_DAYS = 30;

/**
 * 清理 `stats.daily` 的历史桶，只保留最近 STATS_KEEP_DAYS 天。
 *
 * 为什么 SW 与内容脚本都要做：
 *   · 内容脚本只在 flush 时顺带清理，而"某天打开过网页之后再没打开"时它永远不会再跑；
 *   · SW 的 24h alarm 是唯一**不依赖页面**的清理时机（旧版这里是个空壳：
 *     注释写着"按日分桶/30天滚动"，实际什么都没做）。
 */
async function pruneStats() {
  try {
    const { stats } = await chrome.storage.local.get('stats');
    if (!stats || !stats.daily || typeof stats.daily !== 'object') return 0;
    // key 形如 YYYY-MM-DD，字典序即日期序
    const keys = Object.keys(stats.daily).sort();
    if (keys.length <= STATS_KEEP_DAYS) return 0;
    const drop = keys.slice(0, keys.length - STATS_KEEP_DAYS);
    for (const k of drop) delete stats.daily[k];
    await chrome.storage.local.set({ stats });
    return drop.length;
  } catch (err) {
    console.warn('[KH] 统计清理失败', err);
    return 0;
  }
}

/* ---------------- 标签页广播 ---------------- */
async function broadcast(type, payload) {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map(t => chrome.tabs.sendMessage(t.id, Object.assign({ type }, payload || {})).catch(() => {})));
}

/* ---------------- 安装 / 更新 ---------------- */

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install' || details.reason === 'update') {
    await chrome.tabs.create({ url: chrome.runtime.getURL('welcome/welcome.html') });
  }
  await checkForUpdates();
  chrome.alarms.create('checkUpdate', { periodInMinutes: UPDATE_CHECK_INTERVAL_MIN });
  chrome.alarms.create('cleanupStats', { periodInMinutes: CLEANUP_STATS_INTERVAL_MIN });
});

chrome.runtime.onStartup.addListener(() => {
  checkForUpdates();
  chrome.alarms.create('checkUpdate', { periodInMinutes: UPDATE_CHECK_INTERVAL_MIN });
  chrome.alarms.create('cleanupStats', { periodInMinutes: CLEANUP_STATS_INTERVAL_MIN });
});

/* ---------------- 快捷键 ---------------- */

chrome.commands.onCommand.addListener(async (command) => {
  switch (command) {
    case 'toggle-highlight': {
      const { globalEnabled = true } = await chrome.storage.local.get('globalEnabled');
      await chrome.storage.local.set({ globalEnabled: !globalEnabled });
      await updateIcon(!globalEnabled);
      await broadcast(MSG.GLOBAL_CHANGED, { value: !globalEnabled });
      break;
    }
    case 'toggle-site': {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs.length) break;
      await chrome.tabs.sendMessage(tabs[0].id, { type: MSG.SITE_TOGGLE }).catch(() => {});
      break;
    }
    case 'open-settings':
      chrome.runtime.openOptionsPage();
      break;
  }
});

/* ---------------- 消息路由（统一协议） ---------------- */

const HANDLERS = {
  [MSG.STATE_QUERY]: async () => {
    const { globalEnabled = true } = await chrome.storage.local.get('globalEnabled');
    return { ok: true, globalEnabled, version: currentVersion() };
  },

  [MSG.GLOBAL_TOGGLE]: async (msg) => {
    const { globalEnabled = true } = await chrome.storage.local.get('globalEnabled');
    const next = (msg.value === undefined) ? !globalEnabled : !!msg.value;
    await chrome.storage.local.set({ globalEnabled: next });
    await updateIcon(next);
    await broadcast(MSG.GLOBAL_CHANGED, { value: next });
    return { ok: true, globalEnabled: next };
  },

  [MSG.SITE_TOGGLE]: async (msg, sender) => {
    const url = (msg.url || (sender && sender.tab && sender.tab.url) || '');
    let host = '';
    try { host = new URL(url).hostname; } catch (e) { return { ok: false, error: '无法解析主机名' }; }
    if (!host) return { ok: false, error: '无法解析主机名' };

    const { siteDisabledMap = {} } = await chrome.storage.local.get('siteDisabledMap');
    const next = !siteDisabledMap[host];
    if (next) siteDisabledMap[host] = true; else delete siteDisabledMap[host];
    await chrome.storage.local.set({ siteDisabledMap });
    await broadcast(MSG.SITE_CHANGED, { host, disabled: next });
    return { ok: true, host, disabled: next };
  },

  [MSG.UPDATE_CHECK]: async () => ({ ok: true, info: await checkForUpdates() }),

  [MSG.UPDATE_INFO]: async () => {
    const { khUpdateInfo = null } = await chrome.storage.local.get('khUpdateInfo');
    return { ok: true, info: khUpdateInfo };
  }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = msg && HANDLERS[msg.type];
  if (!handler) return false;
  Promise.resolve()
    .then(() => handler(msg, sender))
    .then(sendResponse)
    .catch(err => sendResponse({ ok: false, error: String(err && err.message || err) }));
  return true; // 异步响应
});

/* ---------------- 存储变更 → 图标 ---------------- */

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.globalEnabled) updateIcon(changes.globalEnabled.newValue);
});

/* ---------------- 定时任务 ---------------- */

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkUpdate') checkForUpdates();
  if (alarm.name === 'cleanupStats') pruneStats();   // 分日桶 30 天滚动保留（不依赖页面是否打开过）
});

/* ---------------- 冷启动自检 ---------------- */

(async () => {
  const { globalEnabled = true } = await chrome.storage.local.get('globalEnabled');
  await updateIcon(globalEnabled);
  pruneStats();
  chrome.alarms.create('checkUpdate', { periodInMinutes: UPDATE_CHECK_INTERVAL_MIN });
  chrome.alarms.create('cleanupStats', { periodInMinutes: CLEANUP_STATS_INTERVAL_MIN });
})();
