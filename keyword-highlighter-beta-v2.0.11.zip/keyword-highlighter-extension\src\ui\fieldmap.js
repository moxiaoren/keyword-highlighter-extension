/* ============================================================================
 * src/ui/fieldmap.js · 表单 ⇄ 存储 的**唯一**字段声明 + 往返校验（R12 / UN-08）
 * ----------------------------------------------------------------------------
 * 病根（旧版实测）：同一个字段在四个地方各写一遍 ——
 *   options 编辑弹窗、批量设置、CSV 导入、CSV 导出。
 * 于是出现"弹窗能改、批量改不动""CSV 导出的列和导入的列对不上""新增字段只改了
 * 一处"这类问题。根因不是手滑，而是**没有单一声明**。
 *
 * v2 收敛：`KEYWORD_FIELDS` 是关键词字段的**唯一清单**，每一行同时声明
 *   key（存储键） · label（展示名） · type（控件类型） · form（表单分组） · csv（CSV 列序）
 * 上面四条路径一律遍历这张表：新增一个字段 = 加一行，四端同时生效。
 *
 * 往返校验（R12 / 验收 UN-08）：`roundTrip()` 做「表单 → 存储 → 再读回」的三段比对，
 * 每个字段都必须字节级一致；任何 `toStore` / `toForm` 的不对称都会被它抓出来。
 * 它不是"多余的自测"：CSV 与 JSON 两条导入路径都靠它保证"11 个字段填→存→重读一致，
 * 且交叉无污染"。
 *
 * 铁律：本文件**不定义任何默认值**。字段默认值只从两处来 ——
 *   · `Config.defaults`（全局默认，如默认底色）
 *   · `Config.defaults.matchSettings.*`（新建关键词的匹配开关初值）
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /**
   * 表单分区（弹窗横向紧凑布局用；顺序即渲染顺序）。
   *
   * 【**只有 3 个分区** —— 这是策划案 §5.2.2 的布局铁律，v2 一度漂成 6 个独立卡片】
   * 规格原文：
   *   · 基本信息：关键词输入框、分组选择、备注(Markdown)；**右侧列容纳匹配规则 + 高亮颜色**
   *   · 单元格组合（可折叠）：组合方向、标题关键词(左格)、匹配方式、**抓取后续字段**
   *   · 重要笔记（可折叠）：标记为重要、富文本编辑器、图片尺寸、复用关键词高亮底色
   * 所以「匹配规则」「高亮与分组」不该各成一张卡（它们是"这一个关键词"的属性，
   * 独立成卡只会让弹窗更长、还得多看一眼才知道属于谁），「抓取后续字段」也归在单元格组合里。
   * 用户实测把这个偏离指出来了，这里按规格收回来。
   *
   * `col` = 这一节放在第几列。**为什么显式指定列，而不是让浏览器自动排**：
   *   ① 逐行栅格（旧实现）里一行最高的卡片决定行高，矮卡片下面必留空洞
   *      （实测「匹配规则」112px 挨着「单元格组合」296px，同一行下面空了 184px）；
   *   ② CSS 多列（`column-count`）能消空洞，但**任何卡片高度变化都会重新均衡所有列** ——
   *      拉一下备注框、某节内容变高，整个弹窗就跳一次；
   *   ③ 显式分列后每列是**独立的 flex 竖列**：卡片在列内首尾相接，且某张卡片变高只推它自己那一列。
   */
  /* 【K71 文案清理】`hint` 是**可见**的那一句（一律短句，≤18 字符，否则标题行会折行、
   * 整个弹窗被顶高 —— K70 实测 548→565px）；`hintTitle` 是它的 tooltip，长解释住在这里。
   * 用户点名原则：**模块标题已经写了模块名，正文不得再重复一遍** —— 所以 hint 里不出现
   * 本模块的标题字符串（`_e2e` 有一条按「body 文本不含标题」判定的用例盯着）。 */
  const FORM_SECTIONS = [
    { id: 'basic', title: '基本信息', hint: '关键词 / 匹配 / 备注 / 高亮',
      hintTitle: '这一节是这条关键词的身份：词本身、分组、备注、命中后的高亮颜色', col: 1 },
    { id: 'combo', title: '单元格组合', hint: '左格 + 右格都命中才生效',
      hintTitle: '左格标题 + 右格核心，两格都命中才生效', col: 2 },
    /* 「抓取后续字段」**独立成区**：它早就不只服务组合词了 —— 普通关键词也能抓取，
     * 所以把它塞进「单元格组合」是错的（用户实测指出）。这里与 combo 同列但**是独立卡片**。 */
    { id: 'fetch', title: '抓取后续字段', hint: '命中后把同行的其它字段抓进重要笔记',
      hintTitle: '命中后把同一行里指定的字段抓进重要笔记（普通词也能抓）', col: 2 },
    { id: 'imp', title: '重要笔记', hint: '命中后进左上角面板',
      hintTitle: '重要笔记 / 抓取值 / 图片命中都汇总到页面左上角那个面板', col: 3 }
  ];

  /**
   * 组合方向（comboAxis）决定同一批字段该怎么称呼 —— **唯一一份方向文案表**。
   * 为什么放这里：编辑弹窗要按方向改写「标题关键词(左格)/列关键词(表头)」等标签，
   * 若把这份文案写进 keyword-editor.js 就等于又开了一张字段表（第二次"两处各写一遍"）。
   * 因此：字段清单与方向文案同住 fieldmap.js，弹窗只负责把文案贴到控件上。
   */
  const AXIS_LABELS = {
    lr: {
      cellVerify: '标题关键词(左格)',
      cellVerifyMatchMode: '标题词匹配',
      hint: '左格 + 右格都命中才生效',
      hintTitle: '左格标题 + 右格核心，两格都命中才生效'
    },
    tb: {
      cellVerify: '列关键词(表头)',
      cellVerifyMatchMode: '列词匹配',
      hint: '表头列 + 数据行交叉命中',
      hintTitle: '表头列 + 数据行交叉命中（仅表头生效）'
    }
  };

  /**
   * 【抓取范围（fetchScope）的值 → 界面文案】**唯一一份**界面措辞（K79 口径重梳后）。
   * 取值表（与归一）唯一一份在 `Config.FETCH_SCOPES` / `normalizeFetchScope`；这里只是文案，
   * 且回归网里有一条"两份取值逐字一致"的用例钉着（与 chip.js PARTS ↔ fieldmap 的 label 同手法），
   * 所以不靠"记得改两处"，也不需要在加载期依赖 `KH.Config`。
   *
   * 口径（用户 2026-09-23）：**当前层** = 命中格所在的表；**内层** = 当前层里嵌着的表；
   * **外层** = 当前层的祖先表（命中格是更大表格的内层）。三方向可组合。
   * `auto` 是旧口径的兼容值（**就近优先、只取一层**），保留给存量配置。
   */
  const FETCH_SCOPE_TEXT = [
    ['auto', '自动（就近一层）'],
    ['self', '当前层'],
    ['inner', '内层'],
    ['outer', '外层'],
    ['self+inner', '当前层 + 内层'],
    ['self+outer', '当前层 + 外层'],
    ['inner+outer', '内层 + 外层'],
    ['self+inner+outer', '当前层 + 内层 + 外层']
  ];

  /**
   * 关键词字段唯一清单。
   *   type: text | textarea | labels | bool | int | select | color | richtext
   *   csv :  CSV 18 列中的第几列（1-based；0＝不参与 CSV）—— **表头文案在 storage.js 里另有一份硬编码**，
   *          改这里的 label 不影响 CSV 契约。
   *   sec :  表单分区 id
   *   def :  (cfg) => 初值   ← 只从 Config 派生，禁止字面量
   *   width: 2 = 弹窗里占满整行（默认半行，两个半行字段自动并排）
   *   chip : true = 渲染成**紧凑开关胶囊**而不是"复选框 + 文字"占一行（弹窗空间省一半）
   *
   * 【chip 的文案是单一来源】匹配开关的文案（正则 / Aa / 全词）必须与
   * `src/ui/components/chip.js` 的 `PARTS` **逐字一致** —— 那一份同时供关键词表格的
   * 「核心词匹配 / 标题词匹配」列、悬停 tooltip、批量设置使用。meta-check 有红线校验三者不漂移。
   */
  const KEYWORD_FIELDS = [
    /* ---- 基本信息 ---- */
    /* 关键词与**分组**并排（分组"跟在关键词后面"，与「标题关键词 | 组合方向」同一手法），
     * 两个都是半行 → 自动成一行。 */
    /* 【2.0.2.7 需求①】`cands` = 常态只显胶囊、点末尾的 `+` 才出输入框（2.0.2.6 的交互下沉成控件）。
     * `regexKey` 指**兄弟开关**：只有正则模式下 `|` 才是"或"（普通模式整串转义，写 `A|B` 匹配的是
     * 字面量 `A|B`）—— 所以普通模式整串一个胶囊，勾了「正则」才按 `|` 摊开。 */
    { key: 'text', label: '关键词', type: 'cands', sec: 'basic', csv: 1, required: true, clamp: true, listEdit: true,
      regexKey: 'useRegex',
      def: () => '' },
    { key: 'groupId', label: '分组', type: 'select', sec: 'basic', csv: 3, groupSource: true, def: () => null },
    /* 核心词的三个匹配开关：**紧跟关键词那一行**（与标题词那边同一套胶囊、同一套文案）。
     * 声明顺序 = 胶囊顺序，与 chip.js PARTS 保持一致（正则 → Aa → 全词）。 */
    { key: 'useRegex', label: '正则', type: 'bool', sec: 'basic', csv: 7, chip: true,
      hint: '正则表达式匹配（管道 | 可写多个候选）',
      def: (cfg) => !!(cfg.matchSettings || {}).defaultUseRegex },
    { key: 'caseSensitive', label: 'Aa', type: 'bool', sec: 'basic', csv: 5, chip: true,
      hint: '区分大小写',
      def: (cfg) => !!(cfg.matchSettings || {}).defaultCaseSensitive },
    { key: 'wholeWord', label: '全词', type: 'bool', sec: 'basic', csv: 6, chip: true,
      hint: '整词匹配（两侧不得是字母/数字/下划线）',
      def: (cfg) => !!(cfg.matchSettings || {}).defaultWholeWord },
    /* 高亮颜色：与匹配规则三个胶囊**同一行**（胶囊去掉勾选框后窄了，5 个一行放得下），
     * 两组之间插一条**竖线分隔**（`sepBefore`，用户实测要求）—— 竖线比单纯留白更能说明"这是另一组"。
     * 标签用单字 `底` / `文`（`short`），完整名进 tooltip —— 245px 的容器里，
     * 双字标签 5 个放不下（实测 262px），单字才留得出放分隔线的余量。 */
    { key: 'bgColor', label: '底色', short: '底', type: 'color', sec: 'basic', csv: 8, chip: true, sepBefore: true, def: () => '' },
    { key: 'textColor', label: '文字颜色', short: '文', type: 'color', sec: 'basic', csv: 9, chip: true, def: () => '' },
    /* 【2.0.2.10 票 #55】原来空态把一整段 Markdown 语法当占位文字塞进 4 行框里（66 字）——
     * 输入框里不该出现一页文档。常驻只留一行，完整语法搬进 `hint`（走 `title`，K71 口径 B）。
     * 【票 #56】`grow: true`：卡片被列高拉满后，多出来的高度交给这块可写区（而不是留成死白）。 */
    { key: 'note', label: '备注', type: 'textarea', sec: 'basic', csv: 2, rows: 4, width: 2,
      placeholder: '支持 Markdown（加粗、表格）；多行保留',
      hint: '支持 Markdown：**加粗**、*斜体*、[文字](网址)、|a|b| 表格；多行换行会保留',
      grow: true, def: () => '' },
    /* 启用：`head: true` = 渲染到**分区标题行右侧**，不占正文一行
     * （用户实测："放右上角避免占空间，或者干脆删掉 —— 反正关键词管理的表格处可以改"；
     *  这里选前者：既省空间又保留入口。关键词表格的「状态」列同样可以切换。） */
    { key: 'enabled', label: '启用', type: 'bool', sec: 'basic', csv: 4, chip: true, head: true, def: () => true },

    /* ---- 单元格组合 ---- */
    /* 「启用」（原「启用组合」，K70）：不再走正文的胶囊行，改 `head: true` →
     * 渲染到**本分区标题行右侧**的插槽（与「基本信息」那颗同一形态、同一文案）。
     * 用户实测要求："图中两个胶囊按钮改为参考放在模块右上角，名称统一为启用"。
     * ⚠️ **只改显示文案与挂载位置**：key / csv 列序 / 判定逻辑 / id 一律不动。 */
    { key: 'cellVerifyEnabled', label: '启用', type: 'bool', sec: 'combo', csv: 12, chip: true, head: true, def: () => false },
    /* 同上（`cands`）：标题词也有自己的「正则」开关，切分口径跟着它走。 */
    { key: 'cellVerify', label: '标题关键词(左格)', type: 'cands', sec: 'combo', csv: 13, clamp: true, listEdit: true,
      regexKey: 'cellVerifyUseRegex', def: () => '' },
    { key: 'comboAxis', label: '组合方向', type: 'select', sec: 'combo', csv: 0,
      options: [{ v: 'lr', t: '左右格' }, { v: 'tb', t: '上下格' }], def: () => 'lr' },
    /* 标题词的三个开关：与核心词**同一套胶囊、同一套文案**（含「全词」——
     * 它在标题词这边的实现就是 cellVerifyMatchMode='exact'，表格列里也是这么显示的）。 */
    { key: 'cellVerifyUseRegex', label: '正则', type: 'bool', sec: 'combo', csv: 16, chip: true,
      hint: '标题词按正则匹配', def: () => false },
    { key: 'cellVerifyCaseSensitive', label: 'Aa', type: 'bool', sec: 'combo', csv: 15, chip: true,
      hint: '标题词区分大小写', def: () => false },
    { key: 'cellVerifyMatchMode', label: '全词', type: 'select', sec: 'combo', csv: 14, chip: true,
      hint: '标题词整词精确匹配', onValue: 'exact', offValue: 'include',
      options: [{ v: 'include', t: '包含即可' }, { v: 'exact', t: '整词精确' }], def: () => 'include' },
    /* 取值格（右起视觉列）——**只对左右格（lr）有意义**：
     * 留空 = 历史行为（标签格右侧**相邻、跳过空格子**的那一格）；填了才按表达式取格。
     * 为什么不做成 select：取值可以是一组（`1-3` / `1,3,5`），下拉表达不了。 */
    { key: 'cellOffset', label: '取值格（右起）', type: 'text', sec: 'combo', csv: 0,
      /* C4：原来的 `placeholder: '默认'` 在空值时**恒显**「默认」，是用户点名的冗余 ——
       * 直接删掉这个属性（不是换成别的字）：含义全部收进 `hint` → 容器 tooltip。 */
      hint: '左右格专用：取值格从标签格右边第几格（按视觉列，仅本行内）。'
        + '如 `2` / `1-3` / `1,3,5`（可混写 `1-3,5`）。'
        + '留空＝右侧相邻格（跳过空格子）；显式 `1`＝右边第 1 个视觉列所在的格，两者在有空格子/合并单元格时可能不同。'
        + '超出本行列数＝不命中。',
      def: () => '' },
    /* ---- 抓取后续字段（独立分区：普通词也能抓取，不再只服务组合词）---- */
    /* 【2.0.2.4 需求④】「字段」专用控件（文本框 + 实时胶囊预览 + 后缀图例，
     * 见 `fields.js` 的 `case 'labels'`）。**只换控件形态**：值仍是整串原文，
     * 分隔符/后缀语法/CSV 第 17 列/存储归一全部照旧。
     * 【2.0.2.11 票 #63】控件从 `labels` 换成 `cands`：与「关键词 / 标题词」同一套手感
     * （胶囊 + 浮层输入 + `+`），再加两件抓取字段特有的东西 ——
     *   · `token: true`：每段解析后缀并画徽标（`#图3`、`%4` 一眼看得出，图例也一并带上）；
     *   · `clamp: true`：默认**尺寸不变、单行裁切**，词多了点「展开」占整行（用户口径 m01713：
     *     「宽度高度都默认不变，超出隐藏超出部分，但支持手动展开/收起」）。
     * 存储契约一个字没变（仍是整串原文）。 */
    { key: 'fetchLabels', label: '字段', type: 'cands', sec: 'fetch', csv: 17, width: 2,
      token: true, clamp: true, listEdit: true,
      placeholder: '如：名称｜备注',
      /* C1：模块标题已经叫「抓取后续字段」，正文里的 label 再写一遍就是冗余 → 缩成「字段」。
       * `@表达式` 的语义写准：它是**按标签格所在行**从右数第几格（与组合方向零耦合），
       * 所以措辞里不再拿「取值格（右起）」当参照（那个字段在上下档正好是禁用态，越说越乱）。 */
      hint: '留空＝不抓取。后缀：`#1` 只取右邻一格；`#图` 仅图片；`#3` 最多 3 张图；`#图3` 仅图片且最多 3 张（例「截图#图3」）。'
        /* 2.0.2.5 需求①：一张表里可能好几个字段都带图（包名 logo、图标、截图…），
         * 但只有截图该送去识别。`#0` 就是"这个字段的图别管"——既不识别、也不带进抓取内容。 */
        + '`#0` 该字段**不要图**（不参与图片识别，也不带进抓取内容；例「icon#0」，用于一张表里只有截图该做识别的场景）。'
        + '值格指向：`@表达式` 按**本行**从右数第几格（`2` / `1-3` / `1,3` / `1-3,5`），'
        + '如「应用截图@2」「应用截图@1-3#图」「应用截图#图@2」（修饰与偏移顺序无关，可混写）；'
        + '留空＝右邻格，表达式非法/越界＝回退右邻格。'
        /* 2.0.2.4：`!`/`%` 早就实现了却**一个字提示都没有**（只在更新日志里出现过）——
         * 这里连同新增的 `^` 一起写清；执行顺序固定为 `!` → `^` → `%`。 */
        + '取值修饰（可与上面任意混写）：`!` 去掉该字段所有空白；'
        + '`^锚文本` 只取**锚点之前**的内容（例「名称^[复制]」把复制按钮那截尾巴切掉，前缀长度不用固定）；'
        + '`%N` 只取前 N 个字、`%a-b` 取第 a~b 个字（非法表达式＝保留全文）。'
        + '三者执行顺序固定：`!` → `^` → `%`。',
      def: () => '' },
    /* 「抓取后续字段」模块的**总开关**（K71）：与另三颗胶囊同形态（label/chip/head/type 逐项同形），
     * `csv: 0` = 不进 CSV（存储契约仍是 18 列）。
     * 【K75 · 默认改关】`def` 由 `true` 改成 **`false`**（用户原话："抓取后续字段的启用改为默认关闭"）
     * —— 新建关键词时该模块默认未勾选，与「单元格组合」「重要笔记」一致。
     * ⚠️ **迁移规则一个字没改**：`normalizeFetchEnabled` 仍是"**缺键** ⇒ 按非空 `fetchLabels` 反推
     * （＝true）；键存在 ⇒ 一律尊重" ⇒ **存量配置照旧抓取**（默认值只影响"新建"）。
     * ⚠️ 位置必须**紧跟 `fetchLabels` 之后**：`fieldsOf('fetch')[0]` 仍是那个输入框（既有不变式），
     * 而 `head: true` 的字段渲染进标题行插槽，与正文顺序无关。 */
    { key: 'fetchEnabled', label: '启用', type: 'bool', sec: 'fetch', csv: 0, chip: true, head: true,
      hint: '关闭＝不抓取：本模块字段置灰、已填内容保留', def: () => false },
    /* 「抓取范围」（K74）：**嵌套表格时抓哪一层**。位置必须在 `fetchEnabled` 之后 ——
     * `fieldsOf('fetch')[0]` 仍是那个输入框（K71 的既有不变式）。
     * `csv: 0`（仍是 18 列契约）；未启用抓取模块时由 `syncFetch` 一并禁用。 */
    { key: 'fetchScope', label: '抓取范围', type: 'select', sec: 'fetch', csv: 0, def: () => 'self',
      options: FETCH_SCOPE_TEXT.map((pair) => ({ v: pair[0], t: pair[1] })),
      hint: '嵌套表格时抓哪一层的数据（K79 重梳）：**当前层**＝命中所在的那张表；**内层**＝当前层里嵌着的表；'
        + '**外层**＝包着当前层的表（命中格是更大表格的内层）。可组合，例如「当前层 + 外层」。'
        + '取值时**内层文字不会混进外层的值**；同名标签只有值不同才加「（内层）/（本层）/（外层）」后缀。'
        + '「自动（就近一层）」是旧行为：本层有就用本层、没有才往外找一层。' },

    /* ---- 图片文字识别（图片命中 = 「抓取后续字段」的一个分支）----
     * 【K70 挂载位置】这三个控件原在「单元格组合」里，用户实测要求归到本模块
     * （"识别图片相关内容归到抓取后续字段模块"）：声明顺序落在这里 → 渲染在本分区
     * `抓取后续字段` 输入框**下方**。**只是搬家**：字段名 / 存储键 / 联动 / 保存拦截全不动。
     * 【前置条件（用户确认）】必须配了「抓取后续字段」才允许勾选 —— 图片就是从**这些字段的值格**
     * 里取的（`fetchLabels` 里的 `@表达式` 决定值格指向）；没配抓取字段就无从取图。
     * 勾选后必须填「图片命中关键词」：它是**唯一**的匹配口径（不再回落成规则核心词）。
     * 前置条件由三层共同保证：编辑器禁用（keyword-editor 的 syncFetch）、保存拦截、`Config.normalize` 兜底。
     * 不再限于组合词：普通词命中后同样按"命中所在表里的抓取字段"取图。
     * 上限留空 = 用 `Config.defaults.imgOcr.defaultMax`（默认值不在业务代码里写第二份）。 */
    /* ⚠️ 这三个字段**刻意不用 chip**：它们是「抓取字段」这一类的前置条件说明，不是匹配开关；
     * 渲染成普通勾选行 / 输入行的语义更清楚（核心词与标题词的匹配规则那两排胶囊也必须保持
     * "只有正则/Aa/全词"，真浏览器回归里有一条断言专门盯"同一套说法"）。 */
    /* 【2.0.2.10 票 #57】`sub: 'ocr'` = 这三件在卡片里收进同一个虚线子块（`layout()` 认这个键）；
     * `width: 2` = 它是子块的开关行，独占一行，别跟「抓取范围」挤到同一行右端。 */
    { key: 'imgOcr', label: '识别图片文字', type: 'bool', sec: 'fetch', csv: 0, sub: 'ocr', width: 2,
      /* C6/C8：控件行已经有「识别图片文字」这五个字，tooltip 不再复述它、也不复述模块名
       * （用户点名的原则：模块标题写了模块名，正文不得再写一遍；tooltip 口径保持一致）。
       * 【K75 · 口径补一句】前提是**这条规则真的命中**（用户原话："判断命中了普通词/组合词没有…
       * 如果没有命中，那就不需要考虑图片 ocr 和图片关键词"）—— 图是从"命中那一处配置的字段值格"里取的。 */
      hint: '图片里的字也算命中：识别各字段值格里的图片（需先在上面填好字段；'
        + '且**这条规则真的命中**时才会识别 —— 没命中就不看图片）',
      def: () => false },
    /* 同上（`cands`）。`regexAlways: true`：图片命中词**恒为正则**（`img-ocr.js` 固定
     * `useRegex: true`，没有开关），所以它按 `|` 切分永远是对的。 */
    { key: 'imgOcrKeyword', label: '图片命中关键词', type: 'cands', sec: 'fetch', csv: 0, sub: 'ocr', clamp: true,
      width: 2, regexAlways: true, kvSuffix: true, kvBatch: true, listEdit: true, placeholder: '如：一对一',
      /* 【2.0.4 需求①】词尾 `#表`（或 `#kv`）是**逐词**的入表标记：只有带标记的词，图里
       * 「词+分隔符+值」才会并进重要笔记表格。旧版对**所有词**生效，结果「一对一时间选择范围
       * 11:30.」被拆成 键=一对一时间选择范围 / 值=11:30. 塞进卡片（用户原话）⇒ 收严成点名制。
       * 【2.0.7.2 需求①】`@字段名` 的写法**不再教**（只在词尾认、为存量配置保留）：范围改由上面的
       * 「识别范围」一个控件统管，可写多个字段。`#表` 仍画成徽标，与「抓取字段」框的后缀画法统一。 */
      hint: '按**正则**匹配识别出的图片文字（不区分大小写、不要求整词）。'
        + '如 `一对一` / `A.C`；词里带正则元字符（`C++`）时先按正则、不中再按字面找。'
        + '词尾加 `#表`（如 `供应商#表`）：图里「这个词：值」会并进重要笔记表格；不加就不进。'
        + '只想让这个词管某几个字段的图？在「识别范围」里填那几个字段（不要写在词尾）。',
      def: () => '' },
    /* 【2.0.2.19 需求③】动态判据 —— 填的是**抓取字段名**（不是词）：这些字段抓到的值也要出现在
     * 图上才算命中。用户原话：「配置抓取字段 姓名、截图，若 姓名 抓到的值是 张三 且截图图里也有
     * 张三 则判命中；姓名是张三而图里没有张三则不命中」。与上面那条是**且**关系，留空＝旧行为。 */
    /* 【2.0.3 需求①②】原「还需图上有」改名「图片动态关键词」，控件换成与关键词 / 标题关键词 /
     * 抓取字段 / 图片命中关键词**同一族**（`cands` + `clamp`）：胶囊展示、点 `+` 编辑、点框面进文本态、
     * 词多到看不全才出现「展开」。门禁在 `tests/specs/labels-field.test.js` 的 `CANDS_KEYS`：
     * 五条必须同一份实现、同一组开关 —— 以后改这一族只改一处。
     * `csvSplit`：这一格填的是**抓取字段名**，用户习惯用逗号写多个 ⇒ 逗号与 `|` 都当分隔符。
     * 另外四个候选框**不**吃逗号（关键词里的逗号是正文字符），所以这是显式声明、不是全局改口径。
     * 语义不变：填的是抓取字段名，命中判定时拿**抓到的值**去比识别文本（与上面那条是且关系，留空＝旧行为）。
     * 【2.0.6.1 需求②】`suffixChip`：字段名可带 `!`/`^` 等取值修饰 ⇒ 胶囊按「名字 + 后缀徽标」画，
     * 且不再弹「普通匹配按字面找词…」那句（这句对"填字段名、按值比文本"的框是错位文案）。
     * 【2.0.7.2 需求②】改名「图片动态关键词」→「**图上须有的字段值**」：旧名里带"关键词"三个字，
     * 和上面那个框（填**词**）看着是一类东西，实际这里填的是**抓取字段名**、比的是它抓到的**值**
     * —— 用户对着一排都跟"字段/词"有关的框分不清哪个填词哪个填字段。新名字直接说结论：
     * 图里必须出现这个**字段值**。于是两个框的口径一眼可分：
     *   图片命中关键词（图里要有的**词**）→ 图上须有的字段值（图里要有的**值**）。
     * 【2.0.7.2 需求④】`suffixHide` 摘掉：后缀**现在是真生效的**（`开发者^高价` ⇒ 抓 `a公司 高价值`
     * 得到 `a公司`），所以要像「抓取字段」一样把 `^高价` 画成徽标，让"名字是名字、修饰是修饰"看得见。
     * 【2.0.7.2 需求①】`kvBatch` 保留（2026-11-03 起「批量」并进「修改」弹窗，不再单独挂按钮）：
     * 作用域仍写在词尾 `@字段名`，
     * 本轮修的是那个弹窗**认不出已配字段**（下拉框灰掉、`@` 被当普通词）的 bug —— 见
     * `src/ui/components/fields.js` 的 `knownFields()`。 */
    { key: 'imgOcrNeed', label: '图上须有的字段值', type: 'cands', sec: 'fetch', csv: 0, sub: 'ocr',
      clamp: true, width: 2, csvSplit: true, suffixChip: true, kvBatch: true, listEdit: true,
      placeholder: '如：开发者^高价',
      /* 【2.0.7.1 需求③⑤】命中判定是**或**：这些字段抓到的值里，任一个出现在图上就算命中；命中几个都展示。
       * 【2.0.7.2 需求④】后缀**与「抓取字段」同一套、同一份实现**（`Fetch.extractFor`）：
       * `^锚文本` 取锚点之前的字、`%1-3` 切片、`!` 去空白 —— 想单独给这条判据裁值，就在这格写，
       * 不必回头改抓取字段（那边改了会连带影响笔记里显示的值）。 */
      hint: '填**抓取字段名**（多个用逗号或 `|` 分隔）：这些字段抓到的值里，'
        + '**任意一个**出现在图上就算命中（命中几个都展示）。'
        + '可带取值后缀（`开发者^高价`：先按抓取字段的口径切到 `a公司`，再看图里有没有 `a公司`）——'
        + '后缀写法与「抓取后续字段」完全一致（`^` `%` `!`）。'
        + '比对时忽略空格与换行、不分大小写、不要求整词。留空＝只看上面那个关键词。',
      def: () => '' },
    { key: 'imgOcrMax', label: '张数', type: 'int', sec: 'fetch', csv: 0, sub: 'ocr', inline: true,
      placeholder: '默认',
      /* C5：这是**张数**，原来吃的是 int 分支硬编码的"默认尺寸"提示，写错了对象。
       * T56（用户 2026-10-13）：label 由「每处最多」收成「张数」—— 与 C1/C2 同口径（分区标题与
       * 上一个字段已交代"图片"，正文再写一遍只会把并排的输入框挤到 23px、当前值一个字看不见）。 */
      hint: '每处最多识别几张（留空＝用全局默认张数）', def: () => '' },

    /* ---- 重要笔记 ---- */
    /* K70：「重要」→ 文案改「启用」并 `head: true`（本分区标题行右侧，与另两颗同形态）。
     * 于是正文只剩 `[底色] 尺寸：[__]` 一行（原来三件事挤一行）。 */
    { key: 'important', label: '启用', type: 'bool', sec: 'imp', csv: 10, chip: true, head: true, def: () => false },
    { key: 'impNoteUseHlColor', label: '底色', type: 'bool', sec: 'imp', csv: 0, chip: true,
      /* 【2.0.2.11 票 #64】搬进富文本工具栏，和加粗 / 斜体 / 链接同排（用户口径：「底色 ui 改成和加粗、
       * 插入超链接一样」）。`chip` 保留：万一某处没有富文本工具栏（`layout()` 会退回正文），它仍是胶囊。 */
      tool: true, toolOf: 'importantNote', short: '底',
      hint: '复用关键词高亮底色（重要笔记卡片背景）；关着则用卡片自身的底色',
      def: () => false },
    /* 标签从「图片尺寸(px)」缩到「尺寸」：原标题占 78px，把这个窄容器里的输入框挤得只剩一点点
     * （用户实测："图片大小前面的文本不用这么长，挤压太多输入框位置"）。冒号由 inline 模式的 CSS 补。 */
    { key: 'imgSize', label: '尺寸', type: 'int', sec: 'imp', csv: 0, inline: true,
      /* 【2.0.2.11 票 #64】搬进富文本工具栏：文案带 `▭` 前缀与「字号」那颗 `A` 区分。
       * 【2.0.2.7】范围从 config 的常量取（唯一真源）——**惰性函数**，因为这张表在脚本加载期就构造，
       * 那时 KH.Config 未必已经就位（同文件里 `def: () => ...` 全是闭包，就是这个理由）。
       * 此前这里的 noteFontSize 与分组级那份把 10/20 各抄了一份，改 config 时必然漂移。 */
      tool: true, toolOf: 'importantNote', toolPrefix: '▭',
      min: () => KH.Config.IMG_SIZE_MIN, max: () => KH.Config.IMG_SIZE_MAX, step: 1,
      hint: '图片的显示尺寸（留空＝用全局默认）', def: () => '' },
    /* 2.0.2.2 需求 2：笔记正文字号的**词级覆盖**（留空＝继承「样式」里的全局正文字号）。
     * 与 imgSize 完全同一套手法：渲染时给该卡写内联 `--kh-note-fs`，盖掉宿主级那个值。 */
    { key: 'noteFontSize', label: '字号', type: 'int', sec: 'imp', csv: 0, inline: true,
      tool: true, toolOf: 'importantNote', toolPrefix: 'A',
      min: () => KH.Config.NOTE_FONT_MIN, max: () => KH.Config.NOTE_FONT_MAX, step: 1,
      hint: '笔记正文字号（留空＝用「样式」里的全局字号）', def: () => '' },
    // richtext = 所见即所得（图片/链接/加粗/斜体/表格）；存储仍是干净 Markdown（与旧版一致）
    /* C2：模块标题已经叫「重要笔记」，正文 label 再写一遍就是冗余 → 改「笔记内容」。
     * key / type / csv 列序 / 往返一律不动（纯显示文案）。 */
    /* 【票 #56】`grow: true`：列高把它拉满后，多出来的高度给这块编辑区，不再留成卡内死白。
     * 【2.0.2.11 票 #64】`noLabel: true`：删掉可见的「笔记内容」标题（用户口径：这行文案没用），
     * 字段名改挂编辑器的 `aria-label`（读屏与自动化仍认得出）。底色 / 尺寸 / 字号已进它的工具栏。 */
    { key: 'importantNote', label: '笔记内容', type: 'richtext', sec: 'imp', csv: 11, rows: 4, width: 2, grow: true, noLabel: true, def: () => '' }
  ];

  /** 不属于"用户可编辑字段"但必须原样保留的元数据（往返校验要校验它们不变形） */
  const META_KEYS = ['id', 'createdAt', 'updatedAt', 'kind', 'fetchOnly'];

  const byKey = new Map(KEYWORD_FIELDS.map(f => [f.key, f]));

  /** 按类型强制取值 —— 表单控件给的值五花八门（'true'/'on'/'1'/null），只在这里收口 */
  function coerce(field, v) {
    switch (field.type) {
      case 'bool': return v === true || v === 'true' || v === 'on' || v === 1 || v === '1';
      case 'int': {
        if (v === '' || v == null) return '';
        const n = parseInt(v, 10);
        return isNaN(n) ? '' : n;
      }
      case 'select':
        if (field.options) return field.options.some(o => o.v === v) ? v : field.options[0].v;
        return v == null ? null : v;        // groupId 等动态选项由调用方校验
      default: return v == null ? '' : String(v);
    }
  }

  /** 新建时的初值（全部从 Config 派生） */
  function defaults(cfg) {
    const out = {};
    for (const f of KEYWORD_FIELDS) out[f.key] = coerce(f, f.def(cfg));
    return out;
  }

  /** 表单值 → 存储对象。**唯一**实现：任何写入路径（弹窗/批量/CSV/JSON）都必须经它 */
  function toStore(form, cfg) {
    const base = defaults(cfg || {});
    const merged = Object.assign({}, base, form || {});
    const kw = {};
    for (const f of KEYWORD_FIELDS) kw[f.key] = coerce(f, merged[f.key]);
    // 元数据原样透传（id 等），未知键不进入存储（避免脏字段循环落盘）
    for (const k of META_KEYS) if (form && form[k] !== undefined) kw[k] = form[k];
    // 组合词一致性：没勾选组合就没标题词，避免"勾了又取消"留下半截状态
    if (!kw.cellVerifyEnabled) {
      kw.cellVerify = '';
      kw.cellVerifyMatchMode = 'include';
      kw.cellVerifyCaseSensitive = false;
      kw.cellVerifyUseRegex = false;
    }
    return kw;
  }

  /** 存储对象 → 表单值（同一份清单，保证两侧完全对称） */
  function toForm(kw) {
    const out = {};
    for (const f of KEYWORD_FIELDS) out[f.key] = coerce(f, kw ? kw[f.key] : undefined);
    for (const k of META_KEYS) if (kw && kw[k] !== undefined) out[k] = kw[k];
    return out;
  }

  /**
   * 往返校验：表单 → 存储 → 再读回，逐字段比对。
   * @returns {{ok:boolean, diffs:string[]}}
   */
  function roundTrip(kw, cfg) {
    const diffs = [];
    const stored = toStore(toForm(kw), cfg);
    const back = toForm(stored);
    for (const f of KEYWORD_FIELDS) {
      const a = coerce(f, kw ? kw[f.key] : undefined);
      const b = back[f.key];
      if (a !== b) diffs.push(f.key + ': ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b));
    }
    // 交叉污染检查：不该出现的键不得被写进存储
    const allowed = new Set(KEYWORD_FIELDS.map(f => f.key).concat(META_KEYS));
    for (const k of Object.keys(stored)) if (!allowed.has(k)) diffs.push('出现越界键: ' + k);
    return { ok: diffs.length === 0, diffs };
  }

  /** 供 CSV 列序使用：列号 → 字段（CSV 契约与字段声明同源，不另写一份表头映射） */
  function csvColumns() {
    const cols = new Array(KH.Store.CSV_HEADERS.length).fill(null);
    for (const f of KEYWORD_FIELDS) if (f.csv > 0) cols[f.csv - 1] = f;
    return cols;
  }

  /**
   * 【分组字段清单】分组编辑弹窗的字段声明。
   * 与 `KEYWORD_FIELDS` 同一份风格，交给**同一个** `ui.Fields.create` 渲染 ——
   * 这样"分组弹窗的控件形态"不需要单独维护：关键词那边改成胶囊，这边自动也是胶囊。
   * 文案沿用关键词弹窗的口径（底/文/重要/底色/尺寸），完整含义进 tooltip。
   * id 前缀用 `fld-g-`：分组与关键词有 6 个同名字段键（bgColor/textColor/important/…），
   * 用同一前缀会让"按 id 定位"在弹窗堆叠时产生歧义。
   */
  const GROUP_FIELDS = [
    { key: 'name', label: '分组名称', type: 'text', required: true, width: 2, placeholder: '分组名称' },
    { key: 'bgColor', label: '底色', short: '底', type: 'color', chip: true,
      hint: '统一背景色：组内关键词未单独设色时使用' },
    { key: 'textColor', label: '文字颜色', short: '文', type: 'color', chip: true,
      hint: '统一文字色：组内关键词未单独设色时使用' },
    /* 竖线分隔：上面两个是"统一配色"，下面两个是"行为开关"，与关键词弹窗同一手法 */
    { key: 'important', label: '重要', type: 'bool', chip: true, sepBefore: true,
      hint: '整组标记为「重要」：组内命中都进重要笔记面板' },
    { key: 'impNoteUseHlColor', label: '底色', type: 'bool', chip: true,
      tool: true, toolOf: 'importantNote', short: '底',
      hint: '复用高亮底色（组内关键词的笔记卡片背景）；关着则用卡片自身的底色' },
    { key: 'importantNote', label: '分组重要笔记', type: 'richtext', width: 2, grow: true,
      placeholder: '分组统一的重要笔记（分组标记为重要时生效）；图片、加粗、表格、链接直接在框内显示' },
    { key: 'imgSize', label: '尺寸', type: 'int', inline: true,
      tool: true, toolOf: 'importantNote', toolPrefix: '▭',
      min: () => KH.Config.IMG_SIZE_MIN, max: () => KH.Config.IMG_SIZE_MAX, step: 1 },
    /* 分组级：组内关键词未单独设字号时用它（与上面 imgSize 同一套继承顺序） */
    { key: 'noteFontSize', label: '字号', type: 'int', inline: true,
      tool: true, toolOf: 'importantNote', toolPrefix: 'A',
      min: () => KH.Config.NOTE_FONT_MIN, max: () => KH.Config.NOTE_FONT_MAX, step: 1 }
  ];

  /**
   * 【备注卡片样式字段】与 `GROUP_FIELDS` 同一风格，交给同一个 `ui.Fields.create` 渲染。
   * 三个颜色也统一成**颜色胶囊**（原来用的是旧色块），其余是文本输入。
   * 这些是"全局默认值"，不允许留空（`allowEmpty: false` 由调用方给 —— 颜色胶囊的浮层里没有「清除」）。
   */
  const NOTE_CARD_FIELDS = [
    { key: 'bgColor', label: '底色', short: '底', type: 'color', chip: true, hint: '备注卡片背景色' },
    { key: 'textColor', label: '文字颜色', short: '文', type: 'color', chip: true, hint: '备注卡片文字颜色' },
    { key: 'borderColor', label: '边框颜色', short: '框', type: 'color', chip: true, hint: '备注卡片边框颜色' },
    { key: 'borderWidth', label: '边框宽度', type: 'text', placeholder: '如 1px' },
    { key: 'borderRadius', label: '圆角', type: 'text', placeholder: '如 8px' },
    { key: 'shadow', label: '阴影', type: 'text', width: 2, placeholder: '如 0 4px 12px rgba(0,0,0,.12)' },
    { key: 'maxWidth', label: '最大宽度', type: 'text', placeholder: '如 360px' },
    { key: 'opacity', label: '不透明度', type: 'text', placeholder: '如 1' },
    { key: 'fontSize', label: '字号', type: 'text', placeholder: '如 13px' }
  ];

  /**
   * 【站点规则的两组文案】单一来源 —— 弹窗里的下拉选项与列表里的展示都从这里取。
   * 原先 options.js 里写了一份 `MATCH_TEXT`（精确/含子域名/URL 前缀/正则）给列表用，
   * 又在弹窗里另写了一份（精确/含子域/前缀/正则）—— 同一个下拉两套说法。
   */
  const SITE_SCOPE_TEXT = { domain: '域名', url: '网址' };
  const SITE_MATCH_TEXT = { exact: '精确', subdomain: '含子域名', prefix: 'URL 前缀', regex: '正则' };

  /**
   * 【站点规则字段】交给同一个 `ui.Fields.create` 渲染。
   * 原来这四处是手写的 `.kh-fld`，**没有 id/for**，外部无法按 id 逐字段定位（保存往返也就没法自动断言）。
   */
  const SITE_RULE_FIELDS = [
    { key: 'type', label: '规则类型', type: 'select', width: 2, options: [
      { v: 'blacklist', t: '🚫 黑名单（这些站点不高亮）' },
      { v: 'whitelist', t: '✅ 白名单（只有这些站点高亮）' }
    ] },
    { key: 'scope', label: '匹配对象', type: 'select',
      options: Object.keys(SITE_SCOPE_TEXT).map(k => ({ v: k, t: SITE_SCOPE_TEXT[k] })) },
    { key: 'matchType', label: '匹配方式', type: 'select',
      options: Object.keys(SITE_MATCH_TEXT).map(k => ({ v: k, t: SITE_MATCH_TEXT[k] })) },
    { key: 'pattern', label: '站点 / 网址', type: 'text', required: true, width: 2, placeholder: '如 example.com' }
  ];

  KH.FieldMap = {
    KEYWORD_FIELDS, GROUP_FIELDS, NOTE_CARD_FIELDS, SITE_RULE_FIELDS, FORM_SECTIONS, META_KEYS,
    SITE_SCOPE_TEXT, SITE_MATCH_TEXT,
    byKey: (k) => byKey.get(k) || null,
    fieldsOf: (sec) => KEYWORD_FIELDS.filter(f => f.sec === sec),
    /** 组合方向文案（弹窗按当前方向取用；未知方向一律按默认 lr 处理） */
    axisLabels: (axis) => AXIS_LABELS[axis === 'tb' ? 'tb' : 'lr'],
    coerce, defaults, toStore, toForm, roundTrip, csvColumns
  };
})();
