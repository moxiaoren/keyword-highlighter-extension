/* ============================================================================
 * src/features/important-note.js · 重要笔记面板（⑦Consume 消费者）
 * ----------------------------------------------------------------------------
 * 数据来源（只读注册表，不监听 DOM —— 功能一律通过 ⑦Consume 取数）：
 *   `registry.all()` 里 `meta.important === true` 的命中。
 *
 * 本文件承载四条**用户打磨过很久**的既有语义，重构时必须逐条复现：
 *
 * ① 聚合分卡铁律（附录A §5.7 / 策划案 §3.4）：
 *      先按**内容(note)一致**分卡 —— 内容不一致**绝不**进同一卡；
 *      卡内标签再按「标题 / 关键词」形态聚合：
 *        同标题多值   → `🔖 标题 → a|b`
 *        多标题同值   → `🔖 标题1|标题2 → a`
 *        无标题多词   → `🔖 a|b`
 *        值、标题都不同 → **平铺不交叉**
 *    （旧版 content/important-note.js:253-299 收集 + :438-480 buildTagHtml 的分支。
 *      v2 重构时丢掉了这套语义，退化成"一条命中一张卡 + 标签写死 `标题：x`"。）
 *
 * ② 抓取内容的多行格式（附录A §8）：
 *      · 提取层用**视觉行**（flex 同行合并、真实换行保留、控件剔除）
 *      · 渲染层用**多行表格**（保留 rowspan/colspan、两级分组标题）
 *      · 展示容器一律 `white-space: pre-line`（**不得**用 normal，否则 `\n` 折叠成空格）
 *      算法单源在 `src/features/fetch.js`，本文件只负责插进 DOM。
 *
 * ③ 面板形态（策划案 §5.2.3 / §3.4）：
 *      右上角置顶、可拖动（按头部/FAB）、标题栏 **双击收起为圆形 FAB、再双击展开**、
 *      Shadow DOM 隔离、聚合多条命中、**单条可关闭（本次页面会话）**。
 *
 * ④ 图片：抓取字段里的 `<img>` 以缩略图展示（点击看原图），
 *      尺寸由每词 `imgSize`（分组可统一）覆盖，宽高统一**等比**（不裁剪）。
 *
 * 与旧版的差：旧版靠给命中处**插 span + `data-kh-important*` 属性**把数据带出来
 * （keyword-engine.js:1661-1695），既是数据载体又是 DOM 改造，双违规。
 * v2 数据全在注册表里 —— 页面 DOM 里**零插件节点**（UN-01/02）。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  const HOST_ID = 'kh-important-note-host';

  const STYLE = `
    :host { all: initial; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .khin-wrap {
      position: fixed; z-index: 2147483646;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'PingFang SC', 'Microsoft YaHei', sans-serif;
      user-select: none;
    }
    /* ---------- 收起态：圆形 FAB ---------- */
    .khin-fab {
      width: 48px; height: 48px; border-radius: 50%;
      background: linear-gradient(135deg, #3579c2, #5fb0ee); color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-size: 22px; cursor: move; position: relative;
      box-shadow: 0 4px 14px rgba(74, 144, 217, .4);
      transition: transform .15s ease, box-shadow .15s ease;
    }
    .khin-fab:hover { transform: scale(1.06); }
    .khin-fab-badge {
      position: absolute; top: -4px; right: -4px; min-width: 18px; height: 18px;
      padding: 0 4px; border-radius: 9px; background: #e53935; color: #fff;
      font-size: 12px; font-weight: 600; line-height: 18px; text-align: center;
      border: 2px solid #fff;
    }
    /* ---------- 展开态：面板 ---------- */
    .khin-panel {
      width: 360px; min-width: 220px; max-width: calc(100vw - 32px);
      max-height: calc(100vh - 24px); background: #fff;
      border: 1px solid #e3e8f0; border-radius: 10px;
      box-shadow: 0 8px 28px rgba(0,0,0,.18);
      overflow: hidden; display: flex; flex-direction: column;
      resize: both; animation: khin-in .16s ease-out;
    }
    .khin-wrap[hidden] { display: none !important; }
    @keyframes khin-in { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
    .khin-header {
      display: flex; align-items: center; gap: 8px; padding: 10px 12px;
      background: linear-gradient(180deg, #fff, #eaf1fb);
      border-bottom: 1px solid #eef1f6; cursor: move; flex-shrink: 0;
    }
    .khin-header-icon { font-size: 16px; }
    .khin-header-title { font-size: 14px; font-weight: 600; color: #3579c2; flex: 1; }
    .khin-header-count { font-size: 12px; color: #3579c2; background: #eaf1fb; border-radius: 10px; padding: 1px 8px; }
    .khin-header-btn {
      background: none; border: none; cursor: pointer; font-size: 15px;
      color: #8a8a8a; padding: 2px 4px; border-radius: 4px; line-height: 1;
    }
    .khin-header-btn:hover { color: #333; background: rgba(0,0,0,.05); }
    .khin-body { flex: 1 1 auto; min-height: 0; overflow-y: auto; padding: 6px 0; }
    .khin-body::-webkit-scrollbar { width: 5px; }
    .khin-body::-webkit-scrollbar-thumb { background: #d8d8d8; border-radius: 3px; }
    .khin-body::-webkit-scrollbar-track { background: transparent; }
    .khin-item { padding: 9px 12px; border-bottom: 1px solid #f3f3f3; }
    .khin-item:last-child { border-bottom: none; }
    .khin-item-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 6px; margin-bottom: 5px; }
    .khin-item-tags { display: flex; flex-wrap: wrap; gap: 5px; flex: 1; min-width: 0; }
    .khin-item-kw {
      font-size: 12px; font-weight: 600; color: #3579c2; background: #eaf1fb;
      border-radius: 4px; padding: 1px 7px; max-width: 200px;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex-shrink: 0;
    }
    .khin-item-adj {
      font-size: 12px; font-weight: 600; color: #2e7d32; background: #e8f5e9;
      border-radius: 4px; padding: 1px 7px; max-width: 200px;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex-shrink: 0;
    }
    .khin-item-close {
      background: none; border: none; cursor: pointer; color: #bbb;
      font-size: 13px; padding: 2px 4px; border-radius: 4px; line-height: 1; flex-shrink: 0;
    }
    .khin-item-close:hover { color: #e53935; background: #ffe9e9; }
    /* 内容 / 标签可选中复制；外壳保持 user-select:none 仅避免误选 */
    .khin-item-note, .khin-item-tags, .khin-item-kw, .khin-item-adj, .kh-table {
      user-select: text; -webkit-user-select: text;
    }
    .khin-item-note ::selection, .kh-table ::selection { background: #a6d3ff; color: inherit; }
    /* 重要笔记正文：**必须保留换行**（旧版 v1.8.3 教训；Markdown 渲染会在行间产生 \\n 文本节点） */
    .khin-item-note {
      font-size: 13px; line-height: 1.6; color: #333;
      white-space: pre-line; word-break: break-word; overflow-wrap: break-word;
    }
    .khin-item-note a { color: #1a73e8; text-decoration: none; }
    .khin-item-note a:hover { text-decoration: underline; }
    .khin-item-note b, .khin-item-note strong { font-weight: 600; color: #1f2937; }
    .khin-item-note img, .khin-item-body img {
      max-width: var(--kh-img-size, 70px); max-height: var(--kh-img-size, 70px);
      width: auto; height: auto;          /* 等比缩放，**不裁剪** */
      border-radius: 4px; margin: 4px 8px 4px 0;
      display: inline-block; vertical-align: middle; cursor: pointer;
    }
    .khin-item-note img:hover, .khin-item-body img:hover { opacity: .92; }
    .khin-item-body { margin-top: 4px; }
    .khin-empty { padding: 20px; text-align: center; color: #aaa; font-size: 13px; }
    /* 抓取后续字段渲染的多行表格：**所有**单元格保留换行（v1.8.3） */
    .kh-table { border-collapse: collapse; margin-top: 4px; width: 100%; }
    .kh-table td {
      border: 1px solid #d3dae3; padding: 3px 8px; font-size: 12px; line-height: 1.5;
      background: #fff; text-align: left; vertical-align: middle;
      white-space: pre-line; word-break: break-word;
    }
    /* 抓取表格没有表头行：**只有**字段 label 格上色（它是左列列标题，右侧全是它的内容）。
       绝不能按"首行当表头"着色 —— 那会把「基本信息 / 驳回字段：X / 32位包:」也标成行标题。 */
    .kh-table .kh-table-label {
      background: var(--kh-brand-soft, #eaf1fb); font-weight: 600; color: var(--kh-text, #1f2937);
    }
  `;

  /** 图片协议白名单（与内容脚本 sanitize 同口径：仅 http(s)） */
  const IMG_PROTOCOL_OK = /^https?:\/\//i;

  /** 灯箱允许的图片来源：http(s) 之外还允许 `data:image/*`
   *  —— v1.52 起"抓取到的图片"就可能是内嵌的 data URI（旧版注释写着"data: 内嵌图无需跳转"），
   *  它本身就是原图数据，在灯箱里显示是安全的（`<img src>` 不执行脚本）。 */
  const LIGHTBOX_SRC_OK = /^(https?:\/\/|data:image\/)/i;

  /* =================== 看大图（灯箱） ===================
   * 旧行为是 `window.open(src, '_blank')`（新标签页）——用户实测反馈："查看大图的效果是跳出新的标签页，
   * 或者下载。可以做成当前标签页展示大图么"。现改为**当前页内的灯箱**：
   *   · 单独一个 `[data-kh-ext-ui]` 宿主挂在 body 上（不放在面板的 ShadowRoot 里 ——
   *     否则会被面板的定位/尺寸裁剪，做不到"盖住整个视口"）；
   *   · 图片等比适配视口（`object-fit: contain` + max 92vw/86vh），不放大到失真以上；
   *   · **点任意处 / Esc 关闭**（遮罩点击即关，符合"看图"这类轻交互的预期）；
   *   · 保留一个「在新标签页打开」的兜底入口（需要另存/发给别人时用），并阻止它冒泡触发关闭。
   * 不做缩放/拖拽：内容脚本里自己实现会与页面手势冲突，收益也有限（浏览器原生 Ctrl+滚轮 在灯箱上
   * 仍可缩放整页）。若确实需要，可以后续按"用户明确要求"再加。
   */
  const LIGHTBOX_ID = 'kh-note-lightbox';
  const LIGHTBOX_STYLE = `
    .kh-lb { position: fixed; inset: 0; z-index: 2147483647; background: rgba(0,0,0,.78);
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 10px; cursor: zoom-out; }
    .kh-lb[hidden] { display: none !important; }
    .kh-lb img { max-width: 92vw; max-height: 86vh; width: auto; height: auto;
      border-radius: 6px; box-shadow: 0 12px 40px rgba(0,0,0,.45); background: #fff; }
    .kh-lb-bar { display: flex; align-items: center; gap: 12px; font-size: 12px; color: #e8eef7; }
    .kh-lb-open { height: 26px; padding: 0 10px; border: 1px solid rgba(255,255,255,.5);
      border-radius: 999px; background: transparent; color: #fff; font: inherit; font-size: 12px;
      cursor: pointer; }
    .kh-lb-open:hover { background: rgba(255,255,255,.16); }
  `;

  /** 打开灯箱。返回是否打开成功（协议不允许时不打开） */
  function openLightbox(src, alt) {
    if (!src || !LIGHTBOX_SRC_OK.test(src)) return false;   // javascript: 等不处理
    let host = document.getElementById(LIGHTBOX_ID);
    if (!host) {
      host = document.createElement('div');
      host.id = LIGHTBOX_ID;
      host.setAttribute('data-kh-ext-ui', '1');             // 自身 UI 标记：不参与扫描/悬停命中
      const sr = host.attachShadow({ mode: 'open' });
      sr.innerHTML = '<style>' + LIGHTBOX_STYLE + '</style>' +
        '<div class="kh-lb" hidden>' +
        '<img alt="">' +
        '<div class="kh-lb-bar"><span>点击任意处或按 Esc 关闭</span>' +
        '<button class="kh-lb-open" type="button">在新标签页打开</button></div>' +
        '</div>';
      const box = sr.querySelector('.kh-lb');
      const img = sr.querySelector('img');
      const close = () => { box.hidden = true; img.removeAttribute('src'); };
      box.addEventListener('click', close);                 // 点任意处关闭（含图片本身）
      sr.querySelector('.kh-lb-open').addEventListener('click', (e) => {
        e.stopPropagation();                                // 别顺带把灯箱关了
        const s = img.getAttribute('src');
        if (s) window.open(s, '_blank', 'noopener');
      });
      /* Esc 关闭：只在灯箱真的开着时拦，避免影响页面自身的 Esc 行为 */
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !box.hidden) { e.stopPropagation(); close(); }
      }, true);
      host._close = close;
      document.body.appendChild(host);
    }
    const box = host.shadowRoot.querySelector('.kh-lb');
    const img = host.shadowRoot.querySelector('img');
    img.setAttribute('src', src);
    if (alt) img.setAttribute('alt', alt); else img.removeAttribute('alt');
    box.hidden = false;
    return true;
  }

  /* =================== 取数与聚合 =================== */

  function escText(s) {
    const d = document.createElement('div');
    d.textContent = (s == null ? '' : String(s));
    return d.innerHTML;
  }

  const head = {
    /**
     * 命中 → 卡片标签 HTML（`🔖 … / → …`），逐条对齐旧版 buildTagHtml 的四个分支。
     * entries: [{ kw, adj }]
     */
    tagHtml(entries) {
      const plainVals = new Set();
      const combo = new Map();       // adj -> Set<kw>
      for (const e of entries || []) {
        if (!e || !e.kw) continue;
        if (e.adj) {
          if (!combo.has(e.adj)) combo.set(e.adj, new Set());
          combo.get(e.adj).add(e.kw);
        } else {
          plainVals.add(e.kw);
        }
      }
      const out = [];
      // 无标题普通词：多值聚合 🔖 a|b
      if (plainVals.size) {
        out.push('<span class="khin-item-kw">🔖 ' + Array.from(plainVals).map(escText).join('|') + '</span>');
      }
      const adjs = Array.from(combo.keys());
      if (adjs.length) {
        const valUnion = new Set();
        adjs.forEach(a => combo.get(a).forEach(v => valUnion.add(v)));
        const allSingle = adjs.every(a => combo.get(a).size === 1);
        if (allSingle && valUnion.size === 1) {
          // 多标题同值 → 标题合并，箭头随关键词模块
          const val = Array.from(valUnion)[0];
          out.push('<span class="khin-item-kw">🔖 ' + adjs.map(escText).join('|') + '</span>' +
                   '<span class="khin-item-adj">→ ' + escText(val) + '</span>');
        } else if (allSingle) {
          // 各标题单值但值彼此不同 → 逐条平铺，不交叉
          for (const a of adjs) {
            const only = Array.from(combo.get(a))[0];
            out.push('<span class="khin-item-kw">🔖 ' + escText(a) + '</span>' +
                     '<span class="khin-item-adj">→ ' + escText(only) + '</span>');
          }
        } else {
          // 存在某标题多值 → 按标题分开，同标题多值聚合
          for (const a of adjs) {
            const vals = Array.from(combo.get(a));
            if (!vals.length) continue;
            out.push('<span class="khin-item-kw">🔖 ' + escText(a) + '</span>' +
                     '<span class="khin-item-adj">→ ' + vals.map(escText).join('|') + '</span>');
          }
        }
      }
      return out.join('');
    },

    /**
     * 命中集 → 卡片列表。
     * 两级聚合：先按**内容(note)** 分卡（内容不一致绝不进同一卡），
     * 卡内 entries 去重后交给 tagHtml 做形态聚合。
     * @param {object[]} hits  registry 命中
     * @param {Set<string>} ignored 本次会话被用户关掉的笔记内容
     */
    build(hits, ignored) {
      const rawMap = new Map();     // note\0kw\0adj -> { note, kw, adj, imgSize, bg }
      for (const h of hits || []) {
        if (!h || !h.meta) continue;
        let note = String(h.meta.importantNote || '').trim();
        const fieldsHtml = h.meta.fetchHtml || '';
        // 重要笔记正文 = 用户重要笔记（Markdown）+ 抓取字段的多行表格
        if (fieldsHtml) note = note ? (note + '\n' + fieldsHtml) : fieldsHtml;
        if (!note) continue;                                   // 空内容忽略
        if (ignored && ignored.has(note)) continue;
        const kw = String(h.meta.display || h.meta.text || '').trim();
        if (!kw) continue;
        const adj = String(h.meta.label || '').trim();
        const key = note + '\u0000' + kw + '\u0000' + adj;
        if (rawMap.has(key)) continue;                         // 去重
        rawMap.set(key, {
          note, kw, adj,
          imgSize: h.meta.imgSize || '',
          bg: h.meta.impNoteBg || ''
        });
      }

      const noteMap = new Map();    // note -> { note, imgSize, bg, entrySet }
      rawMap.forEach((r) => {
        let g = noteMap.get(r.note);
        if (!g) { g = { note: r.note, imgSize: r.imgSize, bg: r.bg, entrySet: new Set() }; noteMap.set(r.note, g); }
        if (!g.imgSize && r.imgSize) g.imgSize = r.imgSize;
        if (!g.bg && r.bg) g.bg = r.bg;
        g.entrySet.add(r.kw + '\u0000' + (r.adj || ''));
      });

      const items = [];
      noteMap.forEach((g) => {
        const entries = [];
        g.entrySet.forEach((k) => {
          const i = k.indexOf('\u0000');
          entries.push({ kw: k.slice(0, i), adj: k.slice(i + 1) });
        });
        items.push({ note: g.note, entries, imgSize: g.imgSize || '', bg: g.bg || '' });
      });
      return items;
    },

    /** 内容脏检查：命中集合未变 → 不重建 DOM（避免无关变化导致闪烁/重播入场动画） */
    changed(oldItems, newItems) {
      if ((oldItems || []).length !== (newItems || []).length) return true;
      const key = (it) => (it.note || '') + '\u0001' + (it.bg || '') + '\u0001' + (it.entries || [])
        .map(e => (e.kw || '') + '\u0003' + (e.adj || '')).sort().join('\u0002');
      const oldKeys = new Set((oldItems || []).map(key));
      for (const it of newItems) if (!oldKeys.has(key(it))) return true;
      return false;
    }
  };

  /* =================== 面板 =================== */

  const panel = {
    host: null,
    root: null,          // shadow 内的 .khin-wrap
    panelEl: null,
    bodyEl: null,
    countEl: null,
    minimized: false,
    items: [],
    ignored: new Set(),  // 本次页面会话内已被用户关闭的笔记（按 note 文本）
    pos: { left: 20, top: 20 },
    dragState: null,

    ensure(doc) {
      if (this.host && this.host.isConnected) return this.host;
      const host = doc.createElement('div');
      host.id = HOST_ID;
      // 插件自身 UI 的唯一标记：内容脚本遍历 / 清理 / observer 据此整体跳过
      host.setAttribute('data-kh-ext-ui', '1');
      const shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = '<style>' + STYLE + '</style><div class="khin-wrap" hidden></div>';
      this.root = shadow.querySelector('.khin-wrap');
      doc.body.appendChild(host);
      this.host = host;
      this.setDefaultPosition();
      this.applyPosition();

      /* 点击缩略图 → **当前页灯箱看大图**（用户实测要求；旧行为是新标签页）。
       * data: 内嵌图同样支持（本身就是原图数据），只有非 http(s) 协议才不处理。 */
      this.root.addEventListener('click', (e) => {
        const t = e.target;
        if (t && t.tagName === 'IMG' && t.src) {
          e.preventDefault();
          openLightbox(t.src, t.getAttribute('alt') || '');
        }
      });
      return host;
    },

    /**
     * 默认**左上角**。
     *   · v1.52.0 就是左上角 —— 原实现里写着 `// 默认左上角` + `{ left: gap, top: gap }`；
     *   · v2 重构时按`策划案`三处"页面右上角"（§3.4 概述 / §5 行为 / §9.3 组件说明）改成了右上角，
     *     用户实测后确认**预期是左上角**，已恢复（规格那三处属于过时口径，见 tests/E2E-REPORT.md K26）。
     *   左上角更合理的原因：它是"聚合置顶"的常驻件，左上角在阅读流起点；
     *   右上角既容易和页面自带的右侧栏打架，也容易被浏览器滚动条压住。
     *   ⚠️ 改这里之前先看 meta-check 的"重要笔记面板默认位置"红线 —— 那条是为了防止
     *     "照规格再改回去"而钉的，要改必须先有决定。
     */
    setDefaultPosition() {
      const gap = 20;
      this.pos = { left: gap, top: gap };
    },

    applyPosition() {
      if (!this.root) return;
      const width = this.minimized ? 56 : 360;
      const maxLeft = Math.max(8, window.innerWidth - width - 8);
      const maxTop = Math.max(8, window.innerHeight - 48);
      this.pos.left = Math.max(8, Math.min(this.pos.left, maxLeft));
      this.pos.top = Math.max(8, Math.min(this.pos.top, maxTop));
      this.root.style.left = this.pos.left + 'px';
      this.root.style.top = this.pos.top + 'px';
    },

    startDrag(e) {
      if (e.button === 2) return;                              // 忽略右键
      if (e.target && e.target.tagName === 'BUTTON') return;   // 按钮上不拖
      e.preventDefault();
      const rect = this.root.getBoundingClientRect();
      const state = { startX: e.clientX, startY: e.clientY, startLeft: rect.left, startTop: rect.top };
      this.dragState = state;
      const move = (ev) => {
        if (!this.dragState) return;
        this.pos.left = state.startLeft + (ev.clientX - state.startX);
        this.pos.top = state.startTop + (ev.clientY - state.startY);
        this.applyPosition();
      };
      const up = () => {
        this.dragState = null;
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    },

    /** 渲染（幂等；内容未变则不重建 DOM） */
    render(items, cfg) {
      const doc = document;
      this.ensure(doc);
      const imgSize = (cfg && cfg.importantNote && cfg.importantNote.imgSize) || 70;
      this.host.style.setProperty('--kh-img-size', imgSize + 'px');

      if (!items.length) {
        this.items = items;
        this.hide();
        return;
      }
      const dirty = head.changed(this.items, items);
      this.items = items;
      if (dirty) this.renderContent();
      this.show();
    },

    renderContent() {
      if (!this.root) return;
      const count = this.items.length;

      // 收起态：整块换成圆形 FAB（双击展开 —— 避免拖动位置时误展开）
      if (this.minimized) {
        this.panelEl = null;
        this.bodyEl = null;
        this.countEl = null;
        this.root.innerHTML =
          '<div class="khin-fab" title="重要笔记（' + count + ' 条）">📌' +
          '<span class="khin-fab-badge">' + count + '</span></div>';
        const fab = this.root.querySelector('.khin-fab');
        fab.addEventListener('pointerdown', (e) => this.startDrag(e));
        fab.addEventListener('dblclick', () => {
          this.minimized = false;
          this.renderContent();
          this.applyPosition();
        });
        return;
      }

      // 展开态：外壳只创建一次（避免每次命中变化重播入场动画 → 闪烁）
      if (!this.panelEl) {
        this.root.innerHTML =
          '<div class="khin-panel">' +
            '<div class="khin-header">' +
              '<span class="khin-header-icon">📌</span>' +
              '<span class="khin-header-title">重要笔记</span>' +
              '<span class="khin-header-count">0 条</span>' +
              '<button class="khin-header-btn" data-act="min" title="收起为小按钮">—</button>' +
            '</div>' +
            '<div class="khin-body"></div>' +
          '</div>';
        this.panelEl = this.root.querySelector('.khin-panel');
        this.bodyEl = this.root.querySelector('.khin-body');
        this.countEl = this.root.querySelector('.khin-header-count');

        const header = this.panelEl.querySelector('.khin-header');
        header.addEventListener('pointerdown', (e) => this.startDrag(e));
        // 双击标题栏收起为 FAB（策划案 §5.2.3）
        header.addEventListener('dblclick', () => {
          this.minimized = true;
          this.renderContent();
          this.applyPosition();
        });
        this.panelEl.querySelector('[data-act="min"]').addEventListener('click', (e) => {
          e.stopPropagation();
          this.minimized = true;
          this.renderContent();
          this.applyPosition();
        });
      }

      if (this.countEl) this.countEl.textContent = count + ' 条';
      this.renderItems();
    },

    renderItems() {
      if (!this.bodyEl) return;
      const doc = document;
      this.bodyEl.textContent = '';
      for (const item of this.items) {
        const el = doc.createElement('div');
        el.className = 'khin-item';
        if (item.imgSize) el.style.setProperty('--kh-img-size', item.imgSize + 'px');
        // 「复用高亮底色」：铺该词实际底色（分组色 > 词色 > 全局默认）；空串不铺
        if (/^#[0-9a-fA-F]{3,8}$/.test(item.bg || '')) el.style.background = item.bg;

        const headEl = doc.createElement('div');
        headEl.className = 'khin-item-head';
        const tagsEl = doc.createElement('div');
        tagsEl.className = 'khin-item-tags';
        tagsEl.innerHTML = head.tagHtml(item.entries);
        const closeBtn = doc.createElement('button');
        closeBtn.className = 'khin-item-close';
        closeBtn.title = '本次页面不再显示';
        closeBtn.textContent = '✕';
        closeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.ignored.add(item.note);
          this.refresh();
        });
        headEl.appendChild(tagsEl);
        headEl.appendChild(closeBtn);
        el.appendChild(headEl);

        const noteEl = doc.createElement('div');
        noteEl.className = 'khin-item-note';
        noteEl.appendChild(this.noteFragment(doc, item.note));
        el.appendChild(noteEl);
        this.bodyEl.appendChild(el);
      }
    },

    /**
     * 笔记内容 → DOM 片段。
     * 内容里**混有**两类东西：
     *   · 用户写的 Markdown（`KH.Markdown.toFragment`）
     *   · 抓取字段生成的 `<table class="kh-table kh-table-fetch">` HTML（`KH.Fetch.rowsToTableHtml`）
     * 抓取表格是本插件自己生成的**可信结构**，必须原样插入而不是当 Markdown 文本转义掉；
     * 因此先把表格片段摘出来，其余按 Markdown 渲染，最后按原顺序拼回。
     */
    noteFragment(doc, note) {
      const frag = doc.createDocumentFragment();
      const src = String(note == null ? '' : note);
      // 兼容不带 `kh-table-fetch` 标记的旧串（历史数据 / 已缓存的笔记内容），两种都认
      const re = /<table class="kh-table(?: kh-table-fetch)?">[\s\S]*?<\/table>/g;
      let last = 0;
      let m;
      const pushMd = (text) => {
        if (!text) return;
        frag.appendChild(KH.Markdown.toFragment(text, doc));
      };
      while ((m = re.exec(src)) !== null) {
        pushMd(src.slice(last, m.index));
        const tmp = doc.createElement('div');
        tmp.innerHTML = m[0];          // 本插件自产表格（值已在 Fetch 内转义，图片已走协议白名单）
        while (tmp.firstChild) frag.appendChild(tmp.firstChild);
        last = m.index + m[0].length;
      }
      pushMd(src.slice(last));
      return frag;
    },

    /** 用户关掉某条后重算（不重建注册表） */
    refresh() {
      if (!this.host) return;
      const hits = (KH.registry && typeof KH.registry.all === 'function') ? KH.registry.all() : [];
      const effective = collectEffective(hits);
      this.render(head.build(effective, this.ignored), KH.config);
    },

    /* 显隐写成**幂等**的：重复 show/hide 不再写 attribute（少一次 DOM 变更，
     * 也避免把 hidden 属性翻转成"每次重建都抖一下"） */
    show() { if (this.root && this.root.hidden) this.root.hidden = false; },
    hide() { if (this.root && !this.root.hidden) this.root.hidden = true; },

    /**
     * 重建前清底：**不动显隐**（只保留外壳）。
     *
     * 【为什么不能在这里 hide()】旧实现是 `this.hide()`，于是每个重建周期都
     * `hide()`（⑧Clear，rebuilder 的 feature clear 钩子）→ `show()`（⑦Consume 的 render）。
     * 而 `.khin-wrap[hidden]` 是 `display:none`，它会**取消** `.khin-panel` 的入场动画 `khin-in`
     * （opacity 0→1 / 160ms）；重新显示时动画**从 0 重播** → 面板整体闪一下。
     * 关键在于同一次同步管线里、clear 与 consume 之间**必然发生一次强制样式刷新**
     * （scanner / renderer / fetch 里都有 getComputedStyle / getBoundingClientRect），
     * 浏览器因此真的"看见"了 display:none —— 光看代码只觉得"hide 一下再 show"，
     * 完全不像 bug（真浏览器实测：面板 opacity 掉到 0；把该动画置空后 opacity 全程为 1）。
     *
     * 显隐的唯一决定权在 `render()`：有内容 → show()，无内容 → hide()；
     * 彻底下线走 clear({reason:'destroy'}) → destroy()。这与 note-card 是同一条纪律
     * （重建不碰交互 UI，见 note-card.js 顶部注释）。
     */
    emptyKeepShell() { /* 故意留空：重建期间不隐藏 */ },

    destroy() {
      if (this.host && this.host.parentNode) this.host.parentNode.removeChild(this.host);
      this.host = null;
      this.root = null;
      this.panelEl = null;
      this.bodyEl = null;
      this.countEl = null;
      this.dragState = null;
      this.ignored.clear();
      this.items = [];
    }
  };

  /**
   * 从注册表命中里筛出"内容有效的"重要命中。
   *
   * 抓取内容与**触发判据**都在这里结算一次（唯一出口）：
   *   · 触发判据（策划案 §7.5 坑 15 / 附录A §8）：配了 fetchLabels 的「仅抓取」命中，
   *     必须按标签**确实抓到内容**才算这条记录有效；抓不到 → 不显示、**不回退抓标题右格**。
   *   · 每轮重建都重算（值后到/异步填充后自动补上），不缓存"未命中"结论。
   */
  function collectEffective(hits) {
    const list = (hits || []).filter(h => h && h.meta && h.meta.important);
    const effective = [];
    for (const h of list) {
      try {
        h.meta.fetchHtml = (KH.Fetch && h.textNode)
          ? (KH.Fetch.blockFor(h.textNode, h.meta.fetchLabels) || '')
          : '';
      } catch (err) {
        h.meta.fetchHtml = '';
      }
      // 仅抓取：抓不到内容即视为无内容（旧版 v1.13.6「空值守卫」）
      if (h.meta.fetchOnly && !h.meta.fetchHtml) continue;
      effective.push(h);
    }
    return effective;
  }

  /* =================== 注册为 Feature（⑦Consume 消费者） =================== */

  if (KH.features) {
    KH.features.register('important-note', {
      /** @param {object[]} hits 注册表全量命中 @param {object} cfg 当前配置 */
      consume(hits, cfg) {
        const list = (hits || []).filter(h => h && h.meta && h.meta.important);
        if (!list.length && !panel.host) return;    // 从没出现过：连外壳都不造
        panel.render(head.build(collectEffective(hits), panel.ignored), cfg);
      },

      clear(root, opts) {
        const reason = (opts && opts.reason) || 'rebuild';
        if (reason === 'destroy' || root) panel.destroy();
        /* 切标签页（visibility）：保持原有"收起"语义（隐藏的标签页不绘制，观感无差；
         * 但语义上"暂停即收起"仍是旧口径，不擅自改） */
        else if (reason === 'visibility') panel.hide();
        /* 重建（rebuild）：**绝不动显隐** —— 否则入场动画每次重建都重播 → 闪烁 */
        else panel.emptyKeepShell();
      }
    });
  }

  KH.ImportantNote = { panel, head, collectEffective, IMG_PROTOCOL_OK };
})();
