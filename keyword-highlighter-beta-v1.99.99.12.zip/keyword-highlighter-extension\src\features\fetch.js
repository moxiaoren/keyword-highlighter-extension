/* ============================================================================
 * src/features/fetch.js · 「抓取后续字段」唯一实现（提取 / 视觉行 / 合并块 / 多行表格）
 * ----------------------------------------------------------------------------
 * 为什么单独成一个文件：旧版把这一整块散在 keyword-engine.js 的 10 个私有方法里
 *   `_extractFetched`(705) `_extractFetchedFromTable`(721) `_extractFetchedFromFakeTable`(765)
 *   `_fakeRightValue`(806) `_isInteractive`(900) `_cellText`(964) `_collectRightBlock`(1002)
 *   `_rowsToTableMulti`(1066) `_cellVisualText`(1615) `_fetchNonEmptyPass`(1581) `_imgPlaceholder`(941)
 * 而 v2 重构时**把这一整块丢了**，只留下"取同行右邻单元格的 textContent"一句 —— 于是：
 *   · 多行备注（驳回原因/审核结果描述）换行被折叠、flex 并排被拆行   （附录A §8）
 *   · 标签格 rowspan 合并时，超出合并范围的右侧内容整块抓不到        （策划案 §7.3 坑 8）
 *   · 层级内容（基本信息/测试信息/资质信息 两级分组）退化成两列平铺
 *   · `#1` 简单模式、`|｜,，` 多分隔符、图片占位还原全部失效
 * 本文件把这些算法**原样收拢成单一声明**：所有抓取消费方（重要笔记面板）只调
 * `Fetch.blockFor(hit)` / `Fetch.triggerOk(cell)`，不再各写一套。
 *
 * 与旧版逐条对齐（不得回退）：
 *   ① 触发判据 ≠ 抓取内容：触发 = **直接右邻 td 有内容**（不跳过空格子）；
 *      抓取内容按 fetchLabels；目标为空 → 不显示、**不回退抓标题右格**。   （策划案 §7.5 坑 15）
 *   ② 视觉行提取：flex 同行（top 差 ≤8px）合并成一行、真实 block 换行保留；
 *      按钮/链接等交互控件文本剔除。                                     （附录A §8.2）
 *   ③ 合并块：标签格 rowspan 右侧一路向下抓，直到左侧列出现新标签为止。 （策划案 §7.3 坑 8）
 *   ④ 两级分组标题识别 + 多行表格渲染（保留 rowspan/colspan）。          （v1.6.44 / v1.7.4）
 *   ⑤ 图片：协议白名单（http/https），`data:` 占位图与非法协议丢弃，相对路径转绝对。
 * ========================================================================= */

(function () {
  'use strict';

  const KH = (typeof window !== 'undefined' ? (window.KH = window.KH || {}) : (globalThis.KH = globalThis.KH || {}));

  /** 抓取渲染的两级分组识别的固定标题词（旧版 FETCH_GROUP_TITLES，v1.6.42） */
  const GROUP_TITLES = ['基本信息', '测试信息', '资质信息', '运营备注'];

  /** 图片占位符包裹符（正文仍整体转义，图片单独还原为安全 <img>） */
  const IMG_OPEN = '\u0001KHIMG\u0001';
  const IMG_CLOSE = '\u0001ENDIMG\u0001';

  /** 交互控件标签：命中即剔出正文（「编辑」「查看更多」「收起」等动态控件不抓） */
  const SKIP_TAGS = {
    BUTTON: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1, OPTION: 1, FORM: 1,
    IFRAME: 1, VIDEO: 1, AUDIO: 1, CANVAS: 1, IMG: 1, OBJECT: 1, EMBED: 1, HR: 1
  };
  const INTERACTIVE_ROLES = [
    'button', 'link', 'menuitem', 'menu', 'checkbox', 'radio', 'switch',
    'tab', 'combobox', 'slider', 'dialog', 'toolbar', 'navigation'
  ];

  /**
   * **弱控件信号**：中文后台"操作列"的类名（`opt-col` / `operate` / `caozuo` / `handle` / `cell-ops` …）
   * 与 `style="cursor:pointer"`。
   *
   * 为什么不单独判：这些词太泛，`edit-area` / `opt-desc` 这类**包着真内容的外层容器**也会命中。
   * 所以弱信号还必须**该元素的整段文字由"操作词"拼成**（见 `ACTION_LABELS`）——
   * 操作列的文案无非「编辑 / 删除 / 查看更多」及其组合，
   * 而 `<div class="edit-area">南京市</div>` 的文字是正文，不会被误删。
   * 本项目的既定取向是「宁可多抓、不可丢内容」：认不出的操作词只会**漏判**（多显示一条），
   * 不会把真内容删掉。
   */
  const WEAK_ACTION_CLS = /\b(ops?|opts?|operate|operation|edit|del|delete|remove|modify|handle|caozuo|tool|tools|toolbar|action|actions|link|more|btn|button)\b/i;

  /**
   * 操作词表（**只收"操作"语义、不收可能当值的词**）。
   * 故意**不含**「通过 / 驳回 / 启用 / 停用 / 审核 / 关闭 / 提交 / 保存 / 确定 / 取消」——
   * 这些在审核后台里太常作为**字段值**出现（状态列、审核结果列），
   * 万一被误判成控件就会整条内容丢失。它们若真是按钮，基本都是真 `<button>`（已由标签判据兜住）。
   */
  const ACTION_WORD = '(?:编辑|修改|删除|移除|新增|添加|新建|查看|详情|更多|操作|设置|配置|重置|展开|收起|下载|上传|导入|导出|复制|同步|刷新|处理|指派|分配|撤回|撤销|去处理|查看明细)';
  /** 整段文字 = 若干操作词的拼接（`编辑`、`编辑删除`、`查看更多`、`批量删除`… 中间空白忽略） */
  const ACTION_LABELS = new RegExp('^(?:' + ACTION_WORD + ')+$');
  /** 弱信号允许的最长文字（操作标签都很短；超过一律按内容保留） */
  const WEAK_TEXT_MAX = 16;

  /** 弱信号本身（不含"整段是操作词"守卫） */
  function weakControlSignal(node) {
    const cls = node.className ? String(node.className) : '';
    if (cls && WEAK_ACTION_CLS.test(cls)) return true;
    const style = String((node.getAttribute && node.getAttribute('style')) || '');
    return /cursor\s*:\s*pointer/i.test(style);
  }

  /** 弱信号 + "整段文字都是操作词"守卫（见 `WEAK_ACTION_CLS` 注释） */
  function weakControlElement(node) {
    if (!node.getAttribute) return false;
    if (!weakControlSignal(node)) return false;
    const t = String(node.textContent == null ? '' : node.textContent).replace(/\s+/g, '');
    if (!t || t.length > WEAK_TEXT_MAX) return false;
    return ACTION_LABELS.test(t);
  }

  /**
   * 操作型链接：`href="javascript:..."`（含 `javascript:void(0)`）永远是"点了执行动作"，
   * 不可能是真跳转，因此判为控件。
   * **`href="#"` 故意不算** —— SPA 里用 `#` 占位的正文链接很常见（`<a href="#">应用名</a>`），
   * 把它当控件会把真内容整条丢掉；宁可漏判这一个形态。
   */
  function actionHref(node) {
    const href = String((node.getAttribute && node.getAttribute('href')) || '').trim();
    return /^javascript:/i.test(href);
  }

  /**
   * 是否属于交互控件（旧版 `_isInteractive`，v1.7.9 / v1.13.0 结论 + v2.1.0 加固）。
   * 注意：**纯文字 `<a>` 放行**（组合词核心命中内容常是 `<td><a>南京公司</a></td>`），
   * 只有带显式交互特征（onclick / role=button / 控件 class / 查看更多类中文 / `javascript:` 伪协议）才跳过。
   *
   * 【只服务抓取】本函数只被 `cellText` / `cellVisualText` / `triggerOk` 使用（都在 features/fetch.js 内）；
   * 组合词读的是原生 `textContent`，不受这里影响 —— 所以放宽控件识别**不会**动到高亮/组合词。
   */
  function isInteractive(node) {
    if (!node || node.nodeType !== 1) return false;
    const tag = (node.tagName || '').toUpperCase();
    if (tag === 'BR') return false;
    if (SKIP_TAGS[tag]) return true;
    if (!node.getAttribute) return false;

    const cls = node.className ? String(node.className) : '';
    /** 类名 / 内联 cursor 的判据（`<a>` 与非 `<a>` 共用，避免两边规则漂移） */
    const clsHit = () => {
      if (cls && /\b(btn|button|link|more|toggle|expand|collapse|operation|action)\b/i.test(cls)) return true;
      if (cls && /查看更多|收起|展开|更多|操作/.test(cls)) return true;
      return weakControlElement(node);
    };

    if (tag === 'A') {
      if (node.getAttribute('onclick') || node.getAttribute('onmousedown') || node.getAttribute('onpointerdown')) return true;
      // ⚠️ role 白名单里**不能**有 `link` —— 每个 `<a>` 都是 link，会把正文链接一并误杀
      const aRole = String(node.getAttribute('role') || '').toLowerCase();
      if (aRole === 'button' || aRole === 'menuitem' || aRole === 'checkbox' || aRole === 'switch' || aRole === 'tab') return true;
      if (actionHref(node)) return true;
      return clsHit();
    }

    const role = String(node.getAttribute('role') || '').toLowerCase();
    if (role && INTERACTIVE_ROLES.indexOf(role) >= 0) return true;
    if (node.getAttribute('onclick') || node.getAttribute('onmousedown') || node.getAttribute('onpointerdown')) return true;
    if (node.getAttribute('contenteditable') != null) return true;
    return clsHit();
  }

  /** 沿父链向上查是否有交互祖先（直到 cell / 边界），有则整段文本剔除 */
  function underInteractive(node, stopAt) {
    let p = node && node.parentElement;
    while (p && p !== stopAt) {
      if (isInteractive(p)) return true;
      p = p.parentElement;
    }
    return false;
  }

  /* ---------------------------------------------------------------- 图片 */

  /**
   * `<img>` → 可还原占位符（旧版 `_imgPlaceholder`，v1.50.x）。
   * 协议白名单与 sanitize 一致：仅 http(s)（含 `//` 相对协议、相对路径转绝对）；
   * `data:image/` 视为占位图丢弃；`javascript:` 等非法协议丢弃。
   */
  function imgPlaceholder(img) {
    if (!img) return null;
    let src = (img.getAttribute && img.getAttribute('src')) || '';
    if (!src) return null;
    if (/^data:image\//i.test(src)) return null;
    if (/^[a-z][a-z0-9+.-]*:/i.test(src) && !/^https?:/i.test(src) && !/^\/\//i.test(src)) return null;
    try { src = new URL(src, location.href).href; } catch (err) { /* 保留原样 */ }
    if (!/^https?:\/\//i.test(src)) return null;
    const alt = (img.getAttribute && img.getAttribute('alt')) || '';
    const enc = (s) => encodeURIComponent(s == null ? '' : String(s)).replace(/'/g, '%27');
    return IMG_OPEN + enc(alt) + '|' + enc(src) + IMG_CLOSE;
  }

  /** 占位符 → 安全 `<img>`（在 esc 之后调用：正文保持转义、图片安全插入） */
  function restoreImgs(html) {
    const escA = (s) => String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    return String(html).replace(
      new RegExp('\u0001KHIMG\u0001([^|]*)\\|([^\u0001]*)\u0001ENDIMG\u0001', 'g'),
      (_, a, u) => {
        let alt = '', src = '';
        try { alt = decodeURIComponent(a); src = decodeURIComponent(u); } catch (err) { return ''; }
        if (!/^https?:\/\//i.test(src)) return '';
        return '<img src="' + escA(src) + '" alt="' + escA(alt) + '" loading="lazy">';
      }
    );
  }

  /* ---------------------------------------------------------- 单元格文本 */

  const BLOCK_TAGS = {
    DIV: 1, P: 1, LI: 1, TR: 1, UL: 1, OL: 1, SECTION: 1,
    HEADER: 1, FOOTER: 1, BR: 1, TABLE: 1
  };

  /**
   * 单元格正文提取（旧版 `_cellText`，v1.7.9）。
   *   mergeLines=true  → 简单模式：换行/连续空白压成单空格，同行多子元素合并（「工具 张三 日期」）
   *   mergeLines=false → 整块模式：**保留换行**作多行分隔，仅剔除控件、压缩行内空白、清空行
   * 这是"多行驳回原因不折叠"的底层保证（附录A §8.4）。
   */
  function cellText(el, mergeLines) {
    if (!el) return '';
    const segs = [];
    const walk = (node) => {
      if (node.nodeType === 3) { segs.push(node.textContent || ''); return; }
      if (node.nodeType !== 1) return;
      const tag = (node.tagName || '').toUpperCase();
      if (tag === 'BR') { segs.push('\n'); return; }
      if (tag === 'IMG') { const ph = imgPlaceholder(node); if (ph) segs.push(ph); return; }
      if (isInteractive(node)) return;
      const isBlock = !!BLOCK_TAGS[tag] || /^H[1-6]$/.test(tag);
      if (isBlock && segs.length) segs.push('\n');
      for (let i = 0; i < node.childNodes.length; i++) walk(node.childNodes[i]);
    };
    walk(el);
    const s = segs.join('').replace(/\u00a0/g, ' ');
    if (mergeLines) return s.replace(/[ \t\u3000\r\n]+/g, ' ').trim();
    return s
      .replace(/\u3000/g, ' ')
      .replace(/[ \t]+/g, ' ')
      .replace(/\r?\n+/g, '\n')
      .replace(/\n[ \t]+/g, '\n')
      .replace(/^[\n ]+/, '')
      .replace(/[\n ]+$/, '')
      .trim();
  }

  /**
   * 布局感知提取（旧版 `_cellVisualText`，v1.8.9）—— **视觉行**而非块级切行。
   * 网页常用 flex 把多个 div/span 排在同一行：此时各段 `getBoundingClientRect().top`
   * 接近（≤8px）→ 合为一行；真正换行（不同 top）才分行。
   * 附录A §8.2 明确要求"既要合对 flex 同行、又要保真实换行"，两个方向都要对。
   * 图片按位置并入所在行（纯图单元格也能拿到图片）。
   *
   * 【v1.99.99.10 两处修正（都是用户实测：一格多图被渲染成一列多行）】
   *   ① **按文档顺序**处理文本与图片。旧实现先扫完全部文本节点、再单独扫全部图片，
   *      于是"图在文前 / 图文交替"的单元格里图片被整体挪到末尾 —— 与网页观感不符。
   *      现在一次 TreeWalker（SHOW_TEXT | SHOW_ELEMENT）按文档序处理，顺序即原样。
   *   ② 图片之间按**垂直重叠**判是否同一行（旧实现只比 top 差 ≤8px）。
   *      真实站点的一行缩略图是 `display:inline-block` + `vertical-align:middle`，
   *      高矮不一时 top 差会超过 8px（实测 4 张图 top=139/130/142/134，最大差 12px），
   *      于是 4 张图被判成 4 行 → 面板里变成"一列 4 行单图"。
   *      现在：顶对齐（旧口径）**或**垂直范围重叠 ≥ 较小者的 50% → 同一行。
   */
  function cellVisualText(cell) {
    if (!cell || typeof document === 'undefined' || !document.createRange) return cellText(cell, false);
    const rows = [];

    /** 内容矩形（拿不到就给 null，由调用方回退）。
     *  **元素**（图片）必须用它自己的 `getBoundingClientRect()`：对 `<img>` 这类替换元素，
     *  `Range.selectNodeContents()` 选的是"它的子节点"（没有）→ 得到一个**零高度**的矩形，
     *  于是"垂直重叠"判据永远不成立（实测：4 张一行缩略图仍被拆成 4 行）。 */
    const rectOf = (node) => {
      try {
        if (node.nodeType === 1 && node.getBoundingClientRect) {
          const eb = node.getBoundingClientRect();
          if (eb && (eb.top || eb.height)) return eb;
        }
        const r = document.createRange();
        r.selectNodeContents(node);
        const b = r.getBoundingClientRect();
        if (b && (b.top || b.height)) return b;
      } catch (err) { /* 脱离文档/空节点 → 回退 */ }
      return null;
    };
    /** 同一视觉行：顶对齐（旧口径）或垂直范围明显重叠（同行缩略图高矮不一） */
    const sameLine = (row, top, bottom) => {
      if (!row) return false;
      if (Math.abs(row.top - top) <= 8) return true;
      const minH = Math.min(row.bottom - row.top, bottom - top);
      const overlap = Math.min(row.bottom, bottom) - Math.max(row.top, top);
      return minH > 0 && overlap >= minH * 0.5;
    };
    /** 追加一段（文本或图片）到"最后一个视觉行"，不在同一行就开新行 */
    const addSeg = (top, bottom, part) => {
      const last = rows[rows.length - 1];
      if (sameLine(last, top, bottom)) {
        last.parts.push(part);
        last.top = Math.min(last.top, top);          // 行高向下/向上扩展，后续段仍能并进来
        last.bottom = Math.max(last.bottom, bottom);
        return last;
      }
      const row = { top: top, bottom: bottom, parts: [part] };
      rows.push(row);
      return row;
    };
    const geoOf = (node) => {
      const b = rectOf(node);
      if (!b) { const t = rows.length * 100; return { top: t, bottom: t + 1 }; }
      return { top: Math.round(b.top), bottom: Math.round(b.bottom) };
    };

    const walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, null);
    let n;
    while ((n = walker.nextNode())) {
      if (n.nodeType === 1) {
        if (n.tagName !== 'IMG') continue;                 // 只关心图片；其它元素继续下钻
        const ph = imgPlaceholder(n);
        if (!ph) continue;
        const g = geoOf(n);
        addSeg(g.top, g.bottom, { img: ph });
        continue;
      }
      if (underInteractive(n, cell)) continue;
      const t = (n.nodeValue || '').replace(/[\u00a0\u3000]+/g, ' ').replace(/[ \t]+/g, ' ').trim();
      if (!t) continue;
      const g = geoOf(n);
      addSeg(g.top, g.bottom, { text: t });
    }
    return rows
      .map((r) => r.parts.map((p) => (p.img != null ? p.img : p.text)).join(' ').trim())
      .filter(Boolean)
      .join('\n');
  }

  /* ------------------------------------------------------------ 触发判据 */

  /**
   * 触发判据（旧版 `_fetchNonEmptyPass`，v1.8.6 / v1.13.6 + v2.1.0 加固）：
   *   **直接右邻单元格存在且有正文（含中英数字）** 才算这条记录"有内容"。
   * 关键：**不能用会跳过空格子的 `_findRightCell`** —— 那会把"右格为空"误判成"无右格"
   * （策划案 §7.5 坑 15 明确点名的历史 bug）。
   *
   * 【控件不算内容】判据走 `cellText`，它按 `isInteractive` 剔除 `<button>` / `role=button` /
   * `opt-col|operate|caozuo|edit` 这类操作列、`javascript:` 伪协议操作链接与 `cursor:pointer` 控件，
   * 所以"右格只有一个【编辑】按钮"不会触发抓取；右格是"真内容 + 按钮"时按钮文字也不会混进判断。
   * 右邻格本身是控件（如 `<td class="el-button">`）同样判为空。
   *
   * 【占位串不算内容】剔除控件后剩下的文字还要过 `isPlaceholderText`（**与"下一字段"判据同一口径**）：
   * `-` / `--` / `——` / `~` / `/` 以及 `无` / `暂无` / `N/A` / `null` 都算"没有内容"，
   * 因此 **`-` 加一个按钮** 依然判空（按钮先被剔除，剩下 `-`），不会因为多了个控件就变成"有内容"。
   */
  function triggerOk(cell) {
    if (!cell || !cell.parentElement) return false;
    const nx = cell.nextElementSibling;
    if (nx && /^TD|TH$/i.test(nx.tagName)) {
      if (isInteractive(nx)) return false;                 // 右邻格本身就是控件
      const right = cellText(nx, false) || '';
      if (isPlaceholderText(right)) return false;          // 占位串 = 没有内容
      /* 仅图片也算内容（v1.99.99.12）：右格只有 `<img>`、没有任何文字时同样要显示该条。
       * 不靠"占位符里含 alt/url 字母"这种偶然性质，直接认图片占位符。 */
      if (right.indexOf('\u0001KHIMG\u0001') >= 0) return true;
      return /[\p{L}\p{N}]/u.test(right);
    }
    // 假表格：看右邻兄弟（跨层向上，与 _fakeRightValue 同口径）
    const v = fakeRightValue(cell);
    if (isPlaceholderText(v)) return false;
    return /[\p{L}\p{N}]/u.test(v || '');
  }

  /* -------------------------------------------------------- fetchLabels 解析 */

  /**
   * 解析 fetchLabels（旧版 v1.6.36 / v1.7.8；v1.99.99.12 扩展图片选项）：
   *   · 分隔符 `|` `｜` `,` `，`
   *   · 字段末尾 `#1` = **简单模式**：只取右侧相邻第一个单元格，不做整块多行表格
   *     （如「资质类型#1」）
   *   · 字段末尾 `#图`  = **仅图片**：该字段只保留图片，丢掉文字
   *   · 字段末尾 `#N`（N≥2）= **最多 N 张图**：图片超出部分丢掉，文字照旧
   *   · 可组合：`#图3` = 仅图片 + 最多 3 张
   *     （用户要求"抓取需要支持仅图片、前几张图片的方式"。放在字段名后缀里而不是新配置项，
   *      是为了**每个字段可以不一样**，且与既有的 `#1` 简单模式同一套写法、不必加界面控件。）
   */
  function parseLabels(raw) {
    return String(raw == null ? '' : raw)
      .split(/[|｜,，]/)
      .map(x => x.trim())
      .filter(Boolean)
      .map((t) => {
        /* 后缀：`#图` / `#3` / `#图3` / `#1`（简单模式，历史写法） */
        const m = /^(.*?)#\s*(图|仅图)?\s*(\d+)?\s*$/.exec(t);
        if (m) {
          const label = m[1].replace(/^[ \u3000]+|[ \u3000]+$/g, '');
          const imgOnly = !!m[2];
          const num = m[3] ? parseInt(m[3], 10) : 0;
          /* `#1`（且没写"图"）= 历史语义：简单模式；`#图1` 才是"仅图片且最多 1 张" */
          if (!imgOnly && num === 1) return { label: label, simple: true, imgOnly: false, imgLimit: 0 };
          return { label: label, simple: false, imgOnly: imgOnly, imgLimit: num > 0 ? num : 0 };
        }
        return { label: t, simple: false, imgOnly: false, imgLimit: 0 };
      })
      .filter(it => it.label);
  }

  /** 图片占位符（`imgPlaceholder` 产出）的正则：`\u0001KHIMG\u0001alt|url\u0001ENDIMG\u0001` */
  const IMG_RE = new RegExp('\u0001KHIMG\u0001[^|]*\\|[^\u0001]*\u0001ENDIMG\u0001', 'g');

  /**
   * 按字段的图片选项处理一段内容（**只动图片占位符与文字，不碰 HTML**，调用方随后仍走 escHtml）：
   *   · `imgOnly`  → 只留图片（丢掉文字）
   *   · `imgLimit` → 该字段全局最多保留 N 张图（`budget.n` 跨单元格累计，保证"前 N 张"是整字段的前 N 张）
   * 用户口径："抓取需要支持仅图片、前几张图片的方式"。
   */
  function applyImgPolicy(text, opt, budget) {
    let s = String(text == null ? '' : text);
    const b = budget || { n: 0 };
    /* 【刻意**不按 src 去重**】真实页面里同一张图可能在两列/两行里各出现一次
     * （用户给的结构就是这样：最新版本与历史版本都放了「图一图二」），
     * 去重会直接把其中一列吃空 —— 比"偶尔多一张重复图"糟得多。 */
    if (!opt || (!opt.imgOnly && !opt.imgLimit)) return s;
    if (opt.imgOnly) {
      const keep = [];
      s.replace(IMG_RE, (m) => { keep.push(m); return m; });
      s = keep.join(' ');
      if (!s) return '';
    }
    if (opt.imgLimit > 0) {
      if (b.n == null) b.n = 0;                  // 跨单元格累计，**不重置**（整字段的前 N 张）
      s = s.replace(IMG_RE, (m) => {
        b.n++;
        return b.n <= opt.imgLimit ? m : '';
      });
      s = s.replace(/[ \t]{2,}/g, ' ').replace(/^[ \t]+|[ \t]+$/g, '');
    }
    return s;
  }

  /**
   * 空值判定**唯一口径**：`-` / `—` / `–` / `－` / `~` / `/` 等符号占位串，
   * 以及 `无` / `暂无` / `N/A` / `null` 这类"没有内容"的文字占位串。
   *
   * 为什么必须单独判、且必须只有一处：
   *   · 抓取块的「下一字段」判据是"标签列有内容且右侧全空"，而**空值行的标签列常写 `-`**
   *     （用户明确要求"备注为空显示 `-`"）。若不把 `-` 当占位，空值行会被误判成"下一字段开始"，
   *     把后面的真实值整段截掉 —— 实测踩到：仅抓取模式下第 1 行右格是 `-`，
   *     第 2 行的真实包名就再也抓不出来（策划案 §7.5 坑 15「触发判据 ≠ 抓取内容」要防的正是这类语义错）。
   *   · **触发判据**（`triggerOk`）问的也是"右格有没有内容"，必须用同一份口径 ——
   *     否则就会出现"`-` 算空、`无` 算内容"这种同一概念两套规则的漂移
   *     （用户实测问到：`-` 加一个按钮时算不算空）。
   *
   * 【词表是白名单，一行的成本】漏收的占位串只会**多显示一条**（值就是那个占位串），
   * 不会丢内容；已有词误伤才会丢内容，所以只收"无歧义 = 没有值"的串，
   * 且**全串锚定**（`^…$`）—— `无理由退货` 这种真值不会被误判。
   */
  const PLACEHOLDER_WORDS = /^(?:无|暂无|没有|无数据|暂无数据|未填写|未设置|未配置|n\/?a|null|none|undefined|nil)$/i;

  function isPlaceholderText(s) {
    const t = String(s == null ? '' : s).trim();
    if (!t) return true;
    if (/^[-—–－~～/\\|*·．.、\s]+$/.test(t)) return true;   // 纯符号占位（`-` / `--` / `——` / `/` …）
    return PLACEHOLDER_WORDS.test(t);
  }

  /* ---------------------------------------------------------- 合并块抓取 */

  /**
   * 收集标签格右侧的合并块（旧版 `_collectRightBlock`，v1.6.37 / v1.7.3）。
   * 标签格可能是 rowspan 合并多行的单元格，右侧为未合并的每行单元格。
   * 返回 `[[{t, rs, cs}, ...], ...]`：每行一个数组，rs/cs 为原表格的 rowspan/colspan。
   *
   * 抓取范围**不限于 label 的 rowspan**：右侧内容常纵向延伸超过合并范围；
   * 一路向下抓，直到"超过 label 合并范围后 label 所在列出现新内容"（视为下一字段开始）
   * 或表格结束。
   */
  function collectRightBlock(cell, table) {
    const rowIdx = cell.parentElement ? cell.parentElement.rowIndex : -1;
    if (rowIdx < 0) return [];
    const rowspan = cell.rowSpan || 1;
    const col = cell.cellIndex;
    const nRows = table.rows.length;

    const colUsage = {};
    const occupy = (c, span, rs) => {
      for (let k = 0; k < span; k++) {
        const key = c + k;
        colUsage[key] = Math.max(colUsage[key] || 0, rs);
      }
    };
    const step = (tds) => {
      let c = 0;
      const out = [];
      for (const t of tds) {
        while (colUsage[c]) c++;
        const cs = t.colSpan || 1;
        const rs = t.rowSpan || 1;
        out.push({ td: t, col: c });
        occupy(c, cs, rs);
        c += cs;
      }
      Object.keys(colUsage).forEach(k => { colUsage[k]--; if (colUsage[k] <= 0) delete colUsage[k]; });
      return out;
    };

    // 前置：处理标签上方各行，建立列占用（兼容标签前有合并的表格）
    for (let r = 0; r < rowIdx && r < nRows; r++) step(table.rows[r].cells);

    /**
     * 【起始行 = 标签格自身所在行】（与旧版 `_collectRightBlock` 一致）
     *   旧版就把"标签行 + 其右侧格子"算作该字段内容的一部分（rowspan 形式的字段名尤其如此）。
     *   改成"标签下一行"会让「仅抓取」（标签在表头、值在下方）整块抓空 —— 实测踩到。
     *
     * 【「下一字段」判据】= 标签列的格子**没有被上方 rowspan 占用**（即它真的是本列的一个新格子）
     *   且该格有内容、且标签列右侧全空 → 视为下一个字段的开始。
     *
     *   为什么不能只用"标签列有内容"：同一列在不同表格里含义完全不同 ——
     *     · 多列字段表：标签列是"字段名区"，出现新内容 = 新字段（要收尾）；
     *     · 两列表（字段名 | 值）：标签列**本身就是值列**，第 1 行是字段名、后续行是值，
     *       每一步都在标签列有内容 —— 只看"有内容"会把第 2 行起的真实值全部截断。
     *   区分办法：看该行这个位置是"被上方 rowspan 占位后自动落位"还是"真实存在的新格子"。
     *   真实拖尾（同列独立格子）→ 当成同字段的多行内容继续收集；
     *   被占位落位 → 与上面是同一逻辑列，继续收集。
     *   本判据在"多行内容 / rowspan 合并块 / 两列表 / 表头式标签"四种布局下都给出正确结果。
     */
    /** 标签格本身是不是"表头格"（`<th>` 或位于表头行）——用它决定是否把标签行算作内容：
     *  `<th>驳回原因</th>` 这种"标签在表头、值在下方"的表格，标签行的其它格子是**列标题**，
     *  必须跳过；而字段名直接写在数据格里的表格（`<td>驳回原因</td>`），标签行本身就是内容行。 */
    function isHeaderLikeCell(cell) {
      if (!cell) return false;
      if (cell.tagName === 'TH') return true;
      const table = cell.closest ? cell.closest('table') : null;
      if (!table) return false;
      const tr = cell.closest('tr');
      const head = table.tHead || table.querySelector('thead');
      if (head && tr && head.contains(tr)) return true;
      return false;
    }

    const startLabel = cellVisualText(cell);          // 起始标签文本（新字段判据要用）
    const startRow = isHeaderLikeCell(cell) ? (rowIdx + rowspan) : rowIdx;
    const labelBottom = rowIdx + rowspan;
    const headerLike = isHeaderLikeCell(cell);
    const rows = [];
    for (let r = startRow; r < nRows; r++) {
      const cells = step(table.rows[r].cells);
      const line = [];
      let labelCell = null;
      for (const c of cells) {
        if (c.col === col) { labelCell = c.td; continue; }
        if (c.col > col) {
          const txt = cellVisualText(c.td);
          if (txt || (c.td.rowSpan || 1) > 1 || (c.td.colSpan || 1) > 1) {
            line.push({ t: txt, rs: c.td.rowSpan || 1, cs: c.td.colSpan || 1 });
          }
        }
      }
      /**
       * 标签列右侧**没有任何列**的表（典型是两列表「字段名 | 值」）：
       * 它的值就在标签列本身 —— 第 1 行是字段名，之后每行是值。
       * 必须把标签列的格子也算进内容，否则「仅抓取」这类两列表永远抓不到东西
       * （实测踩到：`应用名称 | 包名` 两列，值全在标签列，`c.col > col` 恒为空 → 抓取块为空）。
       * 判据用"标签列是不是最后一列"，两种表都能兼顾。
       */
      const labelIsLastColumn = !cells.some(c => c.col > col);
      if (labelIsLastColumn && labelCell) {
        const txt = cellVisualText(labelCell);
        if (txt) line.push({ t: txt, rs: labelCell.rowSpan || 1, cs: labelCell.colSpan || 1 });
      }

      // 新字段起始行：标签格不是表头格（即标签写在数据格里）、标签列不是最后一列、
      // 标签列有真实内容（非 `-` 占位）、且本行标签列右侧没有任何内容。
      const isOwnCell = !!(labelCell && !isPlaceholderText(cellVisualText(labelCell)));
      let nextField = !headerLike && !labelIsLastColumn && r >= labelBottom && isOwnCell && line.length === 0;
      /* 新字段起始行（补充判据）：本行是**真实的新标签格**、标签文字与起始标签**不同**、
       * 且本字段**已经收集到内容** → 同样是新字段的开始。
       *
       * 为什么必须有这一条：上面那条要求"本行右侧为空"，而「标签 | 值」这种最常见的两列表里，
       * 下一个字段那一行**右侧恰恰有值** → 被判成"同字段的又一行内容"，于是**字段块一路越界**：
       * 实测（极端场景体检）驳回原因的值里混进了「高价值需跟进 / 命中行…」，
       * 后面的字段内容被吞掉又重复渲染。判据只在"值取自右侧列"时生效（`!labelIsLastColumn`），
       * 所以"值就在标签列"的两列表（`应用名称 | 包名`）行为不变。
       * rowspan 合并的标签（如上例中跨两行的「驳回原因」）仍算同字段 —— 它的 `isOwnCell` 为假。 */
      if (!nextField && !headerLike && !labelIsLastColumn && r >= labelBottom && isOwnCell &&
          rows.length && cellVisualText(labelCell) !== startLabel) {
        nextField = true;
      }
      if (nextField) break;                  // 新字段起始行：本行不含本字段内容，直接收尾
      if (line.length) rows.push(line);
    }
    return rows;
  }

  /* ---------------------------------------------------------- 假表格抓取 */

  /** 取「标签元素」右侧内容（旧版 `_fakeRightValue`）：同父右邻兄弟 → 逐层向上找父级右邻兄弟 */
  function fakeRightValue(labelEl) {
    if (!labelEl) return '';
    let sib = labelEl.nextElementSibling;
    while (sib) {
      const v = cellText(sib, true);
      if (v) return v;
      sib = sib.nextElementSibling;
    }
    let p = labelEl.parentElement;
    for (let d = 0; p && d < 6; d++, p = p.parentElement) {
      const ps = p.nextElementSibling;
      if (ps) {
        const v = cellText(ps, true);
        if (v) return v;
      }
    }
    return '';
  }

  /**
   * 假表格抓取（旧版 `_extractFetchedFromFakeTable`，v1.13.4）：
   * 无 `<table>` 时，在命中位置最近的「包含全部待抓标签文本」的祖先容器内，
   * 找「文本==标签」的元素，取其右邻内容。scope 循环**必须先查再判断到 body**
   * （假表格无公共容器时 body 直接子元素，否则永远找不到 —— 策划案 §7.3 坑 9）。
   */
  function extractFromFakeTable(startEl, items) {
    if (!startEl) return [];
    const labels = items.map(i => i.label);
    let scope = null;
    let el = startEl;
    while (el) {
      const txt = el.textContent || '';
      if (labels.every(l => txt.indexOf(l) !== -1)) { scope = el; break; }
      if (el === document.body) break;
      el = el.parentElement;
    }
    if (!scope) return [];
    const list = Array.prototype.slice.call(scope.querySelectorAll('*'));
    const out = [];
    for (const item of items) {
      let labelEl = null;
      for (let j = 0; j < list.length; j++) {
        if ((list[j].textContent || '').trim() === item.label) { labelEl = list[j]; break; }
      }
      if (!labelEl) continue;
      const val = fakeRightValue(labelEl);
      if (val) out.push({ label: item.label, rows: [[{ t: val, rs: 1, cs: 1 }]] });
    }
    return out;
  }

  /* --------------------------------------------------------------- 主入口 */

  function nearestTable(el) {
    let n = el;
    while (n && n.nodeType === 1 && n.tagName !== 'TABLE') n = n.parentNode;
    return (n && n.tagName === 'TABLE') ? n : null;
  }

  /**
   * 抓取命中所在表格里 fetchLabels 各标签对应的值。
   * @param {Text} textNode 命中文本节点（定位同表 / 同容器范围）
   * @param {string} rawLabels fetchLabels 原文
   * @returns {Array<{label:string, rows:Array<Array<{t:string,rs:number,cs:number}>>}>}
   */
  function extractFor(textNode, rawLabels) {
    const items = parseLabels(rawLabels);
    if (!items.length || !textNode) return [];
    const table = nearestTable(textNode.parentNode);
    if (!table) {
      return extractFromFakeTable(textNode.parentElement, items);
    }

    const cells = table.querySelectorAll('td, th');
    const out = [];
    for (const item of items) {
      let target = null;
      for (let i = 0; i < cells.length; i++) {
        if ((cells[i].textContent || '').trim() === item.label) { target = cells[i]; break; }
      }
      if (!target) continue;      let rows;
      if (item.simple) {
        // 简单模式：取标签行右侧相邻第一个单元格（跳过按钮、合并同格多子元素文本）
        const tr = target.parentElement;
        const right = tr && tr.cells ? tr.cells[target.cellIndex + 1] : null;
        if (right) {
          const val = cellText(right, true);
          if (val) rows = [[{ t: val, rs: 1, cs: 1 }]];
        }
      } else {
        rows = collectRightBlock(target, table);
      }
      if (rows && rows.length) out.push({ label: item.label, rows });
    }
    return out;
  }

  /* ------------------------------------------------- 多行表格渲染（唯一实现） */

  const escHtml = (s) => {
    const d = document.createElement('div');
    d.textContent = (s == null ? '' : String(s));
    return restoreImgs(d.innerHTML);
  };
  const trimSp = (s) => String(s).replace(/^[ \u3000]+|[ \u3000]+$/g, '');

  /** 固定标题词识别（双通道之一）：整行等于 / 以「标题词 + 空白」开头 */
  function knownTitle(s) {
    const t = String(s).trim();
    for (const k of GROUP_TITLES) {
      if (t === k) return k;
      if (t.indexOf(k) === 0 && /[ \u3000]/.test(t.charAt(k.length) || ' ')) return k;
    }
    return null;
  }
  const NUM_RE = /^\s*\d+[、.．:：]\s*/;

  /**
   * 解析一个块的文本行为「一级分组 + 二级标题」两级结构（旧版 v1.6.44 + v1.7.4）。
   * 标题行识别双通道：① 含 tab 的行 = 标题 + 内容；② 匹配固定标题词的行。
   * 编号行（`1、 xxx`）不识别为分组标题。与左列标签同名的行视为网页重复标题，只保留其后内容。
   */
  function parseBlock(textLines, label) {
    const blocks = [];
    let curBlock = null;
    let curSub = null;
    const ensureBlock = (g) => { const b = { gtitle: g, subs: [] }; blocks.push(b); return b; };

    for (let i = 0; i < textLines.length; i++) {
      const ln = textLines[i];
      const ti = ln.indexOf('\t');
      if (ti >= 0) {
        const title = trimSp(ln.slice(0, ti));
        const rest = trimSp(ln.slice(ti + 1));
        if (label != null && title === String(label)) {
          if (!curBlock) curBlock = ensureBlock(null);
          if (rest) {
            if (!curSub) { curSub = { title: null, lines: [] }; curBlock.subs.push(curSub); }
            curSub.lines.push(rest);
          }
          continue;
        }
        curSub = { title, lines: rest ? [rest] : [] };
        if (!curBlock) curBlock = ensureBlock(null);
        curBlock.subs.push(curSub);
        continue;
      }
      if (label != null && ln === String(label)) continue;
      /**
       * **固定标题词必须无条件下判**（不能受"下一行是否含 tab"的启发式约束）。
       * 实测（用户真实样例）：`运营备注` 下面紧跟的是**纯文本行**（如"请修改。"），
       * 不含 tab；若把 knownTitle 放到 lookahead 条件之后，这一行会被当成**内容**，
       * 于是既丢了子标题、又把子标题文字混进上一段内容里。
       */
      const kt = knownTitle(ln);
      if (kt) {
        const rest = trimSp(ln.slice(kt.length));
        curSub = { title: kt, lines: rest ? [rest] : [] };
        if (!curBlock) curBlock = ensureBlock(null);
        curBlock.subs.push(curSub);
      } else if (!NUM_RE.test(ln) && i + 1 < textLines.length &&
                 (textLines[i + 1].indexOf('\t') >= 0 || knownTitle(textLines[i + 1]) !== null)) {
        curBlock = ensureBlock(ln);   // 一级分组标题行（如「32位包:」）
        curSub = null;
      } else {
        if (!curBlock) curBlock = ensureBlock(null);
        if (!curSub) { curSub = { title: null, lines: [] }; curBlock.subs.push(curSub); }
        curSub.lines.push(ln);
      }
    }
    return blocks
      .map(b => ({ gtitle: b.gtitle, subs: b.subs.filter(s => s.lines.length > 0) }))
      .filter(b => b.subs.length > 0);
  }

  /**
   * 多块合并渲染成**一个** `<table class="kh-table kh-table-fetch">`（旧版 `_rowsToTableMulti`，v1.7.6）。
   * 多字段合并为同一张表的多行展示，不拆成多个独立小表；
   * 每个 label 作为左列独立一块（rowspan = 该块行数）；真实多列格保留 rowspan/colspan。
   * 返回 HTML 字符串（供重要笔记面板 / 备注卡片插入）。
   *
   * 【为什么带 `kh-table-fetch` 这个标记类】本表**没有表头行**：第一行就是数据
   * （`[字段 label][二级标题/分组标题][内容]`）。而 Markdown / 富文本表格的第一行**是**表头。
   * 两者共用 `.kh-table` 时，`.kh-table tr:first-child td` 那条"首行当表头"的着色规则
   * 会把「基本信息 / 驳回字段：X / 32位包:」也刷上底色（用户反馈："每列第一个单元格都标了底色"）。
   * 因此用标记类把两类表分开，只给**字段 label 格**上色。
   */
  function rowsToTableHtml(multi) {
    const items = (multi || []).map((m) => {
      const opt = m.opt || null;                 // 该字段的图片选项（仅图片 / 前 N 张）
      const budget = { n: 0 };                   // "前 N 张"是**整字段**的前 N 张（跨单元格累计）
      const textLines = [];
      let grid = false;
      for (const line of m.rows || []) {
        if (line.length === 1 && /[\r\n]/.test(line[0].t)) {
          const parts = String(applyImgPolicy(line[0].t, opt, budget)).split(/\r?\n/).map(trimSp).filter(Boolean);
          textLines.push.apply(textLines, parts);
        } else if (line.length === 1) {
          const one = trimSp(applyImgPolicy(line[0].t, opt, budget));
          if (one) textLines.push(one);
        } else {
          grid = true;
        }
      }
      return { label: m.label, textLines, grid, rows: m.rows || [], opt: opt, budget: budget };
    });

    let html = '<table class="kh-table kh-table-fetch">';
    for (const it of items) {
      if (it.grid) {
        const total = it.rows.length;
        /* 该字段里是否有图片：决定"纯数字格"要不要当噪音去掉（见下） */
        const fieldHasImg = (it.rows || []).some((line) => line.some((c) => String(c.t).indexOf('\u0001KHIMG\u0001') >= 0));
        let firstInBlock = true;
        for (const line of it.rows) {
          let cells = '';
          for (const c of line) {
            let attrs = '';
            if (c.rs > 1) attrs += ' rowspan="' + c.rs + '"';
            if (c.cs > 1) attrs += ' colspan="' + c.cs + '"';
            let val = applyImgPolicy(c.t, it.opt, it.budget);
            /* 【图片字段里的"纯数字格"不是内容】用户实测：截图字段的两个版本列里，
             * 历史版本为空的那一格页面写的是计数 `0`，展示出来就是"后面多出一个单独的 0 单元格"。
             * 判据：本字段**别处有图片** + 本格**没有图片** + 本格文字是**纯数字** → 视为计数，留空
             * （留空而不是删格，列才对得齐）。 */
            if (fieldHasImg && !/\u0001KHIMG\u0001/.test(String(c.t)) && /^\s*\d+\s*$/.test(String(c.t))) val = '';
            cells += '<td' + attrs + '>' + escHtml(val) + '</td>';
          }
          html += '<tr>' + (firstInBlock && it.label != null ? '<td class="kh-table-label" rowspan="' + total + '">' + escHtml(it.label) + '</td>' : '') + cells + '</tr>';
          firstInBlock = false;
        }
        continue;
      }
      if (!it.textLines.length) continue;
      const filled = parseBlock(it.textLines, it.label);
      if (!filled.length) continue;

      const blockTotal = filled.reduce(
        (n, b) => n + (b.gtitle != null ? 1 : 0) + b.subs.reduce((m2, s) => m2 + s.lines.length, 0), 0);

      /**
       * 列模型固定 **3 列**：`[本字段 label][二级标题][内容]`（与旧版 1.52.0 `_rowsToTableMulti` 同构）。
       *
       * 【四条规则都是真浏览器量几何 + 展开网格定下来的，走过弯路，记录在此】
       *
       * ① **label 列只在第 1 行出现一次，`rowspan = 本块总行数`**（旧版口径）。
       *    绝不在续行补"空 label 格"：多补一格会把它后面的格子整体右移一列，
       *    实测就是把「理由」挤到最右侧成为独立一列（用户截图圈出的问题）。
       *
       * ② **一级分组标题 `colspan=2`**，跨满 label 之外的整行（= 「二级标题 + 内容」两列），
       *    从而纵向覆盖下方全部子项，渲染成一条分组横条。
       *
       * ③ **二级标题 `rowspan = 该标题下的行数`**，只在首行出现；续行**只写内容格**，
       *    靠 label(①) 与二级标题(③) 两个 rowspan 各占住一列，内容自然落到第 3 列 ——
       *    与首行内容**严格同列**（真浏览器实测：两者左缘都为 [342]，用户要的"填在前面"）。
       *    这里曾经写成"续行补 `<td colspan=2>` 把内容吞进去"，虽然也同列，
       *    但会让表格多出一个 0 宽的幽灵列，且平白多出空格子，已回退到旧版的干净写法。
       *
       * ④ **没有二级标题的子块**：内容格 `colspan=2` 直接占满「二级标题 + 内容」两列，
       *    不留空列、右缘与有标题的行对齐。
       */
      /** label 之外的两列宽度（「二级标题 + 内容」）：一级分组标题与无标题内容格都用它跨满 */
      const afterLabelColspan = 2;
      let labelDone = false;
      /** label 列：只在第 1 行输出一次，rowspan 覆盖整块（其余行为空字符串，不占格） */
      const labelCell = () => {
        if (labelDone) return '';
        labelDone = true;
        const rs = blockTotal > 1 ? ' rowspan="' + blockTotal + '"' : '';
        return '<td class="kh-table-label"' + rs + '>' + escHtml(it.label) + '</td>';
      };

      for (const b of filled) {
        if (b.gtitle != null) {
          html += '<tr>' + labelCell() +
            '<td colspan="' + afterLabelColspan + '">' + escHtml(b.gtitle) + '</td></tr>';
        }

        for (const s of b.subs) {
          const cap = s.title == null ? '' : s.title;
          const n = s.lines.length;
          for (let i = 0; i < n; i++) {
            if (!cap) {
              // ④ 无二级标题：内容跨「二级标题 + 内容」两列
              html += '<tr>' + labelCell() +
                '<td colspan="' + afterLabelColspan + '">' + escHtml(s.lines[i]) + '</td></tr>';
            } else if (i === 0) {
              // ③ 首行：二级标题 rowspan + 内容
              html += '<tr>' + labelCell() +
                '<td rowspan="' + n + '">' + escHtml(cap) + '</td><td>' + escHtml(s.lines[i]) + '</td></tr>';
            } else {
              // ③ 续行：只写内容格（第 1、2 列已被两个 rowspan 占住）
              html += '<tr><td>' + escHtml(s.lines[i]) + '</td></tr>';
            }
          }
        }
      }
    }
    html += '</table>';
    return html;
  }

  /** 真正算一次（不缓存时走这条）。字段级的图片选项（仅图片 / 前 N 张）按 label 带进渲染。 */
  function computeBlock(textNode, rawLabels) {
    const fetched = extractFor(textNode, rawLabels);
    if (!fetched.length) return null;
    const optOf = {};
    for (const it of parseLabels(rawLabels)) optOf[it.label] = it;
    return rowsToTableHtml(fetched.map(f => ({ label: f.label, rows: f.rows, opt: optOf[f.label] })));
  }

  /**
   * 命中 → 抓取渲染片段（供重要笔记条目）。
   * `fetchLabels` 为空 = 不抓（不是"抓全部右列"）；
   * 配了标签但目标为空 → 返回空，**不回退抓标题右格**。
   *
   * 【必须支持"每轮重建复用"】`extractFor` 的标签格查找是**全表范围**的
   * （`table.querySelectorAll('td, th')` + 找首个文本==标签的格子），所以
   * **同一张表 + 同一组标签，结果对所有命中完全相同**。而它此前被**每一个重要命中**调用一次，
   * 单次又是 O(表格单元格数) → 整体 O(命中数 × 单元格数)：实测 800 行表格（1734 命中）
   * 光这一项就要 **31 秒**、整条重建 30s+，页面直接"长时间无响应"（用户实测缺陷）。
   * 传入 `cache`（按"作用域根元素 + 标签"缓存）后，同一张表只算一次，其余全是查表。
   * cache 由调用方**每轮重建新建**（见 important-note 的 collectEffective），因此不会陈旧；
   * 不传 cache 就退回逐次计算（诊断路径用的就是这条）。
   */
  function blockFor(textNode, rawLabels, cache) {
    if (!cache || !textNode) return computeBlock(textNode, rawLabels);
    const root = nearestTable(textNode.parentNode) || textNode.parentElement;
    if (!root) return computeBlock(textNode, rawLabels);
    let byLabels = cache.get(root);
    if (!byLabels) { byLabels = new Map(); cache.set(root, byLabels); }
    const k = String(rawLabels == null ? '' : rawLabels);
    if (byLabels.has(k)) return byLabels.get(k);
    const v = computeBlock(textNode, rawLabels);
    byLabels.set(k, v);
    return v;
  }

  KH.Fetch = {
    GROUP_TITLES, parseLabels, extractFor, extractFromFakeTable, collectRightBlock,
    cellText, cellVisualText, isInteractive, imgPlaceholder, restoreImgs,
    rowsToTableHtml, blockFor, triggerOk, fakeRightValue, nearestTable, isPlaceholderText,
    /* 图片选项（仅图片 / 前 N 张）：单测直接锁 */
    applyImgPolicy
  };
})();
